{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.186.206:9402 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.910Z",
  "value": "27 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.186.206:9402 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.910Z",
  "value": "0 1 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.234.10:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "39 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.234.10:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "0 1 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "3 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.233.8:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "29 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.233.8:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.167.174:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "48 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.167.174:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.160.141:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "30 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.160.141:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "0 1 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.88.204:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "53 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.88.204:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "0 1 (7) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.194.196:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "54 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.194.196:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.911Z",
  "value": "0 1 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.213.89:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "25 0 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.213.89:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "0 1 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.207.131:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "28 0 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.207.131:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "0 1 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "36 0 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "0 1 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "37 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "0 1 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.117.252:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "38 0 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.117.252:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "0 1 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.43.95:8080 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "26 0 (14) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.43.95:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "0 1 (14) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.200.111:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "42 0 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.200.111:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "0 1 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.20.152:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "43 0 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.20.152:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "0 1 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.20.152:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.912Z",
  "value": "44 0 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.20.152:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.913Z",
  "value": "0 1 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.17:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.945Z",
  "value": "43 0 (19) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.17:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.945Z",
  "value": "0 1 (19) [0x60 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.17:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.973Z",
  "value": "44 0 (18) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.17:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:09.973Z",
  "value": "0 1 (18) [0x60 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.11:30571 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.013Z",
  "value": "43 0 (42) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.11:30571 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.013Z",
  "value": "0 1 (42) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30571 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.013Z",
  "value": "43 0 (21) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30571 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.013Z",
  "value": "0 1 (21) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.11:30681 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.041Z",
  "value": "44 0 (43) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.11:30681 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.041Z",
  "value": "0 1 (43) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30681 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.041Z",
  "value": "44 0 (23) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30681 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.041Z",
  "value": "0 1 (23) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.45.147:10254 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.042Z",
  "value": "41 0 (24) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.45.147:10254 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.042Z",
  "value": "0 1 (24) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.240.226:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.042Z",
  "value": "40 0 (25) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.240.226:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.042Z",
  "value": "0 1 (25) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.19:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.073Z",
  "value": "40 0 (26) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.19:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.073Z",
  "value": "0 1 (26) [0x60 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.11:32726 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.133Z",
  "value": "40 0 (44) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "192.168.1.11:32726 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.133Z",
  "value": "0 1 (44) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:32726 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.133Z",
  "value": "40 0 (28) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:32726 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.133Z",
  "value": "0 1 (28) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.182.189:9000 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.133Z",
  "value": "46 0 (30) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.182.189:9000 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.133Z",
  "value": "0 1 (30) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.182.189:9001 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.134Z",
  "value": "45 0 (31) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.182.189:9001 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.134Z",
  "value": "0 1 (31) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.167.155:7373 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.134Z",
  "value": "31 0 (29) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.167.155:7373 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.134Z",
  "value": "35 0 (29) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.167.155:7373 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.134Z",
  "value": "0 2 (29) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.75.113:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.134Z",
  "value": "32 0 (32) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.75.113:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:10.134Z",
  "value": "0 1 (32) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "192.168.1.10:32726 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:12.785Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "192.168.1.10:32726 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:12.785Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "192.168.1.10:30571 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:12.809Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "192.168.1.10:30571 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:12.809Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "192.168.1.10:30681 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:12.833Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "192.168.1.10:30681 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:12.833Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.88.204:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:13.015Z",
  "value": "0 0 (7) [0x0 0x10]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.11.88.204:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:13.015Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.88.204:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:14.048Z",
  "value": "55 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.88.204:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:14.048Z",
  "value": "0 1 (7) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.194.196:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.547Z",
  "value": "0 0 (8) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.11.194.196:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.547Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.194.196:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:18.584Z",
  "value": "0 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.194.196:80 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:28.642Z",
  "value": "56 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.194.196:80 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:28.642Z",
  "value": "0 1 (8) [0x0 0x0]"
}

