{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.10.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:12.027Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "192.168.101.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:12.783Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.10.0.73:0",
  "last-error": "unable to delete element 10.10.0.73:0 from map cilium_lxc: delete: key does not exist",
  "timestamp": "2024-08-04T16:03:12.981Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.10.0.73:0",
  "last-error": "unable to delete element 10.10.0.73:0 from map cilium_lxc: delete: key does not exist",
  "timestamp": "2024-08-04T16:03:13.182Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:16.275Z",
  "value": "id=84    sec_id=111630 flags=0x0000 ifindex=41  mac=22:3A:C1:42:03:3B nodemac=5A:3D:1F:73:56:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:16.287Z",
  "value": "id=3129  sec_id=126990 flags=0x0000 ifindex=17  mac=C2:67:F4:44:C5:24 nodemac=9E:32:A3:F4:26:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:16.288Z",
  "value": "id=1840  sec_id=87680 flags=0x0000 ifindex=21  mac=DE:C6:A8:3D:08:40 nodemac=0E:5F:8B:18:78:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:16.296Z",
  "value": "id=889   sec_id=124930 flags=0x0000 ifindex=29  mac=CE:2D:41:E7:B1:A9 nodemac=7E:9B:CC:42:B3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:16.300Z",
  "value": "id=2180  sec_id=120519 flags=0x0000 ifindex=55  mac=FA:F9:16:5A:AE:38 nodemac=EE:39:66:A4:13:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:16.301Z",
  "value": "id=1221  sec_id=81099 flags=0x0000 ifindex=71  mac=EA:38:1D:8F:B4:E8 nodemac=96:E8:D6:FF:D5:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:16.303Z",
  "value": "id=2776  sec_id=103831 flags=0x0000 ifindex=39  mac=12:02:56:FB:CC:29 nodemac=F6:A4:E9:14:DF:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.130Z",
  "value": "id=3931  sec_id=76802 flags=0x0000 ifindex=13  mac=6A:BE:93:2F:5A:9A nodemac=12:45:0D:33:80:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.130Z",
  "value": "id=338   sec_id=99246 flags=0x0000 ifindex=15  mac=EA:EF:81:04:39:85 nodemac=2A:03:8C:EF:B0:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.131Z",
  "value": "id=1037  sec_id=68187 flags=0x0000 ifindex=27  mac=0A:FD:15:1D:61:B4 nodemac=06:7D:1C:9A:9D:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.131Z",
  "value": "id=369   sec_id=66091 flags=0x0000 ifindex=61  mac=EE:61:2C:AE:39:02 nodemac=CA:50:84:A1:10:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.133Z",
  "value": "id=1818  sec_id=74727 flags=0x0000 ifindex=35  mac=7E:21:7B:67:FA:B7 nodemac=FA:0C:0E:33:D9:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.135Z",
  "value": "id=3601  sec_id=86769 flags=0x0000 ifindex=31  mac=26:0F:68:E5:AB:1A nodemac=96:86:CD:B0:3A:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.136Z",
  "value": "id=2211  sec_id=73986 flags=0x0000 ifindex=37  mac=DA:40:07:7A:A0:AC nodemac=52:1F:77:B9:AC:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.137Z",
  "value": "id=312   sec_id=68452 flags=0x0000 ifindex=51  mac=62:3A:87:4F:71:4E nodemac=EE:CC:1D:A4:6E:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.206Z",
  "value": "id=1130  sec_id=105483 flags=0x0000 ifindex=33  mac=FA:08:A7:EA:7F:23 nodemac=DA:F1:59:AA:AC:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.207Z",
  "value": "id=2611  sec_id=67967 flags=0x0000 ifindex=59  mac=AA:C2:AA:B9:05:A9 nodemac=86:D4:6D:77:25:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.208Z",
  "value": "id=1372  sec_id=97068 flags=0x0000 ifindex=43  mac=76:42:43:0F:65:9C nodemac=32:AA:E4:E5:37:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.208Z",
  "value": "id=1730  sec_id=119669 flags=0x0000 ifindex=63  mac=32:0F:58:70:3E:A0 nodemac=1A:1E:A2:8C:4A:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.212Z",
  "value": "id=1157  sec_id=126091 flags=0x0000 ifindex=19  mac=5E:F7:54:FA:71:F1 nodemac=F6:10:AA:81:F3:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.212Z",
  "value": "id=323   sec_id=116209 flags=0x0000 ifindex=45  mac=46:79:03:C1:57:9E nodemac=46:46:BC:7D:29:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.212Z",
  "value": "id=3884  sec_id=78979 flags=0x0000 ifindex=53  mac=FA:57:71:92:0A:12 nodemac=EA:B8:DD:5D:5D:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.230Z",
  "value": "id=265   sec_id=75356 flags=0x0000 ifindex=23  mac=C2:3E:5D:AD:5F:87 nodemac=FA:B0:B0:45:5C:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.280Z",
  "value": "id=2708  sec_id=78979 flags=0x0000 ifindex=49  mac=62:1F:0D:8D:B2:B4 nodemac=7E:68:C8:E5:63:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.284Z",
  "value": "id=832   sec_id=80885 flags=0x0000 ifindex=47  mac=6E:D8:E3:22:9C:D7 nodemac=66:2E:D0:39:89:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.287Z",
  "value": "id=84    sec_id=111630 flags=0x0000 ifindex=41  mac=22:3A:C1:42:03:3B nodemac=5A:3D:1F:73:56:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.292Z",
  "value": "id=3129  sec_id=126990 flags=0x0000 ifindex=17  mac=C2:67:F4:44:C5:24 nodemac=9E:32:A3:F4:26:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.304Z",
  "value": "id=3253  sec_id=4     flags=0x0000 ifindex=75  mac=CA:91:26:8A:B7:2B nodemac=06:1D:6B:CB:46:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.306Z",
  "value": "id=1840  sec_id=87680 flags=0x0000 ifindex=21  mac=DE:C6:A8:3D:08:40 nodemac=0E:5F:8B:18:78:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.311Z",
  "value": "id=361   sec_id=81099 flags=0x0000 ifindex=77  mac=4A:03:72:84:25:EE nodemac=5A:7A:AA:2F:D4:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.361Z",
  "value": "id=889   sec_id=124930 flags=0x0000 ifindex=29  mac=CE:2D:41:E7:B1:A9 nodemac=7E:9B:CC:42:B3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.387Z",
  "value": "id=338   sec_id=99246 flags=0x0000 ifindex=15  mac=EA:EF:81:04:39:85 nodemac=2A:03:8C:EF:B0:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.388Z",
  "value": "id=1221  sec_id=81099 flags=0x0000 ifindex=71  mac=EA:38:1D:8F:B4:E8 nodemac=96:E8:D6:FF:D5:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.399Z",
  "value": "id=2776  sec_id=103831 flags=0x0000 ifindex=39  mac=12:02:56:FB:CC:29 nodemac=F6:A4:E9:14:DF:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.400Z",
  "value": "id=3931  sec_id=76802 flags=0x0000 ifindex=13  mac=6A:BE:93:2F:5A:9A nodemac=12:45:0D:33:80:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.403Z",
  "value": "id=2180  sec_id=120519 flags=0x0000 ifindex=55  mac=FA:F9:16:5A:AE:38 nodemac=EE:39:66:A4:13:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.435Z",
  "value": "id=1037  sec_id=68187 flags=0x0000 ifindex=27  mac=0A:FD:15:1D:61:B4 nodemac=06:7D:1C:9A:9D:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.438Z",
  "value": "id=369   sec_id=66091 flags=0x0000 ifindex=61  mac=EE:61:2C:AE:39:02 nodemac=CA:50:84:A1:10:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.464Z",
  "value": "id=1818  sec_id=74727 flags=0x0000 ifindex=35  mac=7E:21:7B:67:FA:B7 nodemac=FA:0C:0E:33:D9:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.476Z",
  "value": "id=312   sec_id=68452 flags=0x0000 ifindex=51  mac=62:3A:87:4F:71:4E nodemac=EE:CC:1D:A4:6E:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.482Z",
  "value": "id=2211  sec_id=73986 flags=0x0000 ifindex=37  mac=DA:40:07:7A:A0:AC nodemac=52:1F:77:B9:AC:46"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.10.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.485Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.486Z",
  "value": "id=3601  sec_id=86769 flags=0x0000 ifindex=31  mac=26:0F:68:E5:AB:1A nodemac=96:86:CD:B0:3A:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:08:31.324Z",
  "value": "id=1372  sec_id=68728 flags=0x0000 ifindex=43  mac=76:42:43:0F:65:9C nodemac=32:AA:E4:E5:37:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:08:31.324Z",
  "value": "id=84    sec_id=97006 flags=0x0000 ifindex=41  mac=22:3A:C1:42:03:3B nodemac=5A:3D:1F:73:56:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:08:31.329Z",
  "value": "id=3601  sec_id=103395 flags=0x0000 ifindex=31  mac=26:0F:68:E5:AB:1A nodemac=96:86:CD:B0:3A:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:08:31.338Z",
  "value": "id=3129  sec_id=108192 flags=0x0000 ifindex=17  mac=C2:67:F4:44:C5:24 nodemac=9E:32:A3:F4:26:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:08:31.343Z",
  "value": "id=369   sec_id=67060 flags=0x0000 ifindex=61  mac=EE:61:2C:AE:39:02 nodemac=CA:50:84:A1:10:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:08:31.346Z",
  "value": "id=1130  sec_id=77832 flags=0x0000 ifindex=33  mac=FA:08:A7:EA:7F:23 nodemac=DA:F1:59:AA:AC:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:25:16.084Z",
  "value": "id=3601  sec_id=86769 flags=0x0000 ifindex=31  mac=26:0F:68:E5:AB:1A nodemac=96:86:CD:B0:3A:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:25:16.092Z",
  "value": "id=1130  sec_id=105483 flags=0x0000 ifindex=33  mac=FA:08:A7:EA:7F:23 nodemac=DA:F1:59:AA:AC:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:25:16.092Z",
  "value": "id=1372  sec_id=97068 flags=0x0000 ifindex=43  mac=76:42:43:0F:65:9C nodemac=32:AA:E4:E5:37:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:25:16.095Z",
  "value": "id=84    sec_id=111630 flags=0x0000 ifindex=41  mac=22:3A:C1:42:03:3B nodemac=5A:3D:1F:73:56:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:25:16.097Z",
  "value": "id=3129  sec_id=126990 flags=0x0000 ifindex=17  mac=C2:67:F4:44:C5:24 nodemac=9E:32:A3:F4:26:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:25:16.107Z",
  "value": "id=369   sec_id=66091 flags=0x0000 ifindex=61  mac=EE:61:2C:AE:39:02 nodemac=CA:50:84:A1:10:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:28:44.577Z",
  "value": "id=3601  sec_id=103395 flags=0x0000 ifindex=31  mac=26:0F:68:E5:AB:1A nodemac=96:86:CD:B0:3A:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:28:44.579Z",
  "value": "id=1130  sec_id=77832 flags=0x0000 ifindex=33  mac=FA:08:A7:EA:7F:23 nodemac=DA:F1:59:AA:AC:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:28:44.588Z",
  "value": "id=84    sec_id=97006 flags=0x0000 ifindex=41  mac=22:3A:C1:42:03:3B nodemac=5A:3D:1F:73:56:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:28:44.589Z",
  "value": "id=3129  sec_id=108192 flags=0x0000 ifindex=17  mac=C2:67:F4:44:C5:24 nodemac=9E:32:A3:F4:26:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:28:44.590Z",
  "value": "id=1372  sec_id=68728 flags=0x0000 ifindex=43  mac=76:42:43:0F:65:9C nodemac=32:AA:E4:E5:37:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:28:44.592Z",
  "value": "id=369   sec_id=67060 flags=0x0000 ifindex=61  mac=EE:61:2C:AE:39:02 nodemac=CA:50:84:A1:10:4E"
}

