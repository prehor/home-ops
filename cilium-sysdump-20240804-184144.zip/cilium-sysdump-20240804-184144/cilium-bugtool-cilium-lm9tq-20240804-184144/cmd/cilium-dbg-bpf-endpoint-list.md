IP ADDRESS       LOCAL ENDPOINT INFO
10.10.0.73:0     id=3253  sec_id=4     flags=0x0000 ifindex=75  mac=CA:91:26:8A:B7:2B nodemac=06:1D:6B:CB:46:58    
192.168.1.10:0   (localhost)                                                                                       
10.10.0.137:0    id=265   sec_id=75356 flags=0x0000 ifindex=23  mac=C2:3E:5D:AD:5F:87 nodemac=FA:B0:B0:45:5C:D7    
10.10.0.35:0     id=832   sec_id=80885 flags=0x0000 ifindex=47  mac=6E:D8:E3:22:9C:D7 nodemac=66:2E:D0:39:89:83    
10.10.0.88:0     id=3601  sec_id=103395 flags=0x0000 ifindex=31  mac=26:0F:68:E5:AB:1A nodemac=96:86:CD:B0:3A:AC   
10.10.0.114:0    id=369   sec_id=67060 flags=0x0000 ifindex=61  mac=EE:61:2C:AE:39:02 nodemac=CA:50:84:A1:10:4E    
10.10.0.36:0     id=338   sec_id=99246 flags=0x0000 ifindex=15  mac=EA:EF:81:04:39:85 nodemac=2A:03:8C:EF:B0:66    
10.10.0.161:0    id=2211  sec_id=73986 flags=0x0000 ifindex=37  mac=DA:40:07:7A:A0:AC nodemac=52:1F:77:B9:AC:46    
192.168.1.11:0   (localhost)                                                                                       
10.10.0.151:0    id=2708  sec_id=78979 flags=0x0000 ifindex=49  mac=62:1F:0D:8D:B2:B4 nodemac=7E:68:C8:E5:63:F0    
10.10.0.142:0    id=2611  sec_id=67967 flags=0x0000 ifindex=59  mac=AA:C2:AA:B9:05:A9 nodemac=86:D4:6D:77:25:B9    
10.10.0.104:0    (localhost)                                                                                       
10.10.0.180:0    id=1130  sec_id=77832 flags=0x0000 ifindex=33  mac=FA:08:A7:EA:7F:23 nodemac=DA:F1:59:AA:AC:F7    
10.10.0.71:0     id=84    sec_id=97006 flags=0x0000 ifindex=41  mac=22:3A:C1:42:03:3B nodemac=5A:3D:1F:73:56:44    
10.10.0.160:0    id=323   sec_id=116209 flags=0x0000 ifindex=45  mac=46:79:03:C1:57:9E nodemac=46:46:BC:7D:29:F7   
10.10.0.40:0     id=1372  sec_id=68728 flags=0x0000 ifindex=43  mac=76:42:43:0F:65:9C nodemac=32:AA:E4:E5:37:63    
10.10.0.62:0     id=889   sec_id=124930 flags=0x0000 ifindex=29  mac=CE:2D:41:E7:B1:A9 nodemac=7E:9B:CC:42:B3:D1   
10.10.0.83:0     id=3129  sec_id=108192 flags=0x0000 ifindex=17  mac=C2:67:F4:44:C5:24 nodemac=9E:32:A3:F4:26:24   
10.10.0.21:0     id=2180  sec_id=120519 flags=0x0000 ifindex=55  mac=FA:F9:16:5A:AE:38 nodemac=EE:39:66:A4:13:43   
10.10.0.25:0     id=312   sec_id=68452 flags=0x0000 ifindex=51  mac=62:3A:87:4F:71:4E nodemac=EE:CC:1D:A4:6E:91    
10.10.0.204:0    id=1157  sec_id=126091 flags=0x0000 ifindex=19  mac=5E:F7:54:FA:71:F1 nodemac=F6:10:AA:81:F3:2C   
10.10.0.175:0    id=2776  sec_id=103831 flags=0x0000 ifindex=39  mac=12:02:56:FB:CC:29 nodemac=F6:A4:E9:14:DF:98   
10.10.0.103:0    id=3931  sec_id=76802 flags=0x0000 ifindex=13  mac=6A:BE:93:2F:5A:9A nodemac=12:45:0D:33:80:CF    
10.10.0.29:0     id=1037  sec_id=68187 flags=0x0000 ifindex=27  mac=0A:FD:15:1D:61:B4 nodemac=06:7D:1C:9A:9D:F6    
10.10.0.148:0    id=1730  sec_id=119669 flags=0x0000 ifindex=63  mac=32:0F:58:70:3E:A0 nodemac=1A:1E:A2:8C:4A:E0   
10.10.0.37:0     id=3884  sec_id=78979 flags=0x0000 ifindex=53  mac=FA:57:71:92:0A:12 nodemac=EA:B8:DD:5D:5D:E2    
10.10.0.51:0     id=1818  sec_id=74727 flags=0x0000 ifindex=35  mac=7E:21:7B:67:FA:B7 nodemac=FA:0C:0E:33:D9:DC    
10.10.0.149:0    id=361   sec_id=81099 flags=0x0000 ifindex=77  mac=4A:03:72:84:25:EE nodemac=5A:7A:AA:2F:D4:08    
10.10.0.234:0    id=1840  sec_id=87680 flags=0x0000 ifindex=21  mac=DE:C6:A8:3D:08:40 nodemac=0E:5F:8B:18:78:02    
