top - 16:41:44 up  1:16,  0 users,  load average: 0.30, 0.40, 0.50
Tasks:  16 total,   3 running,  11 sleeping,   0 stopped,   2 zombie
%Cpu(s): 24.6 us, 31.1 sy,  0.0 ni, 44.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :  32028.1 total,  25317.8 free,   5491.2 used,   1219.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.  26104.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   7311 root      20   0    3596    900    772 R  53.3   0.0   0:00.08 bpftool
   7336 root      20   0    3596    948    820 R  33.3   0.0   0:00.05 bpftool
   7208 root      20   0 1242136  13168   5532 S  20.0   0.0   0:00.05 cilium-+
      1 root      20   0 1477384 214016  46464 S  13.3   0.7   1:54.76 cilium-+
    359 root      20   0 1229348   3668   1392 S   0.0   0.0   0:00.04 cilium-+
    691 root      20   0       0      0      0 Z   0.0   0.0   0:00.15 cilium-+
   2020 root      20   0       0      0      0 Z   0.0   0.0   0:00.00 cilium
   7069 root      20   0    4080    964    832 S   0.0   0.0   0:00.01 tar
   7172 root      20   0 1229120   3704   1436 S   0.0   0.0   0:00.00 gops
   7174 root      20   0 1229120   3704   1436 S   0.0   0.0   0:00.00 gops
   7190 root      20   0 1228864   3704   1436 S   0.0   0.0   0:00.00 gops
   7260 root      20   0    7184   1984   1656 R   0.0   0.0   0:00.00 top
   7286 root      20   0 1229120   3704   1436 S   0.0   0.0   0:00.00 gops
   7287 root      20   0 1229120   3652   1380 S   0.0   0.0   0:00.00 gops
   7288 root      20   0 1228864   3704   1436 S   0.0   0.0   0:00.00 gops
   7331 root      20   0    3596    948    820 D   0.0   0.0   0:00.00 bpftool
