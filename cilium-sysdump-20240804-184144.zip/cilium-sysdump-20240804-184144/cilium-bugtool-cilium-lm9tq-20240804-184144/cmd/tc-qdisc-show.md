qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev enp9s0 root 
qdisc fq_codel 0: dev enp9s0 parent :4 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev enp9s0 parent :3 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev enp9s0 parent :2 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev enp9s0 parent :1 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc mq 0: dev enp10s0 root 
qdisc fq_codel 0: dev enp10s0 parent :4 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev enp10s0 parent :3 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev enp10s0 parent :2 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev enp10s0 parent :1 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc noqueue 0: dev lan root refcnt 2 
qdisc clsact ffff: dev lan parent ffff:fff1 
qdisc noqueue 0: dev iot root refcnt 2 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev lxcf228d89e07e3 root refcnt 2 
qdisc clsact ffff: dev lxcf228d89e07e3 parent ffff:fff1 
qdisc noqueue 0: dev lxc5d9688897f63 root refcnt 2 
qdisc clsact ffff: dev lxc5d9688897f63 parent ffff:fff1 
qdisc noqueue 0: dev lxc02b3905a6dfb root refcnt 2 
qdisc clsact ffff: dev lxc02b3905a6dfb parent ffff:fff1 
qdisc noqueue 0: dev lxc859384ae38a5 root refcnt 2 
qdisc clsact ffff: dev lxc859384ae38a5 parent ffff:fff1 
qdisc noqueue 0: dev lxc503b32a2c6a7 root refcnt 2 
qdisc clsact ffff: dev lxc503b32a2c6a7 parent ffff:fff1 
qdisc noqueue 0: dev lxc910004d47ea4 root refcnt 2 
qdisc clsact ffff: dev lxc910004d47ea4 parent ffff:fff1 
qdisc noqueue 0: dev lxce3e3ac922558 root refcnt 2 
qdisc clsact ffff: dev lxce3e3ac922558 parent ffff:fff1 
qdisc noqueue 0: dev lxcbadff7f8234a root refcnt 2 
qdisc clsact ffff: dev lxcbadff7f8234a parent ffff:fff1 
qdisc noqueue 0: dev lxcef0c82914670 root refcnt 2 
qdisc clsact ffff: dev lxcef0c82914670 parent ffff:fff1 
qdisc noqueue 0: dev lxc2b284e5fe4ce root refcnt 2 
qdisc clsact ffff: dev lxc2b284e5fe4ce parent ffff:fff1 
qdisc noqueue 0: dev lxcd458e6709d60 root refcnt 2 
qdisc clsact ffff: dev lxcd458e6709d60 parent ffff:fff1 
qdisc noqueue 0: dev lxc4c920d1320f1 root refcnt 2 
qdisc clsact ffff: dev lxc4c920d1320f1 parent ffff:fff1 
qdisc noqueue 0: dev lxcfd427869bc62 root refcnt 2 
qdisc clsact ffff: dev lxcfd427869bc62 parent ffff:fff1 
qdisc noqueue 0: dev lxce316820ded76 root refcnt 2 
qdisc clsact ffff: dev lxce316820ded76 parent ffff:fff1 
qdisc noqueue 0: dev lxc3b052960bf39 root refcnt 2 
qdisc clsact ffff: dev lxc3b052960bf39 parent ffff:fff1 
qdisc noqueue 0: dev lxc83b895bb0fa9 root refcnt 2 
qdisc clsact ffff: dev lxc83b895bb0fa9 parent ffff:fff1 
qdisc noqueue 0: dev lxcf8bd3ef502c5 root refcnt 2 
qdisc clsact ffff: dev lxcf8bd3ef502c5 parent ffff:fff1 
qdisc noqueue 0: dev lxcbdbcfb757b99 root refcnt 2 
qdisc clsact ffff: dev lxcbdbcfb757b99 parent ffff:fff1 
qdisc noqueue 0: dev lxc3136ad64a403 root refcnt 2 
qdisc clsact ffff: dev lxc3136ad64a403 parent ffff:fff1 
qdisc noqueue 0: dev lxccc2dfd51c9f5 root refcnt 2 
qdisc clsact ffff: dev lxccc2dfd51c9f5 parent ffff:fff1 
qdisc noqueue 0: dev lxcefb5df718e0f root refcnt 2 
qdisc clsact ffff: dev lxcefb5df718e0f parent ffff:fff1 
qdisc noqueue 0: dev lxcb7c0ed9dd42e root refcnt 2 
qdisc clsact ffff: dev lxcb7c0ed9dd42e parent ffff:fff1 
qdisc noqueue 0: dev lxcbf04ad6c9b4a root refcnt 2 
qdisc clsact ffff: dev lxcbf04ad6c9b4a parent ffff:fff1 
qdisc noqueue 0: dev lxca7a944ff01cc root refcnt 2 
qdisc clsact ffff: dev lxca7a944ff01cc parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxcb9692533e4ab root refcnt 2 
qdisc clsact ffff: dev lxcb9692533e4ab parent ffff:fff1 
