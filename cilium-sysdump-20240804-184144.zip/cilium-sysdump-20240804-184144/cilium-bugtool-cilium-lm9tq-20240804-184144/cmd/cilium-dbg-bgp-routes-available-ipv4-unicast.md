VRouter   Prefix   NextHop   Age   Attrs
