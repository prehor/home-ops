filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbf04ad6c9b4a direct-action not_in_hw id 4447 tag 38ed15d2699cb890 jited 
