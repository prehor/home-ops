[
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.10.0.73"
      },
      "ipv6": {}
    },
    "name": "home-storage/h1",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.10.0.0/24",
        "enabled": true,
        "ip": "192.168.1.11"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.10.0.104"
      }
    ],
    "source": "local"
  }
]

