default via 192.168.1.1 dev lan proto kernel onlink 
10.10.0.21 dev lxcefb5df718e0f proto kernel scope link 
10.10.0.25 dev lxc3136ad64a403 proto kernel scope link 
10.10.0.29 dev lxce3e3ac922558 proto kernel scope link 
10.10.0.35 dev lxcf8bd3ef502c5 proto kernel scope link 
10.10.0.36 dev lxc5d9688897f63 proto kernel scope link 
10.10.0.37 dev lxccc2dfd51c9f5 proto kernel scope link 
10.10.0.40 dev lxc3b052960bf39 proto kernel scope link 
10.10.0.51 dev lxcd458e6709d60 proto kernel scope link 
10.10.0.62 dev lxcbadff7f8234a proto kernel scope link 
10.10.0.71 dev lxce316820ded76 proto kernel scope link 
10.10.0.73 dev lxc_health proto kernel scope link 
10.10.0.83 dev lxc02b3905a6dfb proto kernel scope link 
10.10.0.88 dev lxcef0c82914670 proto kernel scope link 
10.10.0.103 dev lxcf228d89e07e3 proto kernel scope link 
10.10.0.114 dev lxcbf04ad6c9b4a proto kernel scope link 
10.10.0.137 dev lxc910004d47ea4 proto kernel scope link 
10.10.0.142 dev lxcb7c0ed9dd42e proto kernel scope link 
10.10.0.148 dev lxca7a944ff01cc proto kernel scope link 
10.10.0.149 dev lxcb9692533e4ab proto kernel scope link 
10.10.0.151 dev lxcbdbcfb757b99 proto kernel scope link 
10.10.0.160 dev lxc83b895bb0fa9 proto kernel scope link 
10.10.0.161 dev lxc4c920d1320f1 proto kernel scope link 
10.10.0.175 dev lxcfd427869bc62 proto kernel scope link 
10.10.0.180 dev lxc2b284e5fe4ce proto kernel scope link 
10.10.0.204 dev lxc859384ae38a5 proto kernel scope link 
10.10.0.234 dev lxc503b32a2c6a7 proto kernel scope link 
192.168.1.0/24 dev lan proto kernel scope link src 192.168.1.11 
192.168.101.0/24 dev iot proto kernel scope link src 192.168.101.11 
