 16:41:44 up  1:16,  0 users,  load average: 0.30, 0.40, 0.50
