[{
        "key": {
            "ip4": 318875840,
            "ifindex": 6
        },
        "value": {
            "responses_sent": 27
        }
    },{
        "key": {
            "ip4": 285321408,
            "ifindex": 6
        },
        "value": {
            "responses_sent": 1
        }
    }
]
