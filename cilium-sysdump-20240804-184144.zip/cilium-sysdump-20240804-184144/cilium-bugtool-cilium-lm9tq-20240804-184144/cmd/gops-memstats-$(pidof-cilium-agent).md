alloc: 87.39MB (91639536 bytes)
total-alloc: 2.30GB (2469089880 bytes)
sys: 162.57MB (170465215 bytes)
lookups: 0
mallocs: 62276020
frees: 61707460
heap-alloc: 87.39MB (91639536 bytes)
heap-sys: 144.56MB (151584768 bytes)
heap-idle: 35.34MB (37052416 bytes)
heap-in-use: 109.23MB (114532352 bytes)
heap-released: 1.27MB (1335296 bytes)
heap-objects: 568560
stack-in-use: 7.38MB (7733248 bytes)
stack-sys: 7.38MB (7733248 bytes)
stack-mspan-inuse: 1.36MB (1422080 bytes)
stack-mspan-sys: 1.96MB (2056320 bytes)
stack-mcache-inuse: 9.38KB (9600 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.47MB (1537450 bytes)
gc-sys: 5.19MB (5447136 bytes)
next-gc: when heap-alloc >= 137.64MB (144321416 bytes)
last-gc: 2024-08-04 16:41:49.590192672 +0000 UTC
gc-pause-total: 11.960753ms
gc-pause: 39720
gc-pause-end: 1722789709590192672
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 6.670537050256588e-05
enable-gc: true
debug-gc: false
