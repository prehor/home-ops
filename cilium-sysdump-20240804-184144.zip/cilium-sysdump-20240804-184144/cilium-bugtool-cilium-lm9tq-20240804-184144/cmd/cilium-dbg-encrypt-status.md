Encryption: Disabled                  
