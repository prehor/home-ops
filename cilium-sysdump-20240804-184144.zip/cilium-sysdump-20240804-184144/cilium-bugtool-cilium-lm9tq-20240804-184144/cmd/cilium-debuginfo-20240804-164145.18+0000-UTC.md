# Cilium debug information

#### Cilium memory map


```
00400000-0316b000 r-xp 00000000 00:30 144582                             /usr/bin/cilium-agent
0316b000-06797000 r--p 02d6b000 00:30 144582                             /usr/bin/cilium-agent
06797000-06934000 rw-p 06397000 00:30 144582                             /usr/bin/cilium-agent
06934000-070f5000 rw-p 00000000 00:00 0 
c000000000-c009800000 rw-p 00000000 00:00 0 
c009800000-c00c000000 ---p 00000000 00:00 0 
7fa85f069000-7fa85f1bd000 rw-p 00000000 00:00 0 
7fa85f1d5000-7fa85f2b6000 rw-p 00000000 00:00 0 
7fa85f2b6000-7fa85f2f7000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f2f7000-7fa85f338000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f338000-7fa85f379000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f379000-7fa85f3ba000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f3ba000-7fa85f3fb000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f3fb000-7fa85f43c000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f43c000-7fa85f47d000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f47d000-7fa85f4be000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f4be000-7fa85f50f000 rw-p 00000000 00:00 0 
7fa85f50f000-7fa85f511000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f511000-7fa85f513000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f513000-7fa85f515000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f515000-7fa85f517000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f517000-7fa85f519000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f519000-7fa85f51b000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f51b000-7fa85f51d000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f51d000-7fa85f51f000 rw-s 00000000 00:0e 54                         anon_inode:[perf_event]
7fa85f51f000-7fa85fbb6000 rw-p 00000000 00:00 0 
7fa85fbb6000-7fa85fcb6000 rw-p 00000000 00:00 0 
7fa85fcb6000-7fa85fcc7000 rw-p 00000000 00:00 0 
7fa85fcc7000-7fa861cc7000 rw-p 00000000 00:00 0 
7fa861cc7000-7fa871e47000 ---p 00000000 00:00 0 
7fa871e47000-7fa871e48000 rw-p 00000000 00:00 0 
7fa871e48000-7fa891e47000 ---p 00000000 00:00 0 
7fa891e47000-7fa891e48000 rw-p 00000000 00:00 0 
7fa891e48000-7fa8a3cf7000 ---p 00000000 00:00 0 
7fa8a3cf7000-7fa8a3cf8000 rw-p 00000000 00:00 0 
7fa8a3cf8000-7fa8a60cd000 ---p 00000000 00:00 0 
7fa8a60cd000-7fa8a60ce000 rw-p 00000000 00:00 0 
7fa8a60ce000-7fa8a6547000 ---p 00000000 00:00 0 
7fa8a6547000-7fa8a6548000 rw-p 00000000 00:00 0 
7fa8a6548000-7fa8a65c7000 ---p 00000000 00:00 0 
7fa8a65c7000-7fa8a6627000 rw-p 00000000 00:00 0 
7ffdcacb8000-7ffdcacd9000 rw-p 00000000 00:00 0                          [stack]
7ffdcad39000-7ffdcad3d000 r--p 00000000 00:00 0                          [vvar]
7ffdcad3d000-7ffdcad3f000 r-xp 00000000 00:00 0                          [vdso]

```


#### Cilium encryption



#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30 (v1.30.2+k3s2) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumLocalRedirectPolicy", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [lan      192.168.1.11 192.168.1.10 fd61:e2c9:ba8b:0:8f4:f8ff:fe8e:5c8c 2a02:768:1b10:ac5e:8f4:f8ff:fe8e:5c8c fe80::8f4:f8ff:fe8e:5c8c (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 8 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 27/254 allocated from 10.10.0.0/24, 
Allocated addresses:
  10.10.0.103 (storage/minio-0 [restored])
  10.10.0.104 (router)
  10.10.0.114 (flux-system/helm-controller-8b6b769d4-9l6gp [restored])
  10.10.0.137 (network/echo-server-7975c47f84-l9pfk [restored])
  10.10.0.142 (cert-manager/cert-manager-cainjector-7477d56b47-p8h82 [restored])
  10.10.0.148 (kube-system/coredns-6799fbcd5-nfdkr [restored])
  10.10.0.149 (kube-system/hubble-relay-f4457696c-r2rg7)
  10.10.0.151 (storage/minio-kes-6777b4676f-j6sfq [restored])
  10.10.0.160 (kube-system/k8tz-6c9d89b4bf-drdcm [restored])
  10.10.0.161 (cert-manager/cert-manager-webhook-6d5cb854fc-gp94j [restored])
  10.10.0.175 (storage/snapshot-controller-6c64f66dc-tmwtc [restored])
  10.10.0.180 (flux-system/kustomize-controller-78b78bf57d-sx42s [restored])
  10.10.0.204 (kube-system/hubble-ui-75f899dc7c-jnphv [restored])
  10.10.0.21 (system-upgrade/system-upgrade-controller-d67784b5b-4rw8c [restored])
  10.10.0.234 (kube-system/reloader-7fb44dcc5f-fmsxj [restored])
  10.10.0.25 (storage/openebs-zfs-localpv-controller-6c66fff5bd-trkl2 [restored])
  10.10.0.29 (network/k8s-gateway-67ff7c6b99-qbzzk [restored])
  10.10.0.35 (storage/snapshot-validation-webhook-5697d649bc-vgwmq [restored])
  10.10.0.36 (kube-system/metrics-server-bc7c58fdf-wnd6t [restored])
  10.10.0.37 (storage/minio-kes-6777b4676f-w866r [restored])
  10.10.0.40 (flux-system/image-reflector-controller-65df777f5c-bwn9d [restored])
  10.10.0.51 (cert-manager/cert-manager-77cdc7956d-xj7vw [restored])
  10.10.0.62 (network/ingress-nginx-internal-controller-5d8459498c-gz5jp [restored])
  10.10.0.71 (flux-system/source-controller-7944c8d8b4-fm8bt [restored])
  10.10.0.73 (health)
  10.10.0.83 (flux-system/image-automation-controller-79447887bb-45xt5 [restored])
  10.10.0.88 (flux-system/notification-controller-685bdc466d-kcqmc [restored])
ClusterMesh:            0/0 remote clusters ready, 0 global-services
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Native   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      176/176 healthy
  Name                                                                        Last success   Last error   Count   Message
  bpf-map-sync-cilium_lxc                                                     6s ago         never        0       no error   
  cilium-health-ep                                                            31s ago        never        0       no error   
  ct-map-pressure                                                             31s ago        never        0       no error   
  daemon-validate-config                                                      55s ago        never        0       no error   
  dns-garbage-collector-job                                                   37s ago        never        0       no error   
  endpoint-1037-regeneration-recovery                                         never          never        0       no error   
  endpoint-1130-regeneration-recovery                                         never          never        0       no error   
  endpoint-1157-regeneration-recovery                                         never          never        0       no error   
  endpoint-1372-regeneration-recovery                                         never          never        0       no error   
  endpoint-1730-regeneration-recovery                                         never          never        0       no error   
  endpoint-1818-regeneration-recovery                                         never          never        0       no error   
  endpoint-1840-regeneration-recovery                                         never          never        0       no error   
  endpoint-2180-regeneration-recovery                                         never          never        0       no error   
  endpoint-2211-regeneration-recovery                                         never          never        0       no error   
  endpoint-2611-regeneration-recovery                                         never          never        0       no error   
  endpoint-265-regeneration-recovery                                          never          never        0       no error   
  endpoint-2708-regeneration-recovery                                         never          never        0       no error   
  endpoint-2776-regeneration-recovery                                         never          never        0       no error   
  endpoint-312-regeneration-recovery                                          never          never        0       no error   
  endpoint-3129-regeneration-recovery                                         never          never        0       no error   
  endpoint-323-regeneration-recovery                                          never          never        0       no error   
  endpoint-3253-regeneration-recovery                                         never          never        0       no error   
  endpoint-338-regeneration-recovery                                          never          never        0       no error   
  endpoint-3601-regeneration-recovery                                         never          never        0       no error   
  endpoint-361-regeneration-recovery                                          never          never        0       no error   
  endpoint-369-regeneration-recovery                                          never          never        0       no error   
  endpoint-3884-regeneration-recovery                                         never          never        0       no error   
  endpoint-3931-regeneration-recovery                                         never          never        0       no error   
  endpoint-745-regeneration-recovery                                          never          never        0       no error   
  endpoint-832-regeneration-recovery                                          never          never        0       no error   
  endpoint-84-regeneration-recovery                                           never          never        0       no error   
  endpoint-889-regeneration-recovery                                          never          never        0       no error   
  endpoint-gc                                                                 3m37s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                        31s ago        never        0       no error   
  ipcache-inject-labels                                                       32s ago        never        0       no error   
  k8s-heartbeat                                                               7s ago         never        0       no error   
  link-cache                                                                  1s ago         never        0       no error   
  node-neighbor-link-updater                                                  1s ago         never        0       no error   
  resolve-identity-1130                                                       3m0s ago       never        0       no error   
  resolve-identity-1372                                                       3m0s ago       never        0       no error   
  resolve-identity-3129                                                       3m0s ago       never        0       no error   
  resolve-identity-3253                                                       3m31s ago      never        0       no error   
  resolve-identity-3601                                                       3m0s ago       never        0       no error   
  resolve-identity-361                                                        3m32s ago      never        0       no error   
  resolve-identity-369                                                        3m0s ago       never        0       no error   
  resolve-identity-84                                                         3m0s ago       never        0       no error   
  resolve-labels-/                                                            38m32s ago     never        0       no error   
  resolve-labels-cert-manager/cert-manager-77cdc7956d-xj7vw                   38m27s ago     never        0       no error   
  resolve-labels-cert-manager/cert-manager-cainjector-7477d56b47-p8h82        38m27s ago     never        0       no error   
  resolve-labels-cert-manager/cert-manager-webhook-6d5cb854fc-gp94j           38m27s ago     never        0       no error   
  resolve-labels-flux-system/helm-controller-8b6b769d4-9l6gp                  38m27s ago     never        0       no error   
  resolve-labels-flux-system/image-automation-controller-79447887bb-45xt5     38m27s ago     never        0       no error   
  resolve-labels-flux-system/image-reflector-controller-65df777f5c-bwn9d      38m27s ago     never        0       no error   
  resolve-labels-flux-system/kustomize-controller-78b78bf57d-sx42s            38m27s ago     never        0       no error   
  resolve-labels-flux-system/notification-controller-685bdc466d-kcqmc         38m27s ago     never        0       no error   
  resolve-labels-flux-system/source-controller-7944c8d8b4-fm8bt               38m27s ago     never        0       no error   
  resolve-labels-kube-system/coredns-6799fbcd5-nfdkr                          38m27s ago     never        0       no error   
  resolve-labels-kube-system/hubble-relay-f4457696c-r2rg7                     38m32s ago     never        0       no error   
  resolve-labels-kube-system/hubble-ui-75f899dc7c-jnphv                       38m27s ago     never        0       no error   
  resolve-labels-kube-system/k8tz-6c9d89b4bf-drdcm                            38m27s ago     never        0       no error   
  resolve-labels-kube-system/metrics-server-bc7c58fdf-wnd6t                   38m27s ago     never        0       no error   
  resolve-labels-kube-system/reloader-7fb44dcc5f-fmsxj                        38m27s ago     never        0       no error   
  resolve-labels-network/echo-server-7975c47f84-l9pfk                         38m27s ago     never        0       no error   
  resolve-labels-network/ingress-nginx-internal-controller-5d8459498c-gz5jp   38m27s ago     never        0       no error   
  resolve-labels-network/k8s-gateway-67ff7c6b99-qbzzk                         38m27s ago     never        0       no error   
  resolve-labels-storage/minio-0                                              38m27s ago     never        0       no error   
  resolve-labels-storage/minio-kes-6777b4676f-j6sfq                           38m27s ago     never        0       no error   
  resolve-labels-storage/minio-kes-6777b4676f-w866r                           38m27s ago     never        0       no error   
  resolve-labels-storage/openebs-zfs-localpv-controller-6c66fff5bd-trkl2      38m27s ago     never        0       no error   
  resolve-labels-storage/snapshot-controller-6c64f66dc-tmwtc                  38m27s ago     never        0       no error   
  resolve-labels-storage/snapshot-validation-webhook-5697d649bc-vgwmq         38m27s ago     never        0       no error   
  resolve-labels-system-upgrade/system-upgrade-controller-d67784b5b-4rw8c     38m27s ago     never        0       no error   
  restoring-ep-identity (1037)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (1130)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (1157)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (1372)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (1730)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (1818)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (1840)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (2180)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (2211)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (2611)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (265)                                                 38m32s ago     never        0       no error   
  restoring-ep-identity (2708)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (2776)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (312)                                                 38m32s ago     never        0       no error   
  restoring-ep-identity (3129)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (323)                                                 38m32s ago     never        0       no error   
  restoring-ep-identity (338)                                                 38m32s ago     never        0       no error   
  restoring-ep-identity (3601)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (369)                                                 38m32s ago     never        0       no error   
  restoring-ep-identity (3884)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (3931)                                                38m32s ago     never        0       no error   
  restoring-ep-identity (745)                                                 38m32s ago     never        0       no error   
  restoring-ep-identity (832)                                                 38m32s ago     never        0       no error   
  restoring-ep-identity (84)                                                  38m32s ago     never        0       no error   
  restoring-ep-identity (889)                                                 38m32s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                              38m32s ago     never        0       no error   
  sync-policymap-1037                                                         8m28s ago      never        0       no error   
  sync-policymap-1130                                                         8m27s ago      never        0       no error   
  sync-policymap-1157                                                         8m27s ago      never        0       no error   
  sync-policymap-1372                                                         8m27s ago      never        0       no error   
  sync-policymap-1730                                                         8m27s ago      never        0       no error   
  sync-policymap-1818                                                         8m28s ago      never        0       no error   
  sync-policymap-1840                                                         8m28s ago      never        0       no error   
  sync-policymap-2180                                                         8m28s ago      never        0       no error   
  sync-policymap-2211                                                         8m28s ago      never        0       no error   
  sync-policymap-2611                                                         8m27s ago      never        0       no error   
  sync-policymap-265                                                          8m27s ago      never        0       no error   
  sync-policymap-2708                                                         8m27s ago      never        0       no error   
  sync-policymap-2776                                                         8m28s ago      never        0       no error   
  sync-policymap-312                                                          8m28s ago      never        0       no error   
  sync-policymap-3129                                                         8m28s ago      never        0       no error   
  sync-policymap-323                                                          8m27s ago      never        0       no error   
  sync-policymap-3253                                                         8m27s ago      never        0       no error   
  sync-policymap-338                                                          8m28s ago      never        0       no error   
  sync-policymap-3601                                                         8m28s ago      never        0       no error   
  sync-policymap-361                                                          8m27s ago      never        0       no error   
  sync-policymap-369                                                          8m28s ago      never        0       no error   
  sync-policymap-3884                                                         8m27s ago      never        0       no error   
  sync-policymap-3931                                                         8m28s ago      never        0       no error   
  sync-policymap-745                                                          8m29s ago      never        0       no error   
  sync-policymap-832                                                          8m27s ago      never        0       no error   
  sync-policymap-84                                                           8m28s ago      never        0       no error   
  sync-policymap-889                                                          8m28s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1037)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1130)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1157)                                           9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1372)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1730)                                           9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1818)                                           9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1840)                                           8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2180)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2211)                                           9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2611)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (265)                                            10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2708)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2776)                                           8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (312)                                            10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3129)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (323)                                            9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (338)                                            9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3601)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (361)                                            8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (369)                                            10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3884)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3931)                                           8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (832)                                            8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (84)                                             10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (889)                                            9s ago         never        0       no error   
  sync-utime                                                                  32s ago        never        0       no error   
  waiting-initial-global-identities-ep (1037)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (1130)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (1157)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (1372)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (1730)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (1818)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (1840)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (2180)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (2211)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (2611)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (265)                                  38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (2708)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (2776)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (312)                                  38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (3129)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (323)                                  38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (338)                                  38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (3601)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (369)                                  38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (3884)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (3931)                                 38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (832)                                  38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (84)                                   38m32s ago     never        0       no error   
  waiting-initial-global-identities-ep (889)                                  38m32s ago     never        0       no error   
  write-cni-file                                                              38m37s ago     never        0       no error   
Proxy Status:            OK, ip 10.10.0.104, 0 redirects active on ports 10000-20000, Envoy: embedded
Global Identity Range:   min 65536, max 131071
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 67.03   Metrics: Ok
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                lan      192.168.1.11 192.168.1.10 fd61:e2c9:ba8b:0:8f4:f8ff:fe8e:5c8c 2a02:768:1b10:ac5e:8f4:f8ff:fe8e:5c8c fe80::8f4:f8ff:fe8e:5c8c (Direct Routing)
  Mode:                   Hybrid
    DSR Dispatch Mode:    IP Option/Extension
  Backend Selection:      Maglev (Table Size: 16381)
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   147297
  TCP connection tracking       294595
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           294595
  Neighbor table                294595
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              147297
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
mtu:0
enable-host-firewall:false
config-sources:config-map:kube-system/cilium-config
enable-xdp-prefilter:false
synchronize-k8s-nodes:true
enable-masquerade-to-route-source:false
wireguard-persistent-keepalive:0s
hubble-metrics:dns:query drop tcp flow port-distribution icmp http
local-max-addr-scope:252
hubble-export-allowlist:
hubble-drop-events:false
identity-gc-interval:15m0s
kvstore:
srv6-encap-mode:reduced
service-no-backend-response:reject
conntrack-gc-interval:0s
socket-path:/var/run/cilium/cilium.sock
restore:true
bpf-ct-timeout-regular-tcp:2h13m20s
disable-external-ip-mitigation:false
vtep-mask:
enable-route-mtu-for-cni-chaining:false
ipam-cilium-node-update-rate:15s
hubble-export-file-max-size-mb:10
bpf-lb-maglev-map-max:0
enable-node-port:false
kvstore-max-consecutive-quorum-errors:2
hubble-drop-events-reasons:auth_required,policy_denied
bpf-map-event-buffers:
ipsec-key-file:
proxy-xff-num-trusted-hops-egress:0
enable-nat46x64-gateway:false
ipam:kubernetes
bgp-secrets-namespace:kube-system
ipv6-node:auto
custom-cni-conf:false
arping-refresh-period:30s
enable-l7-proxy:true
enable-encryption-strict-mode:false
annotate-k8s-node:false
hubble-event-queue-size:0
hubble-redact-http-urlquery:false
enable-k8s-networkpolicy:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
http-retry-timeout:0
hubble-export-denylist:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
ipv6-pod-subnets:
hubble-listen-address::4244
cmdref:
enable-hubble-open-metrics:false
trace-payloadlen:128
dnsproxy-lock-count:131
enable-local-redirect-policy:true
vtep-cidr:
tofqdns-proxy-response-max-delay:100ms
disable-envoy-version-check:false
cni-external-routing:false
enable-bandwidth-manager:false
bpf-ct-timeout-regular-any:1m0s
enable-ipsec-xfrm-state-caching:true
bpf-ct-timeout-regular-tcp-syn:1m0s
multicast-enabled:false
k8s-require-ipv4-pod-cidr:false
ipv4-native-routing-cidr:10.10.0.0/16
k8s-client-qps:10
egress-gateway-policy-map-max:16384
install-iptables-rules:true
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-runtime-device-detection:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
controller-group-metrics:write-cni-file sync-host-ips sync-lb-maps-with-k8s-services
dnsproxy-lock-timeout:500ms
log-driver:
unmanaged-pod-watcher-interval:15
cilium-endpoint-gc-interval:5m0s
mke-cgroup-mount:
enable-ipv4-masquerade:true
clustermesh-enable-mcs-api:false
hubble-export-file-path:
hubble-event-buffer-capacity:4095
bpf-lb-rss-ipv4-src-cidr:
bpf-lb-algorithm:maglev
proxy-max-requests-per-connection:0
k8s-api-server:
tofqdns-proxy-port:0
k8s-namespace:kube-system
enable-host-legacy-routing:false
encryption-strict-mode-allow-remote-node-identities:false
endpoint-bpf-prog-watchdog-interval:30s
dnsproxy-concurrency-limit:0
hubble-metrics-server-enable-tls:false
envoy-base-id:0
bpf-ct-global-any-max:262144
hubble-export-file-compress:false
kvstore-lease-ttl:15m0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
tofqdns-endpoint-max-ip-per-hostname:50
node-labels:
disable-endpoint-crd:false
proxy-connect-timeout:2
ipv6-range:auto
hubble-metrics-server::9965
bpf-ct-global-tcp-max:524288
tunnel-protocol:vxlan
pprof-address:localhost
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-ipv4-fragment-tracking:true
hubble-redact-http-headers-allow:
kvstore-opt:
bpf-lb-map-max:65536
bpf-events-trace-enabled:true
hubble-socket-path:/var/run/cilium/hubble.sock
enable-l2-neigh-discovery:true
bpf-lb-rev-nat-map-max:0
cluster-name:home-storage
proxy-gid:1337
cni-exclusive:false
kvstore-periodic-sync:5m0s
policy-accounting:true
node-port-mode:snat
l2-announcements-renew-deadline:60s
enable-custom-calls:false
clustermesh-enable-endpoint-sync:false
endpoint-gc-interval:5m0s
hubble-export-file-max-backups:5
enable-active-connection-tracking:false
max-internal-timer-delay:0s
encryption-strict-mode-cidr:
monitor-aggregation-flags:all
ipv4-service-range:auto
enable-tcx:true
nat-map-stats-interval:30s
bpf-lb-sock-terminate-pod-connections:false
enable-health-check-nodeport:true
static-cnp-path:
allow-localhost:auto
kvstore-connectivity-timeout:2m0s
dnsproxy-concurrency-processing-grace-period:0s
bpf-ct-timeout-service-tcp-grace:1m0s
cni-chaining-target:
http-idle-timeout:0
enable-bgp-control-plane:true
devices:lan
prepend-iptables-chains:true
enable-policy:default
operator-prometheus-serve-addr::9963
vtep-endpoint:
ipv4-node:auto
enable-ipsec:false
enable-l2-announcements:true
proxy-admin-port:0
enable-external-ips:false
enable-node-selector-labels:false
proxy-max-connection-duration-seconds:0
lib-dir:/var/lib/cilium
node-port-algorithm:random
http-request-timeout:3600
disable-iptables-feeder-rules:
bpf-lb-acceleration:disabled
auto-create-cilium-node-resource:true
policy-audit-mode:false
exclude-local-address:
vtep-mac:
nodes-gc-interval:5m0s
ingress-secrets-namespace:
preallocate-bpf-maps:false
crd-wait-timeout:5m0s
nat-map-stats-entries:32
cni-chaining-mode:none
mesh-auth-spiffe-trust-domain:spiffe.cilium
tofqdns-idle-connection-grace-period:0s
set-cilium-node-taints:true
enable-mke:false
enable-ipv4-egress-gateway:false
bpf-root:/sys/fs/bpf
direct-routing-skip-unreachable:false
bgp-announce-lb-ip:false
enable-icmp-rules:true
enable-k8s-terminating-endpoint:true
nodeport-addresses:
remove-cilium-node-taints:true
hubble-redact-http-userinfo:true
certificates-directory:/var/run/cilium/certs
node-port-bind-protection:true
cluster-id:1
force-device-detection:false
vlan-bpf-bypass:0
identity-allocation-mode:crd
hubble-drop-events-interval:2m0s
proxy-portrange-min:10000
monitor-queue-size:0
policy-queue-size:100
enable-l2-pod-announcements:false
bpf-lb-service-map-max:0
bpf-lb-source-range-map-max:0
enable-sctp:false
bpf-ct-timeout-regular-tcp-fin:10s
bpf-lb-dsr-l4-xlate:frontend
l2-pod-announcements-interface:
hubble-flowlogs-config-path:
mesh-auth-mutual-listener-port:0
tofqdns-max-deferred-connection-deletes:10000
enable-metrics:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
log-opt:
dnsproxy-insecure-skip-transparent-mode-check:false
node-port-range:
enable-cilium-health-api-server-access:
cgroup-root:/sys/fs/cgroup
install-no-conntrack-iptables-rules:false
tunnel-port:0
l2-announcements-retry-period:10s
encrypt-node:false
bpf-lb-external-clusterip:false
enable-envoy-config:false
http-retry-count:3
egress-masquerade-interfaces:
k8s-client-burst:20
k8s-client-connection-keep-alive:30s
enable-ipv6-ndp:false
iptables-random-fully:false
hubble-redact-kafka-apikey:false
version:false
http-normalize-path:true
fixed-identity-mapping:
clustermesh-ip-identities-sync-timeout:1m0s
enable-wireguard-userspace-fallback:false
mesh-auth-signal-backoff-duration:1s
enable-recorder:false
ipv6-mcast-device:
enable-svc-source-range-check:true
enable-well-known-identities:false
hubble-export-fieldmask:
ipam-default-ip-pool:default
tofqdns-pre-cache:
k8s-heartbeat-timeout:30s
datapath-mode:veth
dnsproxy-socket-linger-timeout:10
external-envoy-proxy:false
enable-pmtu-discovery:false
k8s-kubeconfig-path:
ipam-multi-pool-pre-allocation:
state-dir:/var/run/cilium
mesh-auth-spire-admin-socket:
bpf-fragments-map-max:8192
enable-health-checking:true
hubble-redact-http-headers-deny:
ipv6-cluster-alloc-cidr:f00d::/64
cni-log-file:/var/run/cilium/cilium-cni.log
enable-k8s:true
k8s-client-connection-timeout:30s
dns-max-ips-per-restored-rule:1000
k8s-require-ipv6-pod-cidr:false
envoy-secrets-namespace:
bpf-ct-timeout-service-any:1m0s
enable-ipsec-key-watcher:true
cflags:
bpf-events-drop-enabled:true
envoy-config-retry-interval:15s
enable-ipv4-big-tcp:false
bpf-ct-timeout-service-tcp:2h13m20s
hubble-monitor-events:
operator-api-serve-addr:127.0.0.1:9234
enable-monitor:true
tofqdns-dns-reject-response-code:refused
use-full-tls-context:false
read-cni-conf:
procfs:/host/proc
mesh-auth-gc-interval:5m0s
enable-ipsec-encrypted-overlay:false
enable-unreachable-routes:false
enable-ipv6-masquerade:true
enable-ipv4:true
clustermesh-sync-timeout:1m0s
enable-k8s-api-discovery:false
k8s-service-cache-size:128
iptables-lock-timeout:5s
tofqdns-min-ttl:0
local-router-ipv4:
bpf-lb-sock-hostns-only:false
fqdn-regex-compile-lru-size:1024
agent-labels:
ipv4-range:auto
hubble-skip-unknown-cgroup-ids:true
enable-session-affinity:false
node-port-acceleration:disabled
bgp-announce-pod-cidr:false
http-max-grpc-timeout:0
config-dir:/tmp/cilium/config-map
enable-service-topology:false
local-router-ipv6:
bpf-sock-rev-map-max:262144
bpf-lb-service-backend-map-max:0
enable-hubble:true
enable-endpoint-health-checking:true
proxy-portrange-max:20000
conntrack-gc-max-interval:0s
mesh-auth-queue-size:1024
bpf-lb-affinity-map-max:0
max-connected-clusters:255
label-prefix-file:
proxy-prometheus-port:9964
gops-port:9890
gateway-api-secrets-namespace:
kube-proxy-replacement:true
policy-trigger-interval:1s
enable-k8s-endpoint-slice:true
debug-verbose:
egress-multi-home-ip-rule-compat:false
monitor-aggregation:medium
agent-liveness-update-interval:1s
api-rate-limit:
enable-local-node-route:true
bpf-node-map-max:16384
enable-host-port:false
cluster-health-port:4240
hubble-recorder-sink-queue-size:1024
enable-ipip-termination:false
enable-ingress-controller:false
bypass-ip-availability-upon-restore:false
enable-high-scale-ipcache:false
labels:
auto-direct-node-routes:true
bpf-lb-maglev-table-size:16381
enable-bpf-masquerade:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
mesh-auth-enabled:true
mesh-auth-mutual-connect-timeout:5s
bpf-events-policy-verdict-enabled:true
identity-change-grace-period:5s
enable-bpf-tproxy:false
dnsproxy-enable-transparent-mode:true
bpf-filter-priority:1
enable-cilium-api-server-access:
bpf-auth-map-max:524288
enable-ipv6:false
enable-hubble-recorder-api:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
routing-mode:native
enable-wireguard:false
proxy-xff-num-trusted-hops-ingress:0
k8s-service-proxy-name:
bpf-policy-map-full-reconciliation-interval:15m0s
envoy-config-timeout:2m0s
l2-announcements-lease-duration:300s
enable-ip-masq-agent:false
debug:false
hubble-disable-tls:false
bpf-lb-rss-ipv6-src-cidr:
ipv6-native-routing-cidr:
pprof:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
bpf-policy-map-max:16384
ipv4-pod-subnets:
ipv6-service-range:auto
derive-masq-ip-addr-from-device:
enable-stale-cilium-endpoint-cleanup:true
set-cilium-is-up-condition:true
prometheus-serve-addr::9962
enable-bbr:false
endpoint-queue-size:25
proxy-idle-timeout-seconds:60
bpf-map-dynamic-size-ratio:0.0025
identity-heartbeat-timeout:30m0s
bpf-lb-sock:false
allow-icmp-frag-needed:true
container-ip-local-reserved-ports:auto
monitor-aggregation-interval:5s
ipsec-key-rotation-duration:5m0s
enable-tracing:false
bpf-lb-mode:hybrid
policy-cidr-match-mode:
bpf-lb-dsr-dispatch:opt
enable-auto-protect-node-port-range:true
use-cilium-internal-ip-for-ipsec:false
enable-bpf-clock-probe:false
enable-identity-mark:true
enable-ipv6-big-tcp:false
ipv4-service-loopback-address:169.254.42.1
k8s-sync-timeout:3m0s
log-system-load:false
mesh-auth-rotated-identities-queue-size:1024
envoy-log:
enable-vtep:false
exclude-node-label-patterns:
join-cluster:false
enable-srv6:false
keep-config:false
clustermesh-config:/var/lib/cilium/clustermesh/
allocator-list-timeout:3m0s
egress-gateway-reconciliation-trigger-interval:1s
hubble-redact-enabled:false
envoy-keep-cap-netbindservice:false
config:
metrics:
kube-proxy-replacement-healthz-bind-address:0.0.0.0:10256
enable-health-check-loadbalancer-ip:false
enable-endpoint-routes:true
identity-restore-grace-period:30s
bpf-neigh-global-max:524288
tofqdns-enable-dns-compression:true
encrypt-interface:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
dns-policy-unload-on-shutdown:false
hubble-prefer-ipv6:false
enable-cilium-endpoint-slice:false
pprof-port:6060
enable-xt-socket-fallback:true
agent-health-port:9879
direct-routing-device:
enable-gateway-api:false
route-metric:0
trace-sock:true
max-controller-interval:0
bpf-nat-global-max:524288
```


#### Service list

```
ID   Frontend             Service Type   Backend                           
1    10.11.186.206:9402   ClusterIP      1 => 10.10.0.51:9402 (active)     
2    10.11.234.10:443     ClusterIP      1 => 10.10.0.161:10250 (active)   
3    10.11.0.1:443        ClusterIP      1 => 192.168.1.11:6443 (active)   
4    10.11.233.8:80       ClusterIP      1 => 10.10.0.88:9090 (active)     
5    10.11.167.174:80     ClusterIP      1 => 10.10.0.71:9090 (active)     
6    10.11.160.141:80     ClusterIP      1 => 10.10.0.88:9292 (active)     
7    10.11.88.204:443     ClusterIP      1 => 192.168.1.11:4244 (active)   
8    10.11.194.196:80     ClusterIP      1 => 10.10.0.149:4245 (active)    
9    10.11.213.89:80      ClusterIP      1 => 10.10.0.204:8081 (active)    
10   10.11.207.131:443    ClusterIP      1 => 10.10.0.160:8443 (active)    
11   10.11.0.10:53        ClusterIP      1 => 10.10.0.148:53 (active)      
12   10.11.0.10:9153      ClusterIP      1 => 10.10.0.148:9153 (active)    
13   10.11.117.252:443    ClusterIP      1 => 10.10.0.36:10250 (active)    
14   10.11.43.95:8080     ClusterIP      1 => 10.10.0.137:8080 (active)    
15   10.11.200.111:443    ClusterIP      1 => 10.10.0.62:8443 (active)     
16   10.11.20.152:80      ClusterIP      1 => 10.10.0.62:80 (active)       
17   10.11.20.152:443     ClusterIP      1 => 10.10.0.62:443 (active)      
18   192.168.1.17:443     LoadBalancer   1 => 10.10.0.62:443 (active)      
19   192.168.1.17:80      LoadBalancer   1 => 10.10.0.62:80 (active)       
21   0.0.0.0:30571        NodePort       1 => 10.10.0.62:80 (active)       
23   0.0.0.0:30681        NodePort       1 => 10.10.0.62:443 (active)      
24   10.11.45.147:10254   ClusterIP      1 => 10.10.0.62:10254 (active)    
25   10.11.240.226:53     ClusterIP      1 => 10.10.0.29:1053 (active)     
26   192.168.1.19:53      LoadBalancer   1 => 10.10.0.29:1053 (active)     
28   0.0.0.0:32726        NodePort       1 => 10.10.0.29:1053 (active)     
29   10.11.167.155:7373   ClusterIP      1 => 10.10.0.37:7373 (active)     
                                         2 => 10.10.0.151:7373 (active)    
30   10.11.182.189:9000   ClusterIP      1 => 10.10.0.103:9000 (active)    
31   10.11.182.189:9001   ClusterIP      1 => 10.10.0.103:9001 (active)    
32   10.11.75.113:443     ClusterIP      1 => 10.10.0.35:8443 (active)     
42   192.168.1.11:30571   NodePort       1 => 10.10.0.62:80 (active)       
43   192.168.1.11:30681   NodePort       1 => 10.10.0.62:443 (active)      
44   192.168.1.11:32726   NodePort       1 => 10.10.0.29:1053 (active)     
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/amd64
```


#### Kernel version

```
6.1.0
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                                       IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                                         
84         Disabled           Disabled          97006      k8s:app=source-controller                                                                                10.10.0.71    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux                                                              
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest                                              
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=source-controller                                                                      
                                                           k8s:io.kubernetes.pod.namespace=flux-system                                                                                    
265        Disabled           Disabled          75356      k8s:app.kubernetes.io/component=echo-server                                                              10.10.0.137   ready   
                                                           k8s:app.kubernetes.io/instance=echo-server                                                                                     
                                                           k8s:app.kubernetes.io/name=echo-server                                                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                                                
                                                           k8s:io.kubernetes.pod.namespace=network                                                                                        
312        Disabled           Disabled          68452      k8s:app=openebs-zfs-controller                                                                           10.10.0.25    ready   
                                                           k8s:chart=zfs-localpv-2.6.0                                                                                                    
                                                           k8s:component=openebs-zfs-controller                                                                                           
                                                           k8s:heritage=Helm                                                                                                              
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-zfs-controller-sa                                                              
                                                           k8s:io.kubernetes.pod.namespace=storage                                                                                        
                                                           k8s:name=openebs-zfs-controller                                                                                                
                                                           k8s:openebs.io/component-name=openebs-zfs-controller                                                                           
                                                           k8s:openebs.io/version=2.6.0                                                                                                   
                                                           k8s:release=openebs                                                                                                            
                                                           k8s:role=openebs-zfs                                                                                                           
323        Disabled           Disabled          116209     k8s:app.kubernetes.io/instance=k8tz                                                                      10.10.0.160   ready   
                                                           k8s:app.kubernetes.io/name=k8tz                                                                                                
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=k8tz                                                                                   
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                                    
338        Disabled           Disabled          99246      k8s:app.kubernetes.io/instance=metrics-server                                                            10.10.0.36    ready   
                                                           k8s:app.kubernetes.io/name=metrics-server                                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=metrics-server                                                                         
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                                    
361        Disabled           Disabled          81099      k8s:app.kubernetes.io/name=hubble-relay                                                                  10.10.0.149   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay                                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                                    
                                                           k8s:k8s-app=hubble-relay                                                                                                       
369        Disabled           Disabled          67060      k8s:app=helm-controller                                                                                  10.10.0.114   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux                                                              
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest                                              
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=helm-controller                                                                        
                                                           k8s:io.kubernetes.pod.namespace=flux-system                                                                                    
745        Disabled           Disabled          1          k8s:node-role.kubernetes.io/control-plane=true                                                                         ready   
                                                           k8s:node-role.kubernetes.io/etcd=true                                                                                          
                                                           k8s:node-role.kubernetes.io/master=true                                                                                        
                                                           k8s:openebs.io/nodeid=h1                                                                                                       
                                                           k8s:openebs.io/nodename=h1                                                                                                     
                                                           k8s:p2p.k3s.cattle.io/enabled=true                                                                                             
                                                           k8s:plan.upgrade.cattle.io/controllers=a3f533021e792ff6d664f5d8e5c5b2e0bb1680ccdb03404f2c544f68                                
                                                           reserved:host                                                                                                                  
832        Disabled           Disabled          80885      k8s:app.kubernetes.io/instance=snapshot-controller                                                       10.10.0.35    ready   
                                                           k8s:app.kubernetes.io/name=snapshot-validation-webhook                                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=snapshot-validation-webhook                                                            
                                                           k8s:io.kubernetes.pod.namespace=storage                                                                                        
889        Disabled           Disabled          124930     k8s:app.kubernetes.io/component=controller                                                               10.10.0.62    ready   
                                                           k8s:app.kubernetes.io/instance=ingress-nginx-internal                                                                          
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                                          
                                                           k8s:app.kubernetes.io/name=ingress-nginx                                                                                       
                                                           k8s:app.kubernetes.io/part-of=ingress-nginx                                                                                    
                                                           k8s:app.kubernetes.io/version=1.11.1                                                                                           
                                                           k8s:helm.sh/chart=ingress-nginx-4.11.1                                                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=ingress-nginx-internal                                                                 
                                                           k8s:io.kubernetes.pod.namespace=network                                                                                        
1037       Disabled           Disabled          68187      k8s:app.kubernetes.io/instance=k8s-gateway                                                               10.10.0.29    ready   
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                                          
                                                           k8s:app.kubernetes.io/name=k8s-gateway                                                                                         
                                                           k8s:app.kubernetes.io/version=0.4.0                                                                                            
                                                           k8s:helm.sh/chart=k8s-gateway-2.4.0                                                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=k8s-gateway                                                                            
                                                           k8s:io.kubernetes.pod.namespace=network                                                                                        
1130       Disabled           Disabled          77832      k8s:app=kustomize-controller                                                                             10.10.0.180   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux                                                              
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest                                              
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=kustomize-controller                                                                   
                                                           k8s:io.kubernetes.pod.namespace=flux-system                                                                                    
1157       Disabled           Disabled          126091     k8s:app.kubernetes.io/name=hubble-ui                                                                     10.10.0.204   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui                                                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                                    
                                                           k8s:k8s-app=hubble-ui                                                                                                          
1372       Disabled           Disabled          68728      k8s:app=image-reflector-controller                                                                       10.10.0.40    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux                                                              
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest                                              
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=image-reflector-controller                                                             
                                                           k8s:io.kubernetes.pod.namespace=flux-system                                                                                    
1730       Disabled           Disabled          119669     k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               10.10.0.148   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                                                
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                                    
                                                           k8s:k8s-app=kube-dns                                                                                                           
1818       Disabled           Disabled          74727      k8s:app.kubernetes.io/component=controller                                                               10.10.0.51    ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                                    
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                                          
                                                           k8s:app.kubernetes.io/name=cert-manager                                                                                        
                                                           k8s:app.kubernetes.io/version=v1.15.1                                                                                          
                                                           k8s:app=cert-manager                                                                                                           
                                                           k8s:helm.sh/chart=cert-manager-v1.15.1                                                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                                    
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager                                                                           
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                                   
1840       Disabled           Disabled          87680      k8s:app.kubernetes.io/managed-by=Helm                                                                    10.10.0.234   ready   
                                                           k8s:app=reloader                                                                                                               
                                                           k8s:chart=reloader-1.0.119                                                                                                     
                                                           k8s:group=com.stakater.platform                                                                                                
                                                           k8s:heritage=Helm                                                                                                              
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=reloader                                                                               
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                                    
                                                           k8s:provider=stakater                                                                                                          
                                                           k8s:release=reloader                                                                                                           
                                                           k8s:version=v1.0.119                                                                                                           
2180       Disabled           Disabled          120519     k8s:app.kubernetes.io/component=system-upgrade-controller                                                10.10.0.21    ready   
                                                           k8s:app.kubernetes.io/instance=system-upgrade-controller                                                                       
                                                           k8s:app.kubernetes.io/name=system-upgrade-controller                                                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=system-upgrade                                                  
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=system-upgrade                                                                         
                                                           k8s:io.kubernetes.pod.namespace=system-upgrade                                                                                 
2211       Disabled           Disabled          73986      k8s:app.kubernetes.io/component=webhook                                                                  10.10.0.161   ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                                    
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                                          
                                                           k8s:app.kubernetes.io/name=webhook                                                                                             
                                                           k8s:app.kubernetes.io/version=v1.15.1                                                                                          
                                                           k8s:app=webhook                                                                                                                
                                                           k8s:helm.sh/chart=cert-manager-v1.15.1                                                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                                    
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook                                                                   
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                                   
2611       Disabled           Disabled          67967      k8s:app.kubernetes.io/component=cainjector                                                               10.10.0.142   ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                                    
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                                          
                                                           k8s:app.kubernetes.io/name=cainjector                                                                                          
                                                           k8s:app.kubernetes.io/version=v1.15.1                                                                                          
                                                           k8s:app=cainjector                                                                                                             
                                                           k8s:helm.sh/chart=cert-manager-v1.15.1                                                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                                    
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector                                                                
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                                   
2708       Disabled           Disabled          78979      k8s:app.kubernetes.io/component=minio-kes                                                                10.10.0.151   ready   
                                                           k8s:app.kubernetes.io/instance=minio-kes                                                                                       
                                                           k8s:app.kubernetes.io/name=minio-kes                                                                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                                                
                                                           k8s:io.kubernetes.pod.namespace=storage                                                                                        
2776       Disabled           Disabled          103831     k8s:app.kubernetes.io/instance=snapshot-controller                                                       10.10.0.175   ready   
                                                           k8s:app.kubernetes.io/name=snapshot-controller                                                                                 
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=snapshot-controller                                                                    
                                                           k8s:io.kubernetes.pod.namespace=storage                                                                                        
3129       Disabled           Disabled          108192     k8s:app=image-automation-controller                                                                      10.10.0.83    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux                                                              
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest                                              
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=image-automation-controller                                                            
                                                           k8s:io.kubernetes.pod.namespace=flux-system                                                                                    
3253       Disabled           Disabled          4          reserved:health                                                                                          10.10.0.73    ready   
3601       Disabled           Disabled          103395     k8s:app=notification-controller                                                                          10.10.0.88    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux                                                              
                                                           k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0                                                            
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest                                              
                                                           k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=notification-controller                                                                
                                                           k8s:io.kubernetes.pod.namespace=flux-system                                                                                    
3884       Disabled           Disabled          78979      k8s:app.kubernetes.io/component=minio-kes                                                                10.10.0.37    ready   
                                                           k8s:app.kubernetes.io/instance=minio-kes                                                                                       
                                                           k8s:app.kubernetes.io/name=minio-kes                                                                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                                                
                                                           k8s:io.kubernetes.pod.namespace=storage                                                                                        
3931       Disabled           Disabled          76802      k8s:app.kubernetes.io/component=minio                                                                    10.10.0.103   ready   
                                                           k8s:app.kubernetes.io/instance=minio                                                                                           
                                                           k8s:app.kubernetes.io/name=minio                                                                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps                                               
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system                                           
                                                           k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled                                                  
                                                           k8s:io.cilium.k8s.policy.cluster=home-storage                                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                                                
                                                           k8s:io.kubernetes.pod.namespace=storage                                                                                        
```

#### BPF Policy Get 84

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    310796    4051      0        
Allow    Ingress     1          ANY          NONE         disabled    433209    5010      0        
Allow    Egress      0          ANY          NONE         disabled    1408239   7417      0        

```


#### BPF CT List 84

```
Invalid argument: unknown type 84
```


#### Endpoint Get 84

```
[
  {
    "id": 84,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
        ]
      },
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-84-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "76677795-99da-4789-abe9-17a5334999c3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-84",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:38:44.490Z",
            "success-count": 8
          },
          "uuid": "e01996fd-616a-4b7f-8af1-6c2d708b88ad"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-flux-system/source-controller-7944c8d8b4-fm8bt",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.288Z",
            "success-count": 2
          },
          "uuid": "ff38fbe7-c8fc-4424-a014-c1160cb6f131"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (84)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "58d22d63-b7d3-47ed-afea-48280cf19fc6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-84",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:16.277Z",
            "success-count": 3
          },
          "uuid": "7aaa1bf1-1b45-4e10-9398-cd4d7cf71b47"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (84)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.602Z",
            "success-count": 233
          },
          "uuid": "a5d72249-02a8-4cb4-983e-ac8fd4219346"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (84)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "850e9069-8acd-4b74-9d56-424f9bce1ef4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0f35832e3a2178e726665c83e8836f58019980085ca7b89b3795b720f1b05550:eth0",
        "container-id": "0f35832e3a2178e726665c83e8836f58019980085ca7b89b3795b720f1b05550",
        "k8s-namespace": "flux-system",
        "k8s-pod-name": "source-controller-7944c8d8b4-fm8bt",
        "pod-name": "flux-system/source-controller-7944c8d8b4-fm8bt"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 97006,
        "labels": [
          "k8s:app=source-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=source-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7944c8d8b4"
        ],
        "realized": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "security-relevant": [
          "k8s:app=source-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=source-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2024-08-04T16:28:44Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthz",
          "port": 9440,
          "protocol": "TCP"
        },
        {
          "name": "http",
          "port": 9090,
          "protocol": "TCP"
        },
        {
          "name": "http-prom",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.71",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "5a:3d:1f:73:56:44",
        "interface-index": 41,
        "interface-name": "lxce316820ded76",
        "mac": "22:3a:c1:42:03:3b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 97006,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 97006,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 84

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 84

```
Timestamp              Status   State                   Message
2024-08-04T16:28:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:28:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:28:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:28:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:28:44Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:28:39Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:25:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:25:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:25:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:25:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:25:16Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:25:11Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:08:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:08:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:08:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:08:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:08:31Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:08:26Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to 
2024-08-04T16:03:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 97006

```
ID      LABELS
97006   k8s:app=source-controller
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest
        k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=source-controller
        k8s:io.kubernetes.pod.namespace=flux-system

```


#### BPF Policy Get 265

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    467226   5454      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 265

```
Invalid argument: unknown type 265
```


#### Endpoint Get 265

```
[
  {
    "id": 265,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-265-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2345db6b-e406-453a-9176-54ee05660003"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-network/echo-server-7975c47f84-l9pfk",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.231Z",
            "success-count": 2
          },
          "uuid": "a27e7fb4-2b3d-4237-908d-7361647c7540"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (265)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.985Z",
            "success-count": 1
          },
          "uuid": "ce07e6ee-93d9-4784-b748-cce8be072ec1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-265",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.233Z",
            "success-count": 3
          },
          "uuid": "6fd7ad6c-1efc-40fc-b07a-ada973cb1989"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (265)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.887Z",
            "success-count": 232
          },
          "uuid": "08950646-1712-4f9d-8c7e-a7e4f4f8ef78"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (265)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.985Z",
            "success-count": 1
          },
          "uuid": "1b9c0454-8402-498d-9b17-c7b8c2da06d0"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8baec9537358188b833bf7589f6a5670cb260161145eec785c637826abb9dbaf:eth0",
        "container-id": "8baec9537358188b833bf7589f6a5670cb260161145eec785c637826abb9dbaf",
        "k8s-namespace": "network",
        "k8s-pod-name": "echo-server-7975c47f84-l9pfk",
        "pod-name": "network/echo-server-7975c47f84-l9pfk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 75356,
        "labels": [
          "k8s:app.kubernetes.io/component=echo-server",
          "k8s:app.kubernetes.io/instance=echo-server",
          "k8s:app.kubernetes.io/name=echo-server",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=network"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7975c47f84"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=echo-server",
          "k8s:app.kubernetes.io/instance=echo-server",
          "k8s:app.kubernetes.io/name=echo-server",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=network"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: syncing state to host)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.137",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "fa:b0:b0:45:5c:d7",
        "interface-index": 23,
        "interface-name": "lxc910004d47ea4",
        "mac": "c2:3e:5d:ad:5f:87"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 75356,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 75356,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 265

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 265

```
Timestamp              Status   State          Message
2024-08-04T16:03:17Z   OK       ready          Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready          Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating   Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring      Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring      Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring      Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring      Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring      Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring      Endpoint restoring

```


#### Identity get 75356

```
ID      LABELS
75356   k8s:app.kubernetes.io/component=echo-server
        k8s:app.kubernetes.io/instance=echo-server
        k8s:app.kubernetes.io/name=echo-server
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=network

```


#### BPF Policy Get 312

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    731048   5477      0        

```


#### BPF CT List 312

```
Invalid argument: unknown type 312
```


#### Endpoint Get 312

```
[
  {
    "id": 312,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-312-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c761af18-a72e-4744-8101-08553ee8ef0c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-storage/openebs-zfs-localpv-controller-6c66fff5bd-trkl2",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.477Z",
            "success-count": 2
          },
          "uuid": "c1e720de-530d-4a49-ab16-abccd98af872"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (312)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.985Z",
            "success-count": 1
          },
          "uuid": "f34bfd64-9e89-457d-b832-809c7646e45c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-312",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.139Z",
            "success-count": 3
          },
          "uuid": "584ca4c4-0479-4ae6-810b-6f822858a36c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (312)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.975Z",
            "success-count": 232
          },
          "uuid": "14ea93e7-2809-45c0-8418-ae95217abf2d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (312)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.985Z",
            "success-count": 1
          },
          "uuid": "09b963bb-0511-444c-ba0a-6ab6a32fb708"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b5a8c48931f07b31c6c7f47b5717d1e031692e7036e20d2da55923ff1f2c9ebc:eth0",
        "container-id": "b5a8c48931f07b31c6c7f47b5717d1e031692e7036e20d2da55923ff1f2c9ebc",
        "k8s-namespace": "storage",
        "k8s-pod-name": "openebs-zfs-localpv-controller-6c66fff5bd-trkl2",
        "pod-name": "storage/openebs-zfs-localpv-controller-6c66fff5bd-trkl2"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 68452,
        "labels": [
          "k8s:app=openebs-zfs-controller",
          "k8s:chart=zfs-localpv-2.6.0",
          "k8s:component=openebs-zfs-controller",
          "k8s:heritage=Helm",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-zfs-controller-sa",
          "k8s:io.kubernetes.pod.namespace=storage",
          "k8s:name=openebs-zfs-controller",
          "k8s:openebs.io/component-name=openebs-zfs-controller",
          "k8s:openebs.io/version=2.6.0",
          "k8s:release=openebs",
          "k8s:role=openebs-zfs"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6c66fff5bd"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=openebs-zfs-controller",
          "k8s:chart=zfs-localpv-2.6.0",
          "k8s:component=openebs-zfs-controller",
          "k8s:heritage=Helm",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-zfs-controller-sa",
          "k8s:io.kubernetes.pod.namespace=storage",
          "k8s:name=openebs-zfs-controller",
          "k8s:openebs.io/component-name=openebs-zfs-controller",
          "k8s:openebs.io/version=2.6.0",
          "k8s:release=openebs",
          "k8s:role=openebs-zfs"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: devices changed)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.25",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:cc:1d:a4:6e:91",
        "interface-index": 51,
        "interface-name": "lxc3136ad64a403",
        "mac": "62:3a:87:4f:71:4e"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 68452,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 68452,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 312

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 312

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: devices changed
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-08-04T16:03:16Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 68452

```
ID      LABELS
68452   k8s:app=openebs-zfs-controller
        k8s:chart=zfs-localpv-2.6.0
        k8s:component=openebs-zfs-controller
        k8s:heritage=Helm
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-zfs-controller-sa
        k8s:io.kubernetes.pod.namespace=storage
        k8s:name=openebs-zfs-controller
        k8s:openebs.io/component-name=openebs-zfs-controller
        k8s:openebs.io/version=2.6.0
        k8s:release=openebs
        k8s:role=openebs-zfs

```


#### BPF Policy Get 323

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    1190058   10815     0        
Allow    Egress      0          ANY          NONE         disabled    140668    1569      0        

```


#### BPF CT List 323

```
Invalid argument: unknown type 323
```


#### Endpoint Get 323

```
[
  {
    "id": 323,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-323-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3d92f36d-7247-4e47-91bf-e00e2cf4d088"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/k8tz-6c9d89b4bf-drdcm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.213Z",
            "success-count": 2
          },
          "uuid": "2c8bac7a-7e64-4efb-b6d8-a45e5e2501ce"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (323)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.988Z",
            "success-count": 1
          },
          "uuid": "6a586105-26e6-4b31-90d9-62111696c439"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-323",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.214Z",
            "success-count": 3
          },
          "uuid": "0ac1779e-981c-4ad7-9c20-e56722bebd87"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (323)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:45.789Z",
            "success-count": 232
          },
          "uuid": "7c54c0ef-b5f6-4e92-ab96-d63dc05326db"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (323)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.989Z",
            "success-count": 1
          },
          "uuid": "b505127d-0d75-4c8d-bf3c-9e01ebc0bee6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7bc47ff46543c2955ef55aff3e678f5d67cde5e63aee8a4fe79ddecccffe383d:eth0",
        "container-id": "7bc47ff46543c2955ef55aff3e678f5d67cde5e63aee8a4fe79ddecccffe383d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "k8tz-6c9d89b4bf-drdcm",
        "pod-name": "kube-system/k8tz-6c9d89b4bf-drdcm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 116209,
        "labels": [
          "k8s:app.kubernetes.io/instance=k8tz",
          "k8s:app.kubernetes.io/name=k8tz",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=k8tz",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6c9d89b4bf"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=k8tz",
          "k8s:app.kubernetes.io/name=k8tz",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=k8tz",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: syncing state to host)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "https",
          "port": 8443,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.160",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "46:46:bc:7d:29:f7",
        "interface-index": 45,
        "interface-name": "lxc83b895bb0fa9",
        "mac": "46:79:03:c1:57:9e"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 116209,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 116209,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 323

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 323

```
Timestamp              Status   State          Message
2024-08-04T16:03:17Z   OK       ready          Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready          Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating   Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring      Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring      Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring      Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring      Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring      Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring      Endpoint restoring

```


#### Identity get 116209

```
ID       LABELS
116209   k8s:app.kubernetes.io/instance=k8tz
         k8s:app.kubernetes.io/name=k8tz
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
         k8s:io.cilium.k8s.policy.cluster=home-storage
         k8s:io.cilium.k8s.policy.serviceaccount=k8tz
         k8s:io.kubernetes.pod.namespace=kube-system

```


#### BPF Policy Get 338

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    1523185   14359     0        
Allow    Egress      0          ANY          NONE         disabled    538729    4196      0        

```


#### BPF CT List 338

```
Invalid argument: unknown type 338
```


#### Endpoint Get 338

```
[
  {
    "id": 338,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-338-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0c066f15-c045-4322-a82b-500b424a2599"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/metrics-server-bc7c58fdf-wnd6t",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.388Z",
            "success-count": 2
          },
          "uuid": "42146218-b6cc-4097-aee6-7203762ad3a5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (338)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.986Z",
            "success-count": 1
          },
          "uuid": "3b3d04b0-f03c-4846-b12f-cf343ed4c3e8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-338",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.133Z",
            "success-count": 3
          },
          "uuid": "0599303d-00b3-455e-811f-fe1077d42fc0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (338)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:46.180Z",
            "success-count": 232
          },
          "uuid": "67faa36f-7706-4326-a29f-04153ceaa84c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (338)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.986Z",
            "success-count": 1
          },
          "uuid": "1815dafc-9207-4439-a14d-f36c8c371c84"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "838eb8e813f650ba1aad3ccd3ace05dfa6f7069be37a0c600ddb255b06eb61e2:eth0",
        "container-id": "838eb8e813f650ba1aad3ccd3ace05dfa6f7069be37a0c600ddb255b06eb61e2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "metrics-server-bc7c58fdf-wnd6t",
        "pod-name": "kube-system/metrics-server-bc7c58fdf-wnd6t"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 99246,
        "labels": [
          "k8s:app.kubernetes.io/instance=metrics-server",
          "k8s:app.kubernetes.io/name=metrics-server",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=metrics-server",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=bc7c58fdf"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=metrics-server",
          "k8s:app.kubernetes.io/name=metrics-server",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=metrics-server",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: devices changed)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.36",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "2a:03:8c:ef:b0:66",
        "interface-index": 15,
        "interface-name": "lxc5d9688897f63",
        "mac": "ea:ef:81:04:39:85"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 99246,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 99246,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 338

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 338

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: devices changed
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-08-04T16:03:16Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 99246

```
ID      LABELS
99246   k8s:app.kubernetes.io/instance=metrics-server
        k8s:app.kubernetes.io/name=metrics-server
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=metrics-server
        k8s:io.kubernetes.pod.namespace=kube-system

```


#### BPF Policy Get 361

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    441839   5047      0        
Allow    Egress      0          ANY          NONE         disabled    24173    305       0        

```


#### BPF CT List 361

```
Invalid argument: unknown type 361
```


#### Endpoint Get 361

```
[
  {
    "id": 361,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-361-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a25893db-6ae2-449e-b200-27b5c2862f21"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-361",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:38:13.154Z",
            "success-count": 8
          },
          "uuid": "6af034aa-4492-4ae8-ba46-9056c178c49f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/hubble-relay-f4457696c-r2rg7",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:13.149Z",
            "success-count": 1
          },
          "uuid": "219dd691-9154-4eda-9d3d-92e6f3ad4143"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-361",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.316Z",
            "success-count": 3
          },
          "uuid": "f39e6c01-6c2a-4b5d-96b6-cc7ea8a3e521"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (361)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:46.978Z",
            "success-count": 233
          },
          "uuid": "f52964b5-150d-4281-a788-87df2fbf653b"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "9a214d81c40176f4ae329e979c5bc87ded7a77c49e722abe6c076b942fc0ccb7:eth0",
        "container-id": "9a214d81c40176f4ae329e979c5bc87ded7a77c49e722abe6c076b942fc0ccb7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-relay-f4457696c-r2rg7",
        "pod-name": "kube-system/hubble-relay-f4457696c-r2rg7"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 81099,
        "labels": [
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-relay"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=f4457696c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-relay"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 4245,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.149",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "5a:7a:aa:2f:d4:08",
        "interface-index": 77,
        "interface-name": "lxcb9692533e4ab",
        "mac": "4a:03:72:84:25:ee"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 81099,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 81099,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 361

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 361

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to 
2024-08-04T16:03:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:03:13Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:03:13Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 81099

```
ID      LABELS
81099   k8s:app.kubernetes.io/name=hubble-relay
        k8s:app.kubernetes.io/part-of=cilium
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-relay

```


#### BPF Policy Get 369

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    456028    5293      0        
Allow    Egress      0          ANY          NONE         disabled    9906113   31603     0        

```


#### BPF CT List 369

```
Invalid argument: unknown type 369
```


#### Endpoint Get 369

```
[
  {
    "id": 369,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
        ]
      },
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-369-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4f4a15e7-c322-401b-a0e4-6cd0df5595f3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-369",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:38:44.490Z",
            "success-count": 8
          },
          "uuid": "dd429220-3d52-4b53-a009-9bbf3f9c744c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-flux-system/helm-controller-8b6b769d4-9l6gp",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.438Z",
            "success-count": 2
          },
          "uuid": "c1185b09-d70c-4484-b2da-f8f760048d1d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (369)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.984Z",
            "success-count": 1
          },
          "uuid": "b09d1619-0e2c-4324-8552-f5b104206a6f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-369",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.133Z",
            "success-count": 3
          },
          "uuid": "3880a0eb-ff14-45c8-825d-505d2d0cc7aa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (369)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.602Z",
            "success-count": 233
          },
          "uuid": "113b19eb-3f69-422d-9441-648382ea57b1"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (369)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.984Z",
            "success-count": 1
          },
          "uuid": "132655b6-7773-4ced-8a2c-543824cd1344"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "357d1c1628b96bde122799c6fb2bd4b959e0866489111b7a6f5d31645364a3da:eth0",
        "container-id": "357d1c1628b96bde122799c6fb2bd4b959e0866489111b7a6f5d31645364a3da",
        "k8s-namespace": "flux-system",
        "k8s-pod-name": "helm-controller-8b6b769d4-9l6gp",
        "pod-name": "flux-system/helm-controller-8b6b769d4-9l6gp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 67060,
        "labels": [
          "k8s:app=helm-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=helm-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=8b6b769d4"
        ],
        "realized": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "security-relevant": [
          "k8s:app=helm-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=helm-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2024-08-04T16:28:44Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthz",
          "port": 9440,
          "protocol": "TCP"
        },
        {
          "name": "http-prom",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.114",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ca:50:84:a1:10:4e",
        "interface-index": 61,
        "interface-name": "lxcbf04ad6c9b4a",
        "mac": "ee:61:2c:ae:39:02"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 67060,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 67060,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 369

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 369

```
Timestamp              Status   State                   Message
2024-08-04T16:28:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:28:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:28:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:28:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:28:44Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:28:39Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:25:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:25:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:25:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:25:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:25:16Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:25:11Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:08:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:08:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:08:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:08:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:08:31Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:08:26Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: devices changed
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-08-04T16:03:16Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 67060

```
ID      LABELS
67060   k8s:app=helm-controller
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest
        k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=helm-controller
        k8s:io.kubernetes.pod.namespace=flux-system

```


#### BPF Policy Get 745

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 745

```
Invalid argument: unknown type 745
```


#### Endpoint Get 745

```
[
  {
    "id": 745,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-745-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b1e19140-be6c-476e-a94e-976df199cd78"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-/",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "a96c8788-dc09-4dca-95ae-0d2ba6f818d6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (745)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "3f91af34-4211-4295-ad3f-27435688b750"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-745",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:16.083Z",
            "success-count": 3
          },
          "uuid": "92deef9b-9667-4a8c-addb-0a178899c3f9"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node-role.kubernetes.io/etcd=true",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:openebs.io/nodeid=h1",
          "k8s:openebs.io/nodename=h1",
          "k8s:p2p.k3s.cattle.io/enabled=true",
          "k8s:plan.upgrade.cattle.io/controllers=a3f533021e792ff6d664f5d8e5c5b2e0bb1680ccdb03404f2c544f68"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node-role.kubernetes.io/etcd=true",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:openebs.io/nodeid=h1",
          "k8s:openebs.io/nodename=h1",
          "k8s:p2p.k3s.cattle.io/enabled=true",
          "k8s:plan.upgrade.cattle.io/controllers=a3f533021e792ff6d664f5d8e5c5b2e0bb1680ccdb03404f2c544f68",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node-role.kubernetes.io/etcd=true",
          "k8s:node-role.kubernetes.io/master=true",
          "k8s:openebs.io/nodeid=h1",
          "k8s:openebs.io/nodename=h1",
          "k8s:p2p.k3s.cattle.io/enabled=true",
          "k8s:plan.upgrade.cattle.io/controllers=a3f533021e792ff6d664f5d8e5c5b2e0bb1680ccdb03404f2c544f68",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "fe:d4:d7:ea:50:e6",
        "interface-name": "cilium_host",
        "mac": "fe:d4:d7:ea:50:e6"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 745

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 745

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to 
2024-08-04T16:03:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 1

```
ID   LABELS
1    reserved:host
     reserved:kube-apiserver

```


#### BPF Policy Get 832

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    882090   6805      0        
Allow    Egress      0          ANY          NONE         disabled    33587    371       0        

```


#### BPF CT List 832

```
Invalid argument: unknown type 832
```


#### Endpoint Get 832

```
[
  {
    "id": 832,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-832-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "59e88238-4f69-4ef1-a700-421cd33e60d9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-storage/snapshot-validation-webhook-5697d649bc-vgwmq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.284Z",
            "success-count": 2
          },
          "uuid": "54661dfe-757f-4097-8604-13f0626b6f34"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (832)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.986Z",
            "success-count": 1
          },
          "uuid": "4636fa1c-f2ed-4dbb-865a-f360aa3adbd7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-832",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.286Z",
            "success-count": 3
          },
          "uuid": "315d4774-b11b-440e-b2c2-c706c043e5ea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (832)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:46.886Z",
            "success-count": 232
          },
          "uuid": "afad72f3-3280-485c-9cbb-79465c486a4f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (832)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.986Z",
            "success-count": 1
          },
          "uuid": "49880063-1966-4a24-82bf-d43ebf53e627"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "64120775ee0c5f132e32a751b6d8ef61006e93c27a0f1d5346feebe97be52ef8:eth0",
        "container-id": "64120775ee0c5f132e32a751b6d8ef61006e93c27a0f1d5346feebe97be52ef8",
        "k8s-namespace": "storage",
        "k8s-pod-name": "snapshot-validation-webhook-5697d649bc-vgwmq",
        "pod-name": "storage/snapshot-validation-webhook-5697d649bc-vgwmq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 80885,
        "labels": [
          "k8s:app.kubernetes.io/instance=snapshot-controller",
          "k8s:app.kubernetes.io/name=snapshot-validation-webhook",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=snapshot-validation-webhook",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=5697d649bc"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=snapshot-controller",
          "k8s:app.kubernetes.io/name=snapshot-validation-webhook",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=snapshot-validation-webhook",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: syncing state to host)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "https",
          "port": 8443,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.35",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "66:2e:d0:39:89:83",
        "interface-index": 47,
        "interface-name": "lxcf8bd3ef502c5",
        "mac": "6e:d8:e3:22:9c:d7"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 80885,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 80885,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 832

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 832

```
Timestamp              Status   State          Message
2024-08-04T16:03:17Z   OK       ready          Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready          Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating   Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring      Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring      Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring      Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring      Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring      Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring      Endpoint restoring

```


#### Identity get 80885

```
ID      LABELS
80885   k8s:app.kubernetes.io/instance=snapshot-controller
        k8s:app.kubernetes.io/name=snapshot-validation-webhook
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=snapshot-validation-webhook
        k8s:io.kubernetes.pod.namespace=storage

```


#### BPF Policy Get 889

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    8244802   4213      0        
Allow    Ingress     1          ANY          NONE         disabled    430242    4899      0        
Allow    Egress      0          ANY          NONE         disabled    8563470   5034      0        

```


#### BPF CT List 889

```
Invalid argument: unknown type 889
```


#### Endpoint Get 889

```
[
  {
    "id": 889,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-889-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f0b8e9d3-7661-4b5f-a0a9-ecaa3c63be32"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-network/ingress-nginx-internal-controller-5d8459498c-gz5jp",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.361Z",
            "success-count": 2
          },
          "uuid": "b7b55233-8199-4143-af1d-e62dd255f51a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (889)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.983Z",
            "success-count": 1
          },
          "uuid": "e8150869-07da-445a-ac14-4a9984df0328"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-889",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:16.298Z",
            "success-count": 3
          },
          "uuid": "a348652b-2f31-4244-a14a-75b22f528788"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (889)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:45.582Z",
            "success-count": 232
          },
          "uuid": "f72360b8-2920-4261-a784-0a618eb75e26"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (889)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.983Z",
            "success-count": 1
          },
          "uuid": "c4b50aef-3a35-4827-b4aa-5b56336504cf"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d994e72a82e4eb8e0b5b675639d6505c70c6201c9656591c3e089866dfc6c3fd:eth0",
        "container-id": "d994e72a82e4eb8e0b5b675639d6505c70c6201c9656591c3e089866dfc6c3fd",
        "k8s-namespace": "network",
        "k8s-pod-name": "ingress-nginx-internal-controller-5d8459498c-gz5jp",
        "pod-name": "network/ingress-nginx-internal-controller-5d8459498c-gz5jp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 124930,
        "labels": [
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/instance=ingress-nginx-internal",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=ingress-nginx",
          "k8s:app.kubernetes.io/part-of=ingress-nginx",
          "k8s:app.kubernetes.io/version=1.11.1",
          "k8s:helm.sh/chart=ingress-nginx-4.11.1",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=ingress-nginx-internal",
          "k8s:io.kubernetes.pod.namespace=network"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=5d8459498c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/instance=ingress-nginx-internal",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=ingress-nginx",
          "k8s:app.kubernetes.io/part-of=ingress-nginx",
          "k8s:app.kubernetes.io/version=1.11.1",
          "k8s:helm.sh/chart=ingress-nginx-4.11.1",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=ingress-nginx-internal",
          "k8s:io.kubernetes.pod.namespace=network"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "http",
          "port": 80,
          "protocol": "TCP"
        },
        {
          "name": "https",
          "port": 443,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 10254,
          "protocol": "TCP"
        },
        {
          "name": "webhook",
          "port": 8443,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.62",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7e:9b:cc:42:b3:d1",
        "interface-index": 29,
        "interface-name": "lxcbadff7f8234a",
        "mac": "ce:2d:41:e7:b1:a9"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 124930,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 124930,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 889

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 889

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to 
2024-08-04T16:03:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 124930

```
ID       LABELS
124930   k8s:app.kubernetes.io/component=controller
         k8s:app.kubernetes.io/instance=ingress-nginx-internal
         k8s:app.kubernetes.io/managed-by=Helm
         k8s:app.kubernetes.io/name=ingress-nginx
         k8s:app.kubernetes.io/part-of=ingress-nginx
         k8s:app.kubernetes.io/version=1.11.1
         k8s:helm.sh/chart=ingress-nginx-4.11.1
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
         k8s:io.cilium.k8s.policy.cluster=home-storage
         k8s:io.cilium.k8s.policy.serviceaccount=ingress-nginx-internal
         k8s:io.kubernetes.pod.namespace=network

```


#### BPF Policy Get 1037

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3558292   16543     0        
Allow    Ingress     1          ANY          NONE         disabled    451553    5265      0        
Allow    Egress      0          ANY          NONE         disabled    371072    6086      0        

```


#### BPF CT List 1037

```
Invalid argument: unknown type 1037
```


#### Endpoint Get 1037

```
[
  {
    "id": 1037,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1037-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "642dfc49-2b53-4db7-8adf-902ed022731e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-network/k8s-gateway-67ff7c6b99-qbzzk",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.436Z",
            "success-count": 2
          },
          "uuid": "bbed1cd4-7118-4722-8d21-03b5be6a76d0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (1037)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.984Z",
            "success-count": 1
          },
          "uuid": "2efd49b2-5be8-4836-bafe-7af37c22b2c3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1037",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.133Z",
            "success-count": 3
          },
          "uuid": "377a4495-da53-4e3d-9867-b80a02f4fad9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1037)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:45.082Z",
            "success-count": 232
          },
          "uuid": "f81f6f2f-c90f-433f-85e7-653bba8a98b6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (1037)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.984Z",
            "success-count": 1
          },
          "uuid": "3e58bcdb-06b0-4e7d-a911-28b7bb1ba845"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "09457963c6ce3395186ded9adf7f75b613621ba15811e400b9c0d56d1c57b05b:eth0",
        "container-id": "09457963c6ce3395186ded9adf7f75b613621ba15811e400b9c0d56d1c57b05b",
        "k8s-namespace": "network",
        "k8s-pod-name": "k8s-gateway-67ff7c6b99-qbzzk",
        "pod-name": "network/k8s-gateway-67ff7c6b99-qbzzk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 68187,
        "labels": [
          "k8s:app.kubernetes.io/instance=k8s-gateway",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=k8s-gateway",
          "k8s:app.kubernetes.io/version=0.4.0",
          "k8s:helm.sh/chart=k8s-gateway-2.4.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=k8s-gateway",
          "k8s:io.kubernetes.pod.namespace=network"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=67ff7c6b99"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=k8s-gateway",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=k8s-gateway",
          "k8s:app.kubernetes.io/version=0.4.0",
          "k8s:helm.sh/chart=k8s-gateway-2.4.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=k8s-gateway",
          "k8s:io.kubernetes.pod.namespace=network"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: devices changed)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-udp",
          "port": 1053,
          "protocol": "UDP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.29",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "06:7d:1c:9a:9d:f6",
        "interface-index": 27,
        "interface-name": "lxce3e3ac922558",
        "mac": "0a:fd:15:1d:61:b4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 68187,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 68187,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1037

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1037

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: devices changed
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-08-04T16:03:16Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 68187

```
ID      LABELS
68187   k8s:app.kubernetes.io/instance=k8s-gateway
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=k8s-gateway
        k8s:app.kubernetes.io/version=0.4.0
        k8s:helm.sh/chart=k8s-gateway-2.4.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=network
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=k8s-gateway
        k8s:io.kubernetes.pod.namespace=network

```


#### BPF Policy Get 1130

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    456145    5293      0        
Allow    Egress      0          ANY          NONE         disabled    8832891   30419     0        

```


#### BPF CT List 1130

```
Invalid argument: unknown type 1130
```


#### Endpoint Get 1130

```
[
  {
    "id": 1130,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
        ]
      },
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1130-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d7174713-d7b8-4d33-8b8d-b9cf4fc54ba8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1130",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:38:44.490Z",
            "success-count": 8
          },
          "uuid": "67d54592-29ae-43e0-8f64-05f4cb8d3480"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-flux-system/kustomize-controller-78b78bf57d-sx42s",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.207Z",
            "success-count": 2
          },
          "uuid": "ec399d25-d5fd-4421-9eb9-ee14c66f6b4e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (1130)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.987Z",
            "success-count": 1
          },
          "uuid": "3d27d2e1-82b0-4a87-bcc8-a4361550b877"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1130",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.209Z",
            "success-count": 3
          },
          "uuid": "d9954019-554f-406a-b6da-98a255d7ab53"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1130)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.588Z",
            "success-count": 233
          },
          "uuid": "3be977d9-30b8-4fc1-a555-9c1ad9bbc929"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (1130)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.987Z",
            "success-count": 1
          },
          "uuid": "64d86820-b9be-43e7-ac70-dffb325c7bc9"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "1f14dfc76f1ce17793a87a885528e15c28e3df2c7cc5f56a60d323325e40e316:eth0",
        "container-id": "1f14dfc76f1ce17793a87a885528e15c28e3df2c7cc5f56a60d323325e40e316",
        "k8s-namespace": "flux-system",
        "k8s-pod-name": "kustomize-controller-78b78bf57d-sx42s",
        "pod-name": "flux-system/kustomize-controller-78b78bf57d-sx42s"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 77832,
        "labels": [
          "k8s:app=kustomize-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=kustomize-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=78b78bf57d"
        ],
        "realized": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "security-relevant": [
          "k8s:app=kustomize-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=kustomize-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2024-08-04T16:28:44Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthz",
          "port": 9440,
          "protocol": "TCP"
        },
        {
          "name": "http-prom",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.180",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "da:f1:59:aa:ac:f7",
        "interface-index": 33,
        "interface-name": "lxc2b284e5fe4ce",
        "mac": "fa:08:a7:ea:7f:23"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 77832,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 77832,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1130

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1130

```
Timestamp              Status   State                   Message
2024-08-04T16:28:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:28:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:28:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:28:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:28:44Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:28:39Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:25:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:25:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:25:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:25:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:25:16Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:25:11Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:08:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:08:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:08:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:08:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:08:31Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:08:26Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring               Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 77832

```
ID      LABELS
77832   k8s:app=kustomize-controller
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest
        k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=kustomize-controller
        k8s:io.kubernetes.pod.namespace=flux-system

```


#### BPF Policy Get 1157

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    174992   656       0        
Allow    Ingress     1          ANY          NONE         disabled    461585   5415      0        
Allow    Egress      0          ANY          NONE         disabled    72642    866       0        

```


#### BPF CT List 1157

```
Invalid argument: unknown type 1157
```


#### Endpoint Get 1157

```
[
  {
    "id": 1157,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1157-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "13853eaf-4849-4a77-b30b-06a6c9164ff6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/hubble-ui-75f899dc7c-jnphv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.213Z",
            "success-count": 2
          },
          "uuid": "35c9085a-1aeb-4eba-ad15-9b60ecaabde0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (1157)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.985Z",
            "success-count": 1
          },
          "uuid": "a73dcad8-e54f-440e-b36d-5264c5a61b17"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1157",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.214Z",
            "success-count": 3
          },
          "uuid": "c9972564-92d2-4456-8c9c-13d7dfd6a356"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1157)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:45.280Z",
            "success-count": 232
          },
          "uuid": "a9e78da3-90fd-4409-a3a5-b25778f140de"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (1157)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.985Z",
            "success-count": 1
          },
          "uuid": "a62d87ae-22cc-4a17-a26e-010f0e26e120"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8cc5d7cf1e08fa4df77e2fe3b7420a2bff37801b3f0ab379c0d1e913fcb196ba:eth0",
        "container-id": "8cc5d7cf1e08fa4df77e2fe3b7420a2bff37801b3f0ab379c0d1e913fcb196ba",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-ui-75f899dc7c-jnphv",
        "pod-name": "kube-system/hubble-ui-75f899dc7c-jnphv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 126091,
        "labels": [
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-ui"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=75f899dc7c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-ui"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: syncing state to host)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 8090,
          "protocol": "TCP"
        },
        {
          "name": "http",
          "port": 8081,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.204",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f6:10:aa:81:f3:2c",
        "interface-index": 19,
        "interface-name": "lxc859384ae38a5",
        "mac": "5e:f7:54:fa:71:f1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 126091,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 126091,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1157

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1157

```
Timestamp              Status   State          Message
2024-08-04T16:03:17Z   OK       ready          Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready          Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating   Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring      Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring      Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring      Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring      Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring      Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring      Endpoint restoring

```


#### Identity get 126091

```
ID       LABELS
126091   k8s:app.kubernetes.io/name=hubble-ui
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
         k8s:io.cilium.k8s.policy.cluster=home-storage
         k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=hubble-ui

```


#### BPF Policy Get 1372

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    412600    4647      0        
Allow    Egress      0          ANY          NONE         disabled    1065248   3840      0        

```


#### BPF CT List 1372

```
Invalid argument: unknown type 1372
```


#### Endpoint Get 1372

```
[
  {
    "id": 1372,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
        ]
      },
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1372-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3adf070e-a565-4c0c-991f-f51f524e11c9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1372",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:38:44.490Z",
            "success-count": 8
          },
          "uuid": "e3a8d92a-0a20-4839-bfd5-04af43574234"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-flux-system/image-reflector-controller-65df777f5c-bwn9d",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.209Z",
            "success-count": 2
          },
          "uuid": "78bf9ed9-8ac2-4904-ab3d-c35abc7d7a5a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (1372)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.987Z",
            "success-count": 1
          },
          "uuid": "5f45d8fe-d711-4ebc-9f02-52b58d2f14fa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1372",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.211Z",
            "success-count": 3
          },
          "uuid": "bcd302f3-8472-4d39-b37c-a0c905961af0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1372)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.602Z",
            "success-count": 233
          },
          "uuid": "f4c41dee-d119-47e7-a4e3-194b0952994e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (1372)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.988Z",
            "success-count": 1
          },
          "uuid": "0893a1f9-8d07-4e3a-9624-038467dd6a44"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a23b10ba0a91b421056fc4d659093135aa4117387df18ffd1dcfabfbb3f6e5a2:eth0",
        "container-id": "a23b10ba0a91b421056fc4d659093135aa4117387df18ffd1dcfabfbb3f6e5a2",
        "k8s-namespace": "flux-system",
        "k8s-pod-name": "image-reflector-controller-65df777f5c-bwn9d",
        "pod-name": "flux-system/image-reflector-controller-65df777f5c-bwn9d"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 68728,
        "labels": [
          "k8s:app=image-reflector-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=image-reflector-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=65df777f5c"
        ],
        "realized": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "security-relevant": [
          "k8s:app=image-reflector-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=image-reflector-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2024-08-04T16:28:44Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthz",
          "port": 9440,
          "protocol": "TCP"
        },
        {
          "name": "http-prom",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.40",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "32:aa:e4:e5:37:63",
        "interface-index": 43,
        "interface-name": "lxc3b052960bf39",
        "mac": "76:42:43:0f:65:9c"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 68728,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 68728,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1372

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1372

```
Timestamp              Status   State                   Message
2024-08-04T16:28:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:28:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:28:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:28:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:28:44Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:28:39Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:25:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:25:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:25:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:25:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:25:16Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:25:11Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:08:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:08:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:08:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:08:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:08:31Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:08:26Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring               Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 68728

```
ID      LABELS
68728   k8s:app=image-reflector-controller
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux
        k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest
        k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=image-reflector-controller
        k8s:io.kubernetes.pod.namespace=flux-system

```


#### BPF Policy Get 1730

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    876288    10238     0        
Allow    Ingress     1          ANY          NONE         disabled    1343026   15565     0        
Allow    Egress      0          ANY          NONE         disabled    58700     716       0        

```


#### BPF CT List 1730

```
Invalid argument: unknown type 1730
```


#### Endpoint Get 1730

```
[
  {
    "id": 1730,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1730-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "98e40cbe-a49b-4442-9a26-547d483cdca1"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-6799fbcd5-nfdkr",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.210Z",
            "success-count": 2
          },
          "uuid": "ae2a489e-adf4-4adb-a8ff-e1a8ccd9aea4"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (1730)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.987Z",
            "success-count": 1
          },
          "uuid": "4503a8e9-6af0-49ce-8726-c19e53e69d4d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1730",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.211Z",
            "success-count": 3
          },
          "uuid": "d9835e73-17be-4bf7-9323-411a1dd04d7f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1730)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:45.679Z",
            "success-count": 232
          },
          "uuid": "1a510b27-9699-4150-b6e5-af3e0d902d5e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (1730)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.988Z",
            "success-count": 1
          },
          "uuid": "bf8c02bc-f801-4052-b83c-a04b6281975d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f51760bce9df39e0e5ba58c6f5d29d245fc732798bfd806aac28e4e095cc35e6:eth0",
        "container-id": "f51760bce9df39e0e5ba58c6f5d29d245fc732798bfd806aac28e4e095cc35e6",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-6799fbcd5-nfdkr",
        "pod-name": "kube-system/coredns-6799fbcd5-nfdkr"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 119669,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6799fbcd5"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: syncing state to host)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.148",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1a:1e:a2:8c:4a:e0",
        "interface-index": 63,
        "interface-name": "lxca7a944ff01cc",
        "mac": "32:0f:58:70:3e:a0"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 119669,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 119669,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1730

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1730

```
Timestamp              Status   State          Message
2024-08-04T16:03:17Z   OK       ready          Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready          Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating   Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring      Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring      Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring      Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring      Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring      Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring      Endpoint restoring

```


#### Identity get 119669

```
ID       LABELS
119669   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
         k8s:io.cilium.k8s.policy.cluster=home-storage
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1818

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    219075   2530      0        
Allow    Egress      0          ANY          NONE         disabled    474795   2668      0        

```


#### BPF CT List 1818

```
Invalid argument: unknown type 1818
```


#### Endpoint Get 1818

```
[
  {
    "id": 1818,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1818-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ef087947-f259-4059-814f-f740e285dd01"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cert-manager/cert-manager-77cdc7956d-xj7vw",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.464Z",
            "success-count": 2
          },
          "uuid": "b7dda985-d87b-46ef-a8a7-3162961b3672"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (1818)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.987Z",
            "success-count": 1
          },
          "uuid": "56fbf6d2-1119-4091-ae0f-a29782bdc805"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1818",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.139Z",
            "success-count": 3
          },
          "uuid": "a76894c2-aa75-483a-8d7c-9f8d00732753"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1818)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:45.377Z",
            "success-count": 232
          },
          "uuid": "7d352172-c9eb-43ff-bd35-958f2d63668f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (1818)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.987Z",
            "success-count": 1
          },
          "uuid": "944a4253-bd18-478c-9172-1f93258b45c6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "51b3b24778dd780506075cb68fa3002d39a4c4eeb56cd4b03d654b73d417ea53:eth0",
        "container-id": "51b3b24778dd780506075cb68fa3002d39a4c4eeb56cd4b03d654b73d417ea53",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-77cdc7956d-xj7vw",
        "pod-name": "cert-manager/cert-manager-77cdc7956d-xj7vw"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 74727,
        "labels": [
          "k8s:app=cert-manager",
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cert-manager",
          "k8s:app.kubernetes.io/version=v1.15.1",
          "k8s:helm.sh/chart=cert-manager-v1.15.1",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=77cdc7956d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cert-manager",
          "k8s:app.kubernetes.io/version=v1.15.1",
          "k8s:app=cert-manager",
          "k8s:helm.sh/chart=cert-manager-v1.15.1",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: devices changed)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "http-healthz",
          "port": 9403,
          "protocol": "TCP"
        },
        {
          "name": "http-metrics",
          "port": 9402,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.51",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "fa:0c:0e:33:d9:dc",
        "interface-index": 35,
        "interface-name": "lxcd458e6709d60",
        "mac": "7e:21:7b:67:fa:b7"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 74727,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 74727,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1818

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1818

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: devices changed
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-08-04T16:03:16Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 74727

```
ID      LABELS
74727   k8s:app.kubernetes.io/component=controller
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=cert-manager
        k8s:app.kubernetes.io/version=v1.15.1
        k8s:app=cert-manager
        k8s:helm.sh/chart=cert-manager-v1.15.1
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 1840

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    484094   5732      0        
Allow    Egress      0          ANY          NONE         disabled    361062   3996      0        

```


#### BPF CT List 1840

```
Invalid argument: unknown type 1840
```


#### Endpoint Get 1840

```
[
  {
    "id": 1840,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1840-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d93021ec-1978-4c39-bf67-7c117664d933"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/reloader-7fb44dcc5f-fmsxj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.306Z",
            "success-count": 2
          },
          "uuid": "9e49d1f6-dc69-414e-b03f-d0832bd2c7e8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (1840)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "48a025f4-b6ce-43cc-a484-eafd7018bdf1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1840",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:16.291Z",
            "success-count": 3
          },
          "uuid": "e3a6b6db-5d3b-459d-a8e6-b18d101908a5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1840)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:46.780Z",
            "success-count": 232
          },
          "uuid": "8bf5c058-53cb-4ce9-b620-db557d67c53e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (1840)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "1c413922-f0af-46ed-ae22-2ba19057ad71"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "824a680dfc1443e0f07765382da95f9eb0d82a47fbef411d4fd9082a83f4cd5f:eth0",
        "container-id": "824a680dfc1443e0f07765382da95f9eb0d82a47fbef411d4fd9082a83f4cd5f",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "reloader-7fb44dcc5f-fmsxj",
        "pod-name": "kube-system/reloader-7fb44dcc5f-fmsxj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 87680,
        "labels": [
          "k8s:app=reloader",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:chart=reloader-1.0.119",
          "k8s:group=com.stakater.platform",
          "k8s:heritage=Helm",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=reloader",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:provider=stakater",
          "k8s:release=reloader",
          "k8s:version=v1.0.119"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7fb44dcc5f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app=reloader",
          "k8s:chart=reloader-1.0.119",
          "k8s:group=com.stakater.platform",
          "k8s:heritage=Helm",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=reloader",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:provider=stakater",
          "k8s:release=reloader",
          "k8s:version=v1.0.119"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "http",
          "port": 9090,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.234",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0e:5f:8b:18:78:02",
        "interface-index": 21,
        "interface-name": "lxc503b32a2c6a7",
        "mac": "de:c6:a8:3d:08:40"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 87680,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 87680,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1840

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1840

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to 
2024-08-04T16:03:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 87680

```
ID      LABELS
87680   k8s:app.kubernetes.io/managed-by=Helm
        k8s:app=reloader
        k8s:chart=reloader-1.0.119
        k8s:group=com.stakater.platform
        k8s:heritage=Helm
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=reloader
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:provider=stakater
        k8s:release=reloader
        k8s:version=v1.0.119

```


#### BPF Policy Get 2180

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    271876   1953      0        

```


#### BPF CT List 2180

```
Invalid argument: unknown type 2180
```


#### Endpoint Get 2180

```
[
  {
    "id": 2180,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2180-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8131f0fb-43cb-4fb5-9b1c-48fceb0374c5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-system-upgrade/system-upgrade-controller-d67784b5b-4rw8c",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.403Z",
            "success-count": 2
          },
          "uuid": "39c0e2a9-819d-4325-9157-6be0bdba3630"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (2180)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.983Z",
            "success-count": 1
          },
          "uuid": "b6a5e18c-8d4f-4f8c-8d68-0a5814c06355"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2180",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:16.303Z",
            "success-count": 3
          },
          "uuid": "ef38ba78-37b2-4d6d-86fd-2833e135725e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2180)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.372Z",
            "success-count": 232
          },
          "uuid": "d84bc744-5792-4295-8ae6-e0efad2ce5a8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (2180)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.983Z",
            "success-count": 1
          },
          "uuid": "6c6b7f84-64a3-40a7-8d8b-666eed094bf5"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "53f712c676b605b8398b68b966af17dd5e2a87c9e20028df7039c5f22b2036e6:eth0",
        "container-id": "53f712c676b605b8398b68b966af17dd5e2a87c9e20028df7039c5f22b2036e6",
        "k8s-namespace": "system-upgrade",
        "k8s-pod-name": "system-upgrade-controller-d67784b5b-4rw8c",
        "pod-name": "system-upgrade/system-upgrade-controller-d67784b5b-4rw8c"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 120519,
        "labels": [
          "k8s:app.kubernetes.io/component=system-upgrade-controller",
          "k8s:app.kubernetes.io/instance=system-upgrade-controller",
          "k8s:app.kubernetes.io/name=system-upgrade-controller",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=system-upgrade",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=system-upgrade",
          "k8s:io.kubernetes.pod.namespace=system-upgrade"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=d67784b5b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=system-upgrade-controller",
          "k8s:app.kubernetes.io/instance=system-upgrade-controller",
          "k8s:app.kubernetes.io/name=system-upgrade-controller",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=system-upgrade",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=system-upgrade",
          "k8s:io.kubernetes.pod.namespace=system-upgrade"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.21",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:39:66:a4:13:43",
        "interface-index": 55,
        "interface-name": "lxcefb5df718e0f",
        "mac": "fa:f9:16:5a:ae:38"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 120519,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 120519,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2180

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2180

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to 
2024-08-04T16:03:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 120519

```
ID       LABELS
120519   k8s:app.kubernetes.io/component=system-upgrade-controller
         k8s:app.kubernetes.io/instance=system-upgrade-controller
         k8s:app.kubernetes.io/name=system-upgrade-controller
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=system-upgrade
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
         k8s:io.cilium.k8s.policy.cluster=home-storage
         k8s:io.cilium.k8s.policy.serviceaccount=system-upgrade
         k8s:io.kubernetes.pod.namespace=system-upgrade

```


#### BPF Policy Get 2211

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    996641   8605      0        
Allow    Egress      0          ANY          NONE         disabled    33055    362       0        

```


#### BPF CT List 2211

```
Invalid argument: unknown type 2211
```


#### Endpoint Get 2211

```
[
  {
    "id": 2211,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2211-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "abf5920c-b1df-4f4e-b550-773cfd2518c7"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cert-manager/cert-manager-webhook-6d5cb854fc-gp94j",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.483Z",
            "success-count": 2
          },
          "uuid": "10cdf0ae-38ed-4247-b283-fa9b0a7c6ad4"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (2211)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.984Z",
            "success-count": 1
          },
          "uuid": "9ee4ffd9-9d2c-4974-a907-3e9d5df4ba4f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2211",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.139Z",
            "success-count": 3
          },
          "uuid": "e25c0dc0-c971-4813-ad86-efe8b5411f75"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2211)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:46.084Z",
            "success-count": 232
          },
          "uuid": "00f63aae-df77-4fa4-a398-616ae428c0d0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (2211)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.984Z",
            "success-count": 1
          },
          "uuid": "9a6b9dc9-96be-4d2d-a681-20d8149c6d58"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2790e776e74f4ff76d7a82f10efb1e8a7ec23ff5cfbd91f5883aa190908ebfd8:eth0",
        "container-id": "2790e776e74f4ff76d7a82f10efb1e8a7ec23ff5cfbd91f5883aa190908ebfd8",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-webhook-6d5cb854fc-gp94j",
        "pod-name": "cert-manager/cert-manager-webhook-6d5cb854fc-gp94j"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 73986,
        "labels": [
          "k8s:app=webhook",
          "k8s:app.kubernetes.io/component=webhook",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=webhook",
          "k8s:app.kubernetes.io/version=v1.15.1",
          "k8s:helm.sh/chart=cert-manager-v1.15.1",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6d5cb854fc"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=webhook",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=webhook",
          "k8s:app.kubernetes.io/version=v1.15.1",
          "k8s:app=webhook",
          "k8s:helm.sh/chart=cert-manager-v1.15.1",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: devices changed)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthcheck",
          "port": 6080,
          "protocol": "TCP"
        },
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.161",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "52:1f:77:b9:ac:46",
        "interface-index": 37,
        "interface-name": "lxc4c920d1320f1",
        "mac": "da:40:07:7a:a0:ac"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 73986,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 73986,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2211

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2211

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: devices changed
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-08-04T16:03:16Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 73986

```
ID      LABELS
73986   k8s:app.kubernetes.io/component=webhook
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=webhook
        k8s:app.kubernetes.io/version=v1.15.1
        k8s:app=webhook
        k8s:helm.sh/chart=cert-manager-v1.15.1
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 2611

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    652126   4551      0        

```


#### BPF CT List 2611

```
Invalid argument: unknown type 2611
```


#### Endpoint Get 2611

```
[
  {
    "id": 2611,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2611-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d54a0582-22f0-4cf8-800d-876dcf574803"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cert-manager/cert-manager-cainjector-7477d56b47-p8h82",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.208Z",
            "success-count": 2
          },
          "uuid": "15ccafd6-6720-4e87-a7e8-cc1eff22b0a6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (2611)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.985Z",
            "success-count": 1
          },
          "uuid": "642b36ea-dfbb-4bb4-916f-40a1fc97b659"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2611",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.209Z",
            "success-count": 3
          },
          "uuid": "3318eff2-3187-4112-997b-7ea15334fb65"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2611)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.575Z",
            "success-count": 232
          },
          "uuid": "e40f1f26-76ea-4216-826d-bd54ad913701"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (2611)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.985Z",
            "success-count": 1
          },
          "uuid": "e2a149a6-bec8-482e-82f0-744837c7da5f"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8703a93f14d7c8f4e97022030576f54c8f9e3c690ebb3a20b416a88994bf3000:eth0",
        "container-id": "8703a93f14d7c8f4e97022030576f54c8f9e3c690ebb3a20b416a88994bf3000",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-cainjector-7477d56b47-p8h82",
        "pod-name": "cert-manager/cert-manager-cainjector-7477d56b47-p8h82"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 67967,
        "labels": [
          "k8s:app=cainjector",
          "k8s:app.kubernetes.io/component=cainjector",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cainjector",
          "k8s:app.kubernetes.io/version=v1.15.1",
          "k8s:helm.sh/chart=cert-manager-v1.15.1",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7477d56b47"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=cainjector",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cainjector",
          "k8s:app.kubernetes.io/version=v1.15.1",
          "k8s:app=cainjector",
          "k8s:helm.sh/chart=cert-manager-v1.15.1",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: syncing state to host)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.142",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "86:d4:6d:77:25:b9",
        "interface-index": 59,
        "interface-name": "lxcb7c0ed9dd42e",
        "mac": "aa:c2:aa:b9:05:a9"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 67967,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 67967,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2611

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2611

```
Timestamp              Status   State          Message
2024-08-04T16:03:17Z   OK       ready          Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready          Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating   Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring      Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring      Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring      Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring      Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring      Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring      Endpoint restoring

```


#### Identity get 67967

```
ID      LABELS
67967   k8s:app.kubernetes.io/component=cainjector
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=cainjector
        k8s:app.kubernetes.io/version=v1.15.1
        k8s:app=cainjector
        k8s:helm.sh/chart=cert-manager-v1.15.1
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 2708

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    227901   2057      0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2708

```
Invalid argument: unknown type 2708
```


#### Endpoint Get 2708

```
[
  {
    "id": 2708,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2708-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d3b3ab38-b17c-45e1-8e44-4e45b6776af5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-storage/minio-kes-6777b4676f-j6sfq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.281Z",
            "success-count": 2
          },
          "uuid": "8d3b3fcd-d772-4513-a15b-b51b6e6c5042"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (2708)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.988Z",
            "success-count": 1
          },
          "uuid": "190efe93-c97c-4831-940b-f8ecabd70bc6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2708",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.282Z",
            "success-count": 3
          },
          "uuid": "68e0482f-b161-4059-a8ed-113080244f42"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2708)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.681Z",
            "success-count": 232
          },
          "uuid": "278a2589-8b82-4c2e-b81e-7a9a63f2aa47"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (2708)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.988Z",
            "success-count": 1
          },
          "uuid": "b54ce977-bfdb-4060-9d3b-2ab54a66db2a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2a7a57d7f97181ea14ec925dd14aee7010c792502489e1350d69b80ac1e7ecdb:eth0",
        "container-id": "2a7a57d7f97181ea14ec925dd14aee7010c792502489e1350d69b80ac1e7ecdb",
        "k8s-namespace": "storage",
        "k8s-pod-name": "minio-kes-6777b4676f-j6sfq",
        "pod-name": "storage/minio-kes-6777b4676f-j6sfq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 78979,
        "labels": [
          "k8s:app.kubernetes.io/component=minio-kes",
          "k8s:app.kubernetes.io/instance=minio-kes",
          "k8s:app.kubernetes.io/name=minio-kes",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6777b4676f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=minio-kes",
          "k8s:app.kubernetes.io/instance=minio-kes",
          "k8s:app.kubernetes.io/name=minio-kes",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: syncing state to host)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.151",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7e:68:c8:e5:63:f0",
        "interface-index": 49,
        "interface-name": "lxcbdbcfb757b99",
        "mac": "62:1f:0d:8d:b2:b4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 78979,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 78979,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2708

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2708

```
Timestamp              Status   State          Message
2024-08-04T16:03:17Z   OK       ready          Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready          Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating   Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring      Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring      Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring      Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring      Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring      Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring      Endpoint restoring

```


#### Identity get 78979

```
ID      LABELS
78979   k8s:app.kubernetes.io/component=minio-kes
        k8s:app.kubernetes.io/instance=minio-kes
        k8s:app.kubernetes.io/name=minio-kes
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=storage

```


#### BPF Policy Get 2776

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    472134    5308      0        
Allow    Egress      0          ANY          NONE         disabled    1035051   4211      0        

```


#### BPF CT List 2776

```
Invalid argument: unknown type 2776
```


#### Endpoint Get 2776

```
[
  {
    "id": 2776,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2776-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "edd81e8c-1acd-4a50-9dbf-9dd74b672406"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-storage/snapshot-controller-6c64f66dc-tmwtc",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.400Z",
            "success-count": 2
          },
          "uuid": "cd1482d1-1239-455b-bd43-beb52ef6c7a6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (2776)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "b36dc58d-3bb1-4749-aeec-2724fd9755d1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2776",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:16.308Z",
            "success-count": 3
          },
          "uuid": "328357ca-069b-40c5-b5ff-d7d5ae1c5b76"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2776)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:46.678Z",
            "success-count": 232
          },
          "uuid": "f3f00f87-eba3-4bf9-a334-012bfdd4bad2"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (2776)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "7714e078-4e6d-4ffe-83d2-735b463a143a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "97ef6a7f4e3068cfbe9ca98d85cf2a9319d548a5eefd9a0809ddd15c9572619a:eth0",
        "container-id": "97ef6a7f4e3068cfbe9ca98d85cf2a9319d548a5eefd9a0809ddd15c9572619a",
        "k8s-namespace": "storage",
        "k8s-pod-name": "snapshot-controller-6c64f66dc-tmwtc",
        "pod-name": "storage/snapshot-controller-6c64f66dc-tmwtc"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 103831,
        "labels": [
          "k8s:app.kubernetes.io/instance=snapshot-controller",
          "k8s:app.kubernetes.io/name=snapshot-controller",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=snapshot-controller",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6c64f66dc"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=snapshot-controller",
          "k8s:app.kubernetes.io/name=snapshot-controller",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=snapshot-controller",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "namedPorts": [
        {
          "name": "http",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.175",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f6:a4:e9:14:df:98",
        "interface-index": 39,
        "interface-name": "lxcfd427869bc62",
        "mac": "12:02:56:fb:cc:29"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 103831,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 103831,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2776

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2776

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to 
2024-08-04T16:03:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 103831

```
ID       LABELS
103831   k8s:app.kubernetes.io/instance=snapshot-controller
         k8s:app.kubernetes.io/name=snapshot-controller
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
         k8s:io.cilium.k8s.policy.cluster=home-storage
         k8s:io.cilium.k8s.policy.serviceaccount=snapshot-controller
         k8s:io.kubernetes.pod.namespace=storage

```


#### BPF Policy Get 3129

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    423921    4815      0        
Allow    Egress      0          ANY          NONE         disabled    1084751   3998      0        

```


#### BPF CT List 3129

```
Invalid argument: unknown type 3129
```


#### Endpoint Get 3129

```
[
  {
    "id": 3129,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
        ]
      },
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3129-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "347f5f6c-eb5e-4265-a3e0-cc909f442b06"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3129",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:38:44.491Z",
            "success-count": 8
          },
          "uuid": "d5c7362b-9336-4f6b-aa4b-43d599e83d65"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-flux-system/image-automation-controller-79447887bb-45xt5",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.292Z",
            "success-count": 2
          },
          "uuid": "9d17be58-418c-4308-9db3-a3b7bf4fa098"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (3129)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "04a78d95-4bf1-4144-a90c-641811e7a0c1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3129",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:16.291Z",
            "success-count": 3
          },
          "uuid": "1b7b2935-33cb-4136-894e-32bbf36f9ed8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3129)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.602Z",
            "success-count": 233
          },
          "uuid": "0e67bd4c-3801-48db-8199-c2a85aa9053f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (3129)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.982Z",
            "success-count": 1
          },
          "uuid": "0708b77f-595a-496f-8d14-ca08a315694a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "dea0caf55e0e86008a981773a33570200007fa96cc8668edeb44f84309376f33:eth0",
        "container-id": "dea0caf55e0e86008a981773a33570200007fa96cc8668edeb44f84309376f33",
        "k8s-namespace": "flux-system",
        "k8s-pod-name": "image-automation-controller-79447887bb-45xt5",
        "pod-name": "flux-system/image-automation-controller-79447887bb-45xt5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 108192,
        "labels": [
          "k8s:app=image-automation-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=image-automation-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=79447887bb"
        ],
        "realized": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "security-relevant": [
          "k8s:app=image-automation-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=image-automation-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2024-08-04T16:28:44Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthz",
          "port": 9440,
          "protocol": "TCP"
        },
        {
          "name": "http-prom",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.83",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9e:32:a3:f4:26:24",
        "interface-index": 17,
        "interface-name": "lxc02b3905a6dfb",
        "mac": "c2:67:f4:44:c5:24"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 108192,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 108192,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3129

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3129

```
Timestamp              Status   State                   Message
2024-08-04T16:28:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:28:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:28:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:28:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:28:44Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:28:39Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:25:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:25:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:25:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:25:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:25:16Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:25:11Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:08:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:08:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:08:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:08:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:08:31Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:08:26Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to 
2024-08-04T16:03:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 108192

```
ID       LABELS
108192   k8s:app=image-automation-controller
         k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system
         k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux
         k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
         k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest
         k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted
         k8s:io.cilium.k8s.policy.cluster=home-storage
         k8s:io.cilium.k8s.policy.serviceaccount=image-automation-controller
         k8s:io.kubernetes.pod.namespace=flux-system

```


#### BPF Policy Get 3253

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    30084   344       0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3253

```
Invalid argument: unknown type 3253
```


#### Endpoint Get 3253

```
[
  {
    "id": 3253,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3253-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c1cf08d8-df5d-4f84-9153-9d11049483a4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3253",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:38:14.086Z",
            "success-count": 8
          },
          "uuid": "d5bdadd2-ed6f-447d-bb4c-e60fe1589856"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3253",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.308Z",
            "success-count": 3
          },
          "uuid": "ea6fa284-8e49-4f7a-bea4-a9f790469453"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.73",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "06:1d:6b:cb:46:58",
        "interface-index": 75,
        "interface-name": "lxc_health",
        "mac": "ca:91:26:8a:b7:2b"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3253

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3253

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:03:14Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:03:13Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 3601

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    231259    719       0        
Allow    Ingress     1          ANY          NONE         disabled    424546    4828      0        
Allow    Egress      0          ANY          NONE         disabled    1073628   3988      0        

```


#### BPF CT List 3601

```
Invalid argument: unknown type 3601
```


#### Endpoint Get 3601

```
[
  {
    "id": 3601,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
        ]
      },
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3601-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f0f9e8d0-e851-4485-b412-e725af5587db"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3601",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:38:44.493Z",
            "success-count": 8
          },
          "uuid": "f7d72659-4848-4e2e-9679-178dd3a7eaa5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-flux-system/notification-controller-685bdc466d-kcqmc",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.486Z",
            "success-count": 2
          },
          "uuid": "ead5d3e5-91f0-4d5a-8a7c-fe1c58aa0ae5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (3601)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.983Z",
            "success-count": 1
          },
          "uuid": "7a117043-761a-42c6-8044-2d5d65207e59"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3601",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.139Z",
            "success-count": 3
          },
          "uuid": "03e62413-48be-4f67-af48-e14afe6d5108"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3601)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.602Z",
            "success-count": 233
          },
          "uuid": "e5351aa0-7edf-471c-842e-e5bf2dd3b84d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (3601)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.983Z",
            "success-count": 1
          },
          "uuid": "aade98c1-fd84-4de3-96b2-619222ecf07a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fb3736fbd7286be45955fa16b12ccd5f5e15537dd66305fbc4a25f2ccfc2e8ff:eth0",
        "container-id": "fb3736fbd7286be45955fa16b12ccd5f5e15537dd66305fbc4a25f2ccfc2e8ff",
        "k8s-namespace": "flux-system",
        "k8s-pod-name": "notification-controller-685bdc466d-kcqmc",
        "pod-name": "flux-system/notification-controller-685bdc466d-kcqmc"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 103395,
        "labels": [
          "k8s:app=notification-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=notification-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=685bdc466d"
        ],
        "realized": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "security-relevant": [
          "k8s:app=notification-controller",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
          "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=notification-controller",
          "k8s:io.kubernetes.pod.namespace=flux-system"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2024-08-04T16:28:44Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthz",
          "port": 9440,
          "protocol": "TCP"
        },
        {
          "name": "http",
          "port": 9090,
          "protocol": "TCP"
        },
        {
          "name": "http-prom",
          "port": 8080,
          "protocol": "TCP"
        },
        {
          "name": "http-webhook",
          "port": 9292,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.88",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "96:86:cd:b0:3a:ac",
        "interface-index": 31,
        "interface-name": "lxcef0c82914670",
        "mac": "26:0f:68:e5:ab:1a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 103395,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 103395,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux",
            "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest",
            "k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted"
          ]
        },
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3601

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3601

```
Timestamp              Status   State                   Message
2024-08-04T16:28:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:28:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:28:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:28:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:28:44Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:28:39Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:25:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:25:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:25:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:25:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:25:16Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:25:11Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:08:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-08-04T16:08:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:08:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-08-04T16:08:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-08-04T16:08:31Z   OK       ready                   Set identity for this endpoint
2024-08-04T16:08:26Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: devices changed
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-08-04T16:03:16Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 103395

```
ID       LABELS
103395   k8s:app=notification-controller
         k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/instance=flux-system
         k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/part-of=flux
         k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/version=v2.3.0
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=flux-system
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=flux
         k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
         k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn-version=latest
         k8s:io.cilium.k8s.namespace.labels.pod-security.kubernetes.io/warn=restricted
         k8s:io.cilium.k8s.policy.cluster=home-storage
         k8s:io.cilium.k8s.policy.serviceaccount=notification-controller
         k8s:io.kubernetes.pod.namespace=flux-system

```


#### BPF Policy Get 3884

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3884

```
Invalid argument: unknown type 3884
```


#### Endpoint Get 3884

```
[
  {
    "id": 3884,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3884-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6f9d1af0-1894-46f9-959b-00f91bd58d1f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-storage/minio-kes-6777b4676f-w866r",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.213Z",
            "success-count": 2
          },
          "uuid": "07d27709-84f5-4ac6-b3f4-ed6fb7f0da7f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (3884)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.984Z",
            "success-count": 1
          },
          "uuid": "7d7a911e-333a-41eb-9ffd-dfd49297e025"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3884",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.214Z",
            "success-count": 3
          },
          "uuid": "f3c18ba5-9ad4-4525-8b97-6151bba8a1fb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3884)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:44.774Z",
            "success-count": 232
          },
          "uuid": "6fb14ec7-06b5-49ca-b855-f8a968764157"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (3884)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.984Z",
            "success-count": 1
          },
          "uuid": "9bc0e2af-c35c-4cf4-b0bf-c7cb069afa03"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "01580c6baa090ad11579cc2c05e2e1a83677cc13695d6a8bd703c315685f66e6:eth0",
        "container-id": "01580c6baa090ad11579cc2c05e2e1a83677cc13695d6a8bd703c315685f66e6",
        "k8s-namespace": "storage",
        "k8s-pod-name": "minio-kes-6777b4676f-w866r",
        "pod-name": "storage/minio-kes-6777b4676f-w866r"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 78979,
        "labels": [
          "k8s:app.kubernetes.io/component=minio-kes",
          "k8s:app.kubernetes.io/instance=minio-kes",
          "k8s:app.kubernetes.io/name=minio-kes",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6777b4676f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=minio-kes",
          "k8s:app.kubernetes.io/instance=minio-kes",
          "k8s:app.kubernetes.io/name=minio-kes",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: syncing state to host)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.37",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ea:b8:dd:5d:5d:e2",
        "interface-index": 53,
        "interface-name": "lxccc2dfd51c9f5",
        "mac": "fa:57:71:92:0a:12"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 78979,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 78979,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3884

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3884

```
Timestamp              Status   State          Message
2024-08-04T16:03:17Z   OK       ready          Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       ready          Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating   Regenerating endpoint: syncing state to host
2024-08-04T16:03:17Z   OK       restoring      Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-08-04T16:03:14Z   OK       restoring      Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring      Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring      Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring      Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring      Endpoint restoring

```


#### Identity get 78979

```
ID      LABELS
78979   k8s:app.kubernetes.io/component=minio-kes
        k8s:app.kubernetes.io/instance=minio-kes
        k8s:app.kubernetes.io/name=minio-kes
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=storage

```


#### BPF Policy Get 3931

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    7596358   604       0        
Allow    Ingress     1          ANY          NONE         disabled    149140    1674      0        
Allow    Egress      0          ANY          NONE         disabled    681392    5815      0        

```


#### BPF CT List 3931

```
Invalid argument: unknown type 3931
```


#### Endpoint Get 3931

```
[
  {
    "id": 3931,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3931-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ec108f32-9d17-4520-adaf-71e65da2022f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-storage/minio-0",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:17.400Z",
            "success-count": 2
          },
          "uuid": "9e1393f9-5864-43a0-aefb-3e5ec6c49a2e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "restoring-ep-identity (3931)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.986Z",
            "success-count": 1
          },
          "uuid": "0a8a9798-7d7c-4718-b6a7-7ace57a4294f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3931",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:33:17.133Z",
            "success-count": 3
          },
          "uuid": "329b4658-c010-485b-9186-17096905eedb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3931)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:41:46.282Z",
            "success-count": 232
          },
          "uuid": "140b3442-9925-4e94-bb18-eb68994a8892"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "waiting-initial-global-identities-ep (3931)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-08-04T16:03:12.986Z",
            "success-count": 1
          },
          "uuid": "48de066d-bfa3-4091-bb50-8fab8a46af18"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8868a653985a556fdb7e8bbd039cee1171bc4577ba0568a2eaad8b9907fef51f:eth0",
        "container-id": "8868a653985a556fdb7e8bbd039cee1171bc4577ba0568a2eaad8b9907fef51f",
        "k8s-namespace": "storage",
        "k8s-pod-name": "minio-0",
        "pod-name": "storage/minio-0"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 76802,
        "labels": [
          "k8s:app.kubernetes.io/component=minio",
          "k8s:app.kubernetes.io/instance=minio",
          "k8s:app.kubernetes.io/name=minio",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "labels": {
        "derived": [
          "k8s:apps.kubernetes.io/pod-index=0",
          "k8s:controller-revision-hash=minio-57bdc648dd",
          "k8s:statefulset.kubernetes.io/pod-name=minio-0"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=minio",
          "k8s:app.kubernetes.io/instance=minio",
          "k8s:app.kubernetes.io/name=minio",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system",
          "k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled",
          "k8s:io.cilium.k8s.policy.cluster=home-storage",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=storage"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: devices changed)",
          "state": "ready",
          "timestamp": "2024-08-04T16:03:17Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.10.0.103",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "12:45:0d:33:80:cf",
        "interface-index": 13,
        "interface-name": "lxcf228d89e07e3",
        "mac": "6a:be:93:2f:5a:9a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 76802,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 76802,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3931

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3931

```
Timestamp              Status   State                   Message
2024-08-04T16:03:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-08-04T16:03:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-08-04T16:03:17Z   OK       regenerating            Regenerating endpoint: devices changed
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: syncing state to host)
2024-08-04T16:03:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-08-04T16:03:16Z   OK       regenerating            Regenerating endpoint: syncing state to host
2024-08-04T16:03:14Z   OK       restoring               Skipped duplicate endpoint regeneration trigger due to 
2024-08-04T16:03:13Z   OK       restoring               Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-08-04T16:03:12Z   OK       restoring               Synchronizing endpoint labels with KVStore
2024-08-04T16:03:12Z   OK       restoring               Restoring endpoint from previous cilium instance
2024-08-04T16:03:08Z   OK       restoring               Endpoint restoring

```


#### Identity get 76802

```
ID      LABELS
76802   k8s:app.kubernetes.io/component=minio
        k8s:app.kubernetes.io/instance=minio
        k8s:app.kubernetes.io/name=minio
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=storage
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/name=cluster-apps
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/namespace=flux-system
        k8s:io.cilium.k8s.namespace.labels.kustomize.toolkit.fluxcd.io/prune=disabled
        k8s:io.cilium.k8s.policy.cluster=home-storage
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=storage

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0xc0013c96b0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0xc001e9a2a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0xc001e9a2a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x22e9da0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x22ea600,
 completeNotifications: (func(error)) 0x22ea3a0,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=24) {
  (k8s.ServiceID) kube-system/k8tz: (*k8s.Service)(0xc0013c8420)(frontends:[10.11.207.131]/ports=[https]/selector=map[app.kubernetes.io/instance:k8tz app.kubernetes.io/name:k8tz]),
  (k8s.ServiceID) network/ingress-nginx-internal-controller: (*k8s.Service)(0xc0013c86e0)(frontends:[10.11.20.152]/ports=[http https]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:ingress-nginx-internal app.kubernetes.io/name:ingress-nginx]),
  (k8s.ServiceID) storage/minio: (*k8s.Service)(0xc0013c89a0)(frontends:[10.11.182.189]/ports=[s3 http]/selector=map[app.kubernetes.io/component:minio app.kubernetes.io/instance:minio app.kubernetes.io/name:minio]),
  (k8s.ServiceID) storage/snapshot-controller: (*k8s.Service)(0xc0013c8b00)(frontends:[]/ports=[http]/selector=map[app.kubernetes.io/instance:snapshot-controller app.kubernetes.io/name:snapshot-controller]),
  (k8s.ServiceID) flux-system/source-controller: (*k8s.Service)(0xc002720bb0)(frontends:[10.11.167.174]/ports=[http]/selector=map[app:source-controller]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0xc002720f20)(frontends:[10.11.88.204]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/cilium-agent: (*k8s.Service)(0xc002720d10)(frontends:[]/ports=[metrics envoy-metrics]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/cilium-operator: (*k8s.Service)(0xc002720dc0)(frontends:[]/ports=[metrics]/selector=map[io.cilium/app:operator name:cilium-operator]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0xc0013c84d0)(frontends:[10.11.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) network/ingress-nginx-internal-controller-metrics: (*k8s.Service)(0xc0013c8840)(frontends:[10.11.45.147]/ports=[metrics]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:ingress-nginx-internal app.kubernetes.io/name:ingress-nginx]),
  (k8s.ServiceID) network/k8s-gateway: (*k8s.Service)(0xc0013c88f0)(frontends:[10.11.240.226]/ports=[dns-udp]/selector=map[app.kubernetes.io/instance:k8s-gateway app.kubernetes.io/name:k8s-gateway]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0xc002720b00)(frontends:[10.11.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) flux-system/notification-controller: (*k8s.Service)(0xc0013c82c0)(frontends:[10.11.233.8]/ports=[http]/selector=map[app:notification-controller]),
  (k8s.ServiceID) kube-system/hubble-metrics: (*k8s.Service)(0xc002720e70)(frontends:[]/ports=[hubble-metrics]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.Service)(0xc0013c8370)(frontends:[10.11.213.89]/ports=[http]/selector=map[k8s-app:hubble-ui]),
  (k8s.ServiceID) kube-system/metrics-server: (*k8s.Service)(0xc0013c8580)(frontends:[10.11.117.252]/ports=[https]/selector=map[app.kubernetes.io/instance:metrics-server app.kubernetes.io/name:metrics-server]),
  (k8s.ServiceID) network/echo-server: (*k8s.Service)(0xc0013c8630)(frontends:[10.11.43.95]/ports=[http]/selector=map[app.kubernetes.io/component:echo-server app.kubernetes.io/instance:echo-server app.kubernetes.io/name:echo-server]),
  (k8s.ServiceID) network/ingress-nginx-internal-controller-admission: (*k8s.Service)(0xc0013c8790)(frontends:[10.11.200.111]/ports=[https-webhook]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:ingress-nginx-internal app.kubernetes.io/name:ingress-nginx]),
  (k8s.ServiceID) storage/snapshot-validation-webhook: (*k8s.Service)(0xc0013c8bb0)(frontends:[10.11.75.113]/ports=[https]/selector=map[app.kubernetes.io/instance:snapshot-controller app.kubernetes.io/name:snapshot-validation-webhook]),
  (k8s.ServiceID) cert-manager/cert-manager-webhook: (*k8s.Service)(0xc0026964d0)(frontends:[10.11.234.10]/ports=[https]/selector=map[app.kubernetes.io/component:webhook app.kubernetes.io/instance:cert-manager app.kubernetes.io/name:webhook]),
  (k8s.ServiceID) flux-system/webhook-receiver: (*k8s.Service)(0xc002720c60)(frontends:[10.11.160.141]/ports=[http]/selector=map[app:notification-controller]),
  (k8s.ServiceID) storage/minio-kes: (*k8s.Service)(0xc0013c8a50)(frontends:[10.11.167.155]/ports=[kes]/selector=map[app.kubernetes.io/component:minio-kes app.kubernetes.io/instance:minio-kes app.kubernetes.io/name:minio-kes]),
  (k8s.ServiceID) cert-manager/cert-manager: (*k8s.Service)(0xc002696420)(frontends:[10.11.186.206]/ports=[tcp-prometheus-servicemonitor]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:cert-manager app.kubernetes.io/name:cert-manager]),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.Service)(0xc002720fd0)(frontends:[10.11.194.196]/ports=[]/selector=map[k8s-app:hubble-relay])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=20) {
  (k8s.ServiceID) kube-system/metrics-server: (*k8s.EndpointSlices)(0xc00183c5b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "metrics-server-pxzc5": (*k8s.Endpoints)(0xc00445a5b0)(10.10.0.36:10250/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/cert-manager: (*k8s.EndpointSlices)(0xc0014847b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "cert-manager-9stqp": (*k8s.Endpoints)(0xc002a55380)(10.10.0.51:9402/TCP)
   }
  }),
  (k8s.ServiceID) flux-system/notification-controller: (*k8s.EndpointSlices)(0xc00183c578)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=29) "notification-controller-m5hwb": (*k8s.Endpoints)(0xc002a55860)(10.10.0.88:9090/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0xc00183c590)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-2nc6n": (*k8s.Endpoints)(0xc0023fc8f0)(192.168.1.11:4244/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.EndpointSlices)(0xc00183c598)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "hubble-relay-w8fdx": (*k8s.Endpoints)(0xc007ba7520)(10.10.0.149:4245/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.EndpointSlices)(0xc00183c5a0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=15) "hubble-ui-b7bn2": (*k8s.Endpoints)(0xc00445a0d0)(10.10.0.204:8081/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/k8tz: (*k8s.EndpointSlices)(0xc00183c5a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "k8tz-6vb8p": (*k8s.Endpoints)(0xc00445a270)(10.10.0.160:8443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0xc00183c5b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-msndq": (*k8s.Endpoints)(0xc00445a410)(10.10.0.148:53/TCP,10.10.0.148:53/UDP,10.10.0.148:9153/TCP)
   }
  }),
  (k8s.ServiceID) network/ingress-nginx-internal-controller: (*k8s.EndpointSlices)(0xc00183c5d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=39) "ingress-nginx-internal-controller-bgwg5": (*k8s.Endpoints)(0xc00445aa90)(10.10.0.62:443/TCP,10.10.0.62:80/TCP)
   }
  }),
  (k8s.ServiceID) network/k8s-gateway: (*k8s.EndpointSlices)(0xc00183c5e0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "k8s-gateway-5zx7h": (*k8s.Endpoints)(0xc00445add0)(10.10.0.29:1053/UDP)
   }
  }),
  (k8s.ServiceID) storage/minio: (*k8s.EndpointSlices)(0xc00183c5f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "minio-q6ndd": (*k8s.Endpoints)(0xc00445b1e0)(10.10.0.103:9000/TCP,10.10.0.103:9001/TCP)
   }
  }),
  (k8s.ServiceID) flux-system/source-controller: (*k8s.EndpointSlices)(0xc00183c580)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=23) "source-controller-kcgd2": (*k8s.Endpoints)(0xc002a55a00)(10.10.0.71:9090/TCP)
   }
  }),
  (k8s.ServiceID) flux-system/webhook-receiver: (*k8s.EndpointSlices)(0xc00183c588)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=22) "webhook-receiver-8n4jm": (*k8s.Endpoints)(0xc002a55ba0)(10.10.0.88:9292/TCP)
   }
  }),
  (k8s.ServiceID) network/ingress-nginx-internal-controller-metrics: (*k8s.EndpointSlices)(0xc00183c5d8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=47) "ingress-nginx-internal-controller-metrics-8xvkg": (*k8s.Endpoints)(0xc00445ac30)(10.10.0.62:10254/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/cert-manager-webhook: (*k8s.EndpointSlices)(0xc0014847c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=26) "cert-manager-webhook-2phpd": (*k8s.Endpoints)(0xc002a55520)(10.10.0.161:10250/TCP)
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0xc00183c570)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0xc002a556c0)(192.168.1.11:6443/TCP)
   }
  }),
  (k8s.ServiceID) network/echo-server: (*k8s.EndpointSlices)(0xc00183c5c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "echo-server-8cpdb": (*k8s.Endpoints)(0xc00445a750)(10.10.0.137:8080/TCP)
   }
  }),
  (k8s.ServiceID) storage/minio-kes: (*k8s.EndpointSlices)(0xc00183c5e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=15) "minio-kes-ggt2z": (*k8s.Endpoints)(0xc00445af70)(10.10.0.151:7373/TCP,10.10.0.37:7373/TCP)
   }
  }),
  (k8s.ServiceID) storage/snapshot-validation-webhook: (*k8s.EndpointSlices)(0xc00183c5f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=33) "snapshot-validation-webhook-74vtx": (*k8s.Endpoints)(0xc00445b380)(10.10.0.35:8443/TCP)
   }
  }),
  (k8s.ServiceID) network/ingress-nginx-internal-controller-admission: (*k8s.EndpointSlices)(0xc00183c5c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=49) "ingress-nginx-internal-controller-admission-mhh48": (*k8s.Endpoints)(0xc00445a8f0)(10.10.0.62:8443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0xc001846e00)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0xc0022932c0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0x4a9a60,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0xc0084e0498
  },
  gcTrigger: (chan struct {}) (cap=1) 0xc001dae7e0,
  gcExited: (chan struct {}) 0xc001dae840,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0xc001cc2300)({
     ObserverVec: (*prometheus.HistogramVec)(0xc001bf7d78)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce00f0)({
       metricMap: (*prometheus.metricMap)(0xc001ce0120)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0011196e0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0xccb080
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0xc001cc2380)({
     ObserverVec: (*prometheus.HistogramVec)(0xc001bf7d80)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce0180)({
       metricMap: (*prometheus.metricMap)(0xc001ce01b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0011197a0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0xccb080
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0xc001cc2400)({
     GaugeVec: (*prometheus.GaugeVec)(0xc001bf7d88)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce0210)({
       metricMap: (*prometheus.metricMap)(0xc001ce0240)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001119800)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xcc2500
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0xc001cc2480)({
     GaugeVec: (*prometheus.GaugeVec)(0xc001bf7d90)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce02a0)({
       metricMap: (*prometheus.metricMap)(0xc001ce02d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001119860)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xcc2500
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0xc001cc2500)({
     GaugeVec: (*prometheus.GaugeVec)(0xc001bf7d98)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce0330)({
       metricMap: (*prometheus.metricMap)(0xc001ce0360)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001119920)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xcc2500
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0xc001cc2580)({
     GaugeVec: (*prometheus.GaugeVec)(0xc001bf7da0)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce03c0)({
       metricMap: (*prometheus.metricMap)(0xc001ce03f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001119980)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xcc2500
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0xc001cc2600)({
     GaugeVec: (*prometheus.GaugeVec)(0xc001bf7da8)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce0450)({
       metricMap: (*prometheus.metricMap)(0xc001ce0480)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc0011199e0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xcc2500
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0xc001cc2680)({
     GaugeVec: (*prometheus.GaugeVec)(0xc001bf7db0)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce04e0)({
       metricMap: (*prometheus.metricMap)(0xc001ce0510)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001119a40)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xcc2500
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0xc001cc2700)({
     ObserverVec: (*prometheus.HistogramVec)(0xc001bf7db8)({
      MetricVec: (*prometheus.MetricVec)(0xc001ce0570)({
       metricMap: (*prometheus.metricMap)(0xc001ce05a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0xc001119aa0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0xccb080
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0xcc1f40,
       hashAddByte: (func(uint64, uint8) uint64) 0xcc1f80
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0xc001846e00)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0xc001e94070)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0xc001e8a948)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 455ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x22513c0,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x2254700,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x225b1e0,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x225b1e0,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x225b1e0,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=27) {
  (string) (len=10) "10.10.0.62": (string) (len=69) "network/ingress-nginx-internal-controller-5d8459498c-gz5jp [restored]",
  (string) (len=11) "10.10.0.151": (string) (len=45) "storage/minio-kes-6777b4676f-j6sfq [restored]",
  (string) (len=11) "10.10.0.104": (string) (len=6) "router",
  (string) (len=10) "10.10.0.73": (string) (len=6) "health",
  (string) (len=11) "10.10.0.175": (string) (len=54) "storage/snapshot-controller-6c64f66dc-tmwtc [restored]",
  (string) (len=10) "10.10.0.25": (string) (len=66) "storage/openebs-zfs-localpv-controller-6c66fff5bd-trkl2 [restored]",
  (string) (len=10) "10.10.0.51": (string) (len=53) "cert-manager/cert-manager-77cdc7956d-xj7vw [restored]",
  (string) (len=10) "10.10.0.40": (string) (len=66) "flux-system/image-reflector-controller-65df777f5c-bwn9d [restored]",
  (string) (len=10) "10.10.0.21": (string) (len=67) "system-upgrade/system-upgrade-controller-d67784b5b-4rw8c [restored]",
  (string) (len=11) "10.10.0.149": (string) (len=40) "kube-system/hubble-relay-f4457696c-r2rg7",
  (string) (len=10) "10.10.0.36": (string) (len=53) "kube-system/metrics-server-bc7c58fdf-wnd6t [restored]",
  (string) (len=11) "10.10.0.161": (string) (len=61) "cert-manager/cert-manager-webhook-6d5cb854fc-gp94j [restored]",
  (string) (len=11) "10.10.0.137": (string) (len=47) "network/echo-server-7975c47f84-l9pfk [restored]",
  (string) (len=11) "10.10.0.204": (string) (len=49) "kube-system/hubble-ui-75f899dc7c-jnphv [restored]",
  (string) (len=10) "10.10.0.88": (string) (len=63) "flux-system/notification-controller-685bdc466d-kcqmc [restored]",
  (string) (len=11) "10.10.0.180": (string) (len=60) "flux-system/kustomize-controller-78b78bf57d-sx42s [restored]",
  (string) (len=10) "10.10.0.83": (string) (len=67) "flux-system/image-automation-controller-79447887bb-45xt5 [restored]",
  (string) (len=11) "10.10.0.148": (string) (len=46) "kube-system/coredns-6799fbcd5-nfdkr [restored]",
  (string) (len=10) "10.10.0.71": (string) (len=57) "flux-system/source-controller-7944c8d8b4-fm8bt [restored]",
  (string) (len=11) "10.10.0.160": (string) (len=44) "kube-system/k8tz-6c9d89b4bf-drdcm [restored]",
  (string) (len=11) "10.10.0.114": (string) (len=54) "flux-system/helm-controller-8b6b769d4-9l6gp [restored]",
  (string) (len=10) "10.10.0.37": (string) (len=45) "storage/minio-kes-6777b4676f-w866r [restored]",
  (string) (len=10) "10.10.0.35": (string) (len=63) "storage/snapshot-validation-webhook-5697d649bc-vgwmq [restored]",
  (string) (len=11) "10.10.0.234": (string) (len=48) "kube-system/reloader-7fb44dcc5f-fmsxj [restored]",
  (string) (len=11) "10.10.0.103": (string) (len=26) "storage/minio-0 [restored]",
  (string) (len=10) "10.10.0.29": (string) (len=47) "network/k8s-gateway-67ff7c6b99-qbzzk [restored]",
  (string) (len=11) "10.10.0.142": (string) (len=64) "cert-manager/cert-manager-cainjector-7477d56b47-p8h82 [restored]"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=20) "default:192.168.1.11": (string) (len=7) "node-ip"
}

```

