filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3136ad64a403 direct-action not_in_hw id 4264 tag ee32b4c8dcaac94b jited 
