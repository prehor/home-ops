Endpoint ID: 84
Path: /sys/fs/bpf/tc/globals/cilium_policy_00084

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    310796    4051      0        
Allow    Ingress     1          ANY          NONE         disabled    433656    5015      0        
Allow    Egress      0          ANY          NONE         disabled    1408239   7417      0        


Endpoint ID: 265
Path: /sys/fs/bpf/tc/globals/cilium_policy_00265

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    467226   5454      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 312
Path: /sys/fs/bpf/tc/globals/cilium_policy_00312

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    731048   5477      0        


Endpoint ID: 323
Path: /sys/fs/bpf/tc/globals/cilium_policy_00323

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    1188742   10803     0        
Allow    Egress      0          ANY          NONE         disabled    140668    1569      0        


Endpoint ID: 338
Path: /sys/fs/bpf/tc/globals/cilium_policy_00338

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    1523185   14359     0        
Allow    Egress      0          ANY          NONE         disabled    538729    4196      0        


Endpoint ID: 361
Path: /sys/fs/bpf/tc/globals/cilium_policy_00361

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    441839   5047      0        
Allow    Egress      0          ANY          NONE         disabled    24173    305       0        


Endpoint ID: 369
Path: /sys/fs/bpf/tc/globals/cilium_policy_00369

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    455580    5288      0        
Allow    Egress      0          ANY          NONE         disabled    9906113   31603     0        


Endpoint ID: 745
Path: /sys/fs/bpf/tc/globals/cilium_policy_00745

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 832
Path: /sys/fs/bpf/tc/globals/cilium_policy_00832

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    882090   6805      0        
Allow    Egress      0          ANY          NONE         disabled    33587    371       0        


Endpoint ID: 889
Path: /sys/fs/bpf/tc/globals/cilium_policy_00889

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    8240722   4198      0        
Allow    Ingress     1          ANY          NONE         disabled    430242    4899      0        
Allow    Egress      0          ANY          NONE         disabled    8563470   5034      0        


Endpoint ID: 1037
Path: /sys/fs/bpf/tc/globals/cilium_policy_01037

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3554837   16529     0        
Allow    Ingress     1          ANY          NONE         disabled    451553    5265      0        
Allow    Egress      0          ANY          NONE         disabled    370547    6078      0        


Endpoint ID: 1130
Path: /sys/fs/bpf/tc/globals/cilium_policy_01130

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    456145    5293      0        
Allow    Egress      0          ANY          NONE         disabled    8831761   30415     0        


Endpoint ID: 1157
Path: /sys/fs/bpf/tc/globals/cilium_policy_01157

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    174992   656       0        
Allow    Ingress     1          ANY          NONE         disabled    461585   5415      0        
Allow    Egress      0          ANY          NONE         disabled    72642    866       0        


Endpoint ID: 1372
Path: /sys/fs/bpf/tc/globals/cilium_policy_01372

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    412154    4642      0        
Allow    Egress      0          ANY          NONE         disabled    1064100   3836      0        


Endpoint ID: 1730
Path: /sys/fs/bpf/tc/globals/cilium_policy_01730

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    874793    10221     0        
Allow    Ingress     1          ANY          NONE         disabled    1341621   15549     0        
Allow    Egress      0          ANY          NONE         disabled    58641     715       0        


Endpoint ID: 1818
Path: /sys/fs/bpf/tc/globals/cilium_policy_01818

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    219075   2530      0        
Allow    Egress      0          ANY          NONE         disabled    474663   2666      0        


Endpoint ID: 1840
Path: /sys/fs/bpf/tc/globals/cilium_policy_01840

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    483583   5726      0        
Allow    Egress      0          ANY          NONE         disabled    361062   3996      0        


Endpoint ID: 2180
Path: /sys/fs/bpf/tc/globals/cilium_policy_02180

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    271876   1953      0        


Endpoint ID: 2211
Path: /sys/fs/bpf/tc/globals/cilium_policy_02211

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    995615   8593      0        
Allow    Egress      0          ANY          NONE         disabled    33055    362       0        


Endpoint ID: 2611
Path: /sys/fs/bpf/tc/globals/cilium_policy_02611

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    652126   4551      0        


Endpoint ID: 2708
Path: /sys/fs/bpf/tc/globals/cilium_policy_02708

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    227405   2052      0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2776
Path: /sys/fs/bpf/tc/globals/cilium_policy_02776

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    472134    5308      0        
Allow    Egress      0          ANY          NONE         disabled    1033844   4205      0        


Endpoint ID: 3129
Path: /sys/fs/bpf/tc/globals/cilium_policy_03129

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    423921    4815      0        
Allow    Egress      0          ANY          NONE         disabled    1083263   3991      0        


Endpoint ID: 3253
Path: /sys/fs/bpf/tc/globals/cilium_policy_03253

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    29952   342       0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3601
Path: /sys/fs/bpf/tc/globals/cilium_policy_03601

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    231259    719       0        
Allow    Ingress     1          ANY          NONE         disabled    424546    4828      0        
Allow    Egress      0          ANY          NONE         disabled    1072489   3984      0        


Endpoint ID: 3884
Path: /sys/fs/bpf/tc/globals/cilium_policy_03884

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3931
Path: /sys/fs/bpf/tc/globals/cilium_policy_03931

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    7596358   604       0        
Allow    Ingress     1          ANY          NONE         disabled    149140    1674      0        
Allow    Egress      0          ANY          NONE         disabled    679932    5802      0        


