filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcefb5df718e0f direct-action not_in_hw id 4170 tag 91dd75ddf099674c jited 
