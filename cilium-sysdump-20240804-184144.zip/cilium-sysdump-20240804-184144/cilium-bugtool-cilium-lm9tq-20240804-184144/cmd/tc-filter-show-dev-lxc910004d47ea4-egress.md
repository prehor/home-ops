filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_to_container-lxc910004d47ea4 direct-action not_in_hw id 4047 tag fec431b2fccfb4ce jited 
