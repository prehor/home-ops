{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:13.015Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "55",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:14.048Z",
  "value": "ANY://192.168.1.11"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "54",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:17.547Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "56",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-08-04T16:03:28.642Z",
  "value": "ANY://10.10.0.149"
}

