filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_to_container-lxcb9692533e4ab direct-action not_in_hw id 4090 tag 7306d4b92f3fe5b5 jited 
