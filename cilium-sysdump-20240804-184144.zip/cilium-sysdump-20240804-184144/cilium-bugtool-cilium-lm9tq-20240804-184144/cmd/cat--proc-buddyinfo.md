Node 0, zone      DMA      0      0      0      0      0      0      0      0      1      1      2 
Node 0, zone    DMA32      5      5      5      3      5      2      5      3      4      4    534 
Node 0, zone   Normal   6459   9787   3554   1528    638    237    107     58     27      4   5691 
