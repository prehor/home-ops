VRouter   Peer   Prefix   NextHop   Age   Attrs
