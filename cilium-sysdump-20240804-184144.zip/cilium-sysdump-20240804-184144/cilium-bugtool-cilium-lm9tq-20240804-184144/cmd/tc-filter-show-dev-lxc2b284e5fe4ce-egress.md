filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_to_container-lxc2b284e5fe4ce direct-action not_in_hw id 4394 tag 93588ab338da3af7 jited 
