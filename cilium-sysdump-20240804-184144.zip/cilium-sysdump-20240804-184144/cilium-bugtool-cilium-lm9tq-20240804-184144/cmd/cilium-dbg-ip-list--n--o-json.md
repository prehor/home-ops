[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.10.0.21/32",
    "hostIP": "192.168.1.11",
    "identity": 120519,
    "metadata": {
      "name": "system-upgrade-controller-d67784b5b-4rw8c",
      "namespace": "system-upgrade",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.25/32",
    "hostIP": "192.168.1.11",
    "identity": 68452,
    "metadata": {
      "name": "openebs-zfs-localpv-controller-6c66fff5bd-trkl2",
      "namespace": "storage",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.29/32",
    "hostIP": "192.168.1.11",
    "identity": 68187,
    "metadata": {
      "name": "k8s-gateway-67ff7c6b99-qbzzk",
      "namespace": "network",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.35/32",
    "hostIP": "192.168.1.11",
    "identity": 80885,
    "metadata": {
      "name": "snapshot-validation-webhook-5697d649bc-vgwmq",
      "namespace": "storage",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.36/32",
    "hostIP": "192.168.1.11",
    "identity": 99246,
    "metadata": {
      "name": "metrics-server-bc7c58fdf-wnd6t",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.37/32",
    "hostIP": "192.168.1.11",
    "identity": 78979,
    "metadata": {
      "name": "minio-kes-6777b4676f-w866r",
      "namespace": "storage",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.40/32",
    "hostIP": "192.168.1.11",
    "identity": 68728,
    "metadata": {
      "name": "image-reflector-controller-65df777f5c-bwn9d",
      "namespace": "flux-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.51/32",
    "hostIP": "192.168.1.11",
    "identity": 74727,
    "metadata": {
      "name": "cert-manager-77cdc7956d-xj7vw",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.62/32",
    "hostIP": "192.168.1.11",
    "identity": 124930,
    "metadata": {
      "name": "ingress-nginx-internal-controller-5d8459498c-gz5jp",
      "namespace": "network",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.71/32",
    "hostIP": "192.168.1.11",
    "identity": 97006,
    "metadata": {
      "name": "source-controller-7944c8d8b4-fm8bt",
      "namespace": "flux-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.73/32",
    "hostIP": "192.168.1.11",
    "identity": 4
  },
  {
    "cidr": "10.10.0.83/32",
    "hostIP": "192.168.1.11",
    "identity": 108192,
    "metadata": {
      "name": "image-automation-controller-79447887bb-45xt5",
      "namespace": "flux-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.88/32",
    "hostIP": "192.168.1.11",
    "identity": 103395,
    "metadata": {
      "name": "notification-controller-685bdc466d-kcqmc",
      "namespace": "flux-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.103/32",
    "hostIP": "192.168.1.11",
    "identity": 76802,
    "metadata": {
      "name": "minio-0",
      "namespace": "storage",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.104/32",
    "hostIP": "192.168.1.11",
    "identity": 1
  },
  {
    "cidr": "10.10.0.114/32",
    "hostIP": "192.168.1.11",
    "identity": 67060,
    "metadata": {
      "name": "helm-controller-8b6b769d4-9l6gp",
      "namespace": "flux-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.137/32",
    "hostIP": "192.168.1.11",
    "identity": 75356,
    "metadata": {
      "name": "echo-server-7975c47f84-l9pfk",
      "namespace": "network",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.142/32",
    "hostIP": "192.168.1.11",
    "identity": 67967,
    "metadata": {
      "name": "cert-manager-cainjector-7477d56b47-p8h82",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.148/32",
    "hostIP": "192.168.1.11",
    "identity": 119669,
    "metadata": {
      "name": "coredns-6799fbcd5-nfdkr",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.149/32",
    "hostIP": "192.168.1.11",
    "identity": 81099,
    "metadata": {
      "name": "hubble-relay-f4457696c-r2rg7",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.151/32",
    "hostIP": "192.168.1.11",
    "identity": 78979,
    "metadata": {
      "name": "minio-kes-6777b4676f-j6sfq",
      "namespace": "storage",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.160/32",
    "hostIP": "192.168.1.11",
    "identity": 116209,
    "metadata": {
      "name": "k8tz-6c9d89b4bf-drdcm",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.161/32",
    "hostIP": "192.168.1.11",
    "identity": 73986,
    "metadata": {
      "name": "cert-manager-webhook-6d5cb854fc-gp94j",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.175/32",
    "hostIP": "192.168.1.11",
    "identity": 103831,
    "metadata": {
      "name": "snapshot-controller-6c64f66dc-tmwtc",
      "namespace": "storage",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.180/32",
    "hostIP": "192.168.1.11",
    "identity": 77832,
    "metadata": {
      "name": "kustomize-controller-78b78bf57d-sx42s",
      "namespace": "flux-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.204/32",
    "hostIP": "192.168.1.11",
    "identity": 126091,
    "metadata": {
      "name": "hubble-ui-75f899dc7c-jnphv",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.10.0.234/32",
    "hostIP": "192.168.1.11",
    "identity": 87680,
    "metadata": {
      "name": "reloader-7fb44dcc5f-fmsxj",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "192.168.1.10/32",
    "identity": 1
  },
  {
    "cidr": "192.168.1.11/32",
    "identity": 1
  }
]

