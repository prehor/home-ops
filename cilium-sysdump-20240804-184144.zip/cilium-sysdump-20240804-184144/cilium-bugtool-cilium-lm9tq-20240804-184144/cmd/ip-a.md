1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: enp9s0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq master lan state UP group default qlen 1000
    link/ether 18:31:bf:d0:6d:0d brd ff:ff:ff:ff:ff:ff
3: enp10s0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc mq master lan state DOWN group default qlen 1000
    link/ether 18:31:bf:d0:6d:0e brd ff:ff:ff:ff:ff:ff
4: enp11s0: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether 18:31:bf:d0:6d:0f brd ff:ff:ff:ff:ff:ff
5: enp12s0: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether 18:31:bf:d0:6d:10 brd ff:ff:ff:ff:ff:ff
6: lan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:f4:f8:8e:5c:8c brd ff:ff:ff:ff:ff:ff
    inet 192.168.1.11/24 scope global lan
       valid_lft forever preferred_lft forever
    inet 192.168.1.10/32 scope global lan
       valid_lft forever preferred_lft forever
    inet6 fd61:e2c9:ba8b:0:8f4:f8ff:fe8e:5c8c/64 scope global dynamic mngtmpaddr 
       valid_lft forever preferred_lft forever
    inet6 2a02:768:1b10:ac5e:8f4:f8ff:fe8e:5c8c/64 scope global dynamic mngtmpaddr 
       valid_lft 21474441sec preferred_lft 21474441sec
    inet6 fe80::8f4:f8ff:fe8e:5c8c/64 scope link 
       valid_lft forever preferred_lft forever
7: iot@lan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:f4:f8:8e:5c:8d brd ff:ff:ff:ff:ff:ff
    inet 192.168.101.11/24 scope global iot
       valid_lft forever preferred_lft forever
    inet6 fe80::8f4:f8ff:fe8e:5c8d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether a2:2a:48:15:b5:3b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a02a:48ff:fe15:b53b/64 scope link 
       valid_lft forever preferred_lft forever
9: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether fe:d4:d7:ea:50:e6 brd ff:ff:ff:ff:ff:ff
    inet 10.10.0.104/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::fcd4:d7ff:feea:50e6/64 scope link 
       valid_lft forever preferred_lft forever
13: lxcf228d89e07e3@if12: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 12:45:0d:33:80:cf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1045:dff:fe33:80cf/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc5d9688897f63@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:03:8c:ef:b0:66 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2803:8cff:feef:b066/64 scope link 
       valid_lft forever preferred_lft forever
17: lxc02b3905a6dfb@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:32:a3:f4:26:24 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::9c32:a3ff:fef4:2624/64 scope link 
       valid_lft forever preferred_lft forever
19: lxc859384ae38a5@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether f6:10:aa:81:f3:2c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f410:aaff:fe81:f32c/64 scope link 
       valid_lft forever preferred_lft forever
21: lxc503b32a2c6a7@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:5f:8b:18:78:02 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::c5f:8bff:fe18:7802/64 scope link 
       valid_lft forever preferred_lft forever
23: lxc910004d47ea4@if22: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether fa:b0:b0:45:5c:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::f8b0:b0ff:fe45:5cd7/64 scope link 
       valid_lft forever preferred_lft forever
27: lxce3e3ac922558@if26: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 06:7d:1c:9a:9d:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 8
    inet6 fe80::47d:1cff:fe9a:9df6/64 scope link 
       valid_lft forever preferred_lft forever
29: lxcbadff7f8234a@if28: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:9b:cc:42:b3:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 9
    inet6 fe80::7c9b:ccff:fe42:b3d1/64 scope link 
       valid_lft forever preferred_lft forever
31: lxcef0c82914670@if30: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 96:86:cd:b0:3a:ac brd ff:ff:ff:ff:ff:ff link-netnsid 10
    inet6 fe80::9486:cdff:feb0:3aac/64 scope link 
       valid_lft forever preferred_lft forever
33: lxc2b284e5fe4ce@if32: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether da:f1:59:aa:ac:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 11
    inet6 fe80::d8f1:59ff:feaa:acf7/64 scope link 
       valid_lft forever preferred_lft forever
35: lxcd458e6709d60@if34: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether fa:0c:0e:33:d9:dc brd ff:ff:ff:ff:ff:ff link-netnsid 12
    inet6 fe80::f80c:eff:fe33:d9dc/64 scope link 
       valid_lft forever preferred_lft forever
37: lxc4c920d1320f1@if36: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 52:1f:77:b9:ac:46 brd ff:ff:ff:ff:ff:ff link-netnsid 13
    inet6 fe80::501f:77ff:feb9:ac46/64 scope link 
       valid_lft forever preferred_lft forever
39: lxcfd427869bc62@if38: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether f6:a4:e9:14:df:98 brd ff:ff:ff:ff:ff:ff link-netnsid 14
    inet6 fe80::f4a4:e9ff:fe14:df98/64 scope link 
       valid_lft forever preferred_lft forever
41: lxce316820ded76@if40: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:3d:1f:73:56:44 brd ff:ff:ff:ff:ff:ff link-netnsid 15
    inet6 fe80::583d:1fff:fe73:5644/64 scope link 
       valid_lft forever preferred_lft forever
43: lxc3b052960bf39@if42: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 32:aa:e4:e5:37:63 brd ff:ff:ff:ff:ff:ff link-netnsid 16
    inet6 fe80::30aa:e4ff:fee5:3763/64 scope link 
       valid_lft forever preferred_lft forever
45: lxc83b895bb0fa9@if44: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 46:46:bc:7d:29:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 17
    inet6 fe80::4446:bcff:fe7d:29f7/64 scope link 
       valid_lft forever preferred_lft forever
47: lxcf8bd3ef502c5@if46: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 66:2e:d0:39:89:83 brd ff:ff:ff:ff:ff:ff link-netnsid 18
    inet6 fe80::642e:d0ff:fe39:8983/64 scope link 
       valid_lft forever preferred_lft forever
49: lxcbdbcfb757b99@if48: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:68:c8:e5:63:f0 brd ff:ff:ff:ff:ff:ff link-netnsid 19
    inet6 fe80::7c68:c8ff:fee5:63f0/64 scope link 
       valid_lft forever preferred_lft forever
51: lxc3136ad64a403@if50: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ee:cc:1d:a4:6e:91 brd ff:ff:ff:ff:ff:ff link-netnsid 20
    inet6 fe80::eccc:1dff:fea4:6e91/64 scope link 
       valid_lft forever preferred_lft forever
53: lxccc2dfd51c9f5@if52: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ea:b8:dd:5d:5d:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 21
    inet6 fe80::e8b8:ddff:fe5d:5de2/64 scope link 
       valid_lft forever preferred_lft forever
55: lxcefb5df718e0f@if54: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ee:39:66:a4:13:43 brd ff:ff:ff:ff:ff:ff link-netnsid 22
    inet6 fe80::ec39:66ff:fea4:1343/64 scope link 
       valid_lft forever preferred_lft forever
59: lxcb7c0ed9dd42e@if58: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 86:d4:6d:77:25:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 24
    inet6 fe80::84d4:6dff:fe77:25b9/64 scope link 
       valid_lft forever preferred_lft forever
61: lxcbf04ad6c9b4a@if60: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ca:50:84:a1:10:4e brd ff:ff:ff:ff:ff:ff link-netnsid 25
    inet6 fe80::c850:84ff:fea1:104e/64 scope link 
       valid_lft forever preferred_lft forever
63: lxca7a944ff01cc@if62: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:1e:a2:8c:4a:e0 brd ff:ff:ff:ff:ff:ff link-netnsid 26
    inet6 fe80::181e:a2ff:fe8c:4ae0/64 scope link 
       valid_lft forever preferred_lft forever
75: lxc_health@if74: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 06:1d:6b:cb:46:58 brd ff:ff:ff:ff:ff:ff link-netnsid 23
    inet6 fe80::41d:6bff:fecb:4658/64 scope link 
       valid_lft forever preferred_lft forever
77: lxcb9692533e4ab@if76: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:7a:aa:2f:d4:08 brd ff:ff:ff:ff:ff:ff link-netnsid 27
    inet6 fe80::587a:aaff:fe2f:d408/64 scope link 
       valid_lft forever preferred_lft forever
