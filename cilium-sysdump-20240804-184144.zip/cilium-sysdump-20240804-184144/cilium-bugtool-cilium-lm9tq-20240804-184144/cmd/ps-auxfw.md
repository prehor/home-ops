USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        7208  0.0  0.0 1241816 12956 ?       Ssl  16:41   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        7250  0.0  0.0   7064  1308 ?        R    16:41   0:00  \_ ps auxfw
root        7251  0.0  0.0   4532  1092 ?        R    16:41   0:00  \_ ip -4 r
root        7252  0.0  0.0   4532  1092 ?        R    16:41   0:00  \_ ip a
root        7253  0.0  0.0   4532  1092 ?        R    16:41   0:00  \_ ip -d -s l
root        7254  0.0  0.0   4532  1072 ?        R    16:41   0:00  \_ ip -6 r
root        7255  0.0  0.0   4400   552 ?        R    16:41   0:00  \_ ip -4 n
root        7256  0.0  0.0   2016   440 ?        R    16:41   0:00  \_ ip -6 n
root        7257  0.0  0.0    752   276 ?        R    16:41   0:00  \_ ss -t -p -a -i -s -n -e
root        7190  0.0  0.0 1228864 3704 ?        Ssl  16:41   0:00 /bin/gops stats 1
root        7174  0.0  0.0 1229120 3704 ?        Ssl  16:41   0:00 /bin/gops pprof-heap 1
root        7172  0.0  0.0 1229120 3704 ?        Ssl  16:41   0:00 /bin/gops pprof-cpu 1
root        7069  0.0  0.0   4080   964 ?        Ss   16:28   0:00 tar cf - /tmp/cilium-bugtool-20240804-162448.762+0000-UTC-3498892271.tar
root           1  4.9  0.6 1477384 214016 ?      Ssl  16:03   1:54 cilium-agent --config-dir=/tmp/cilium/config-map
root         359  0.0  0.0 1229348 3668 ?        Sl   16:03   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
root         691  0.0  0.0      0     0 ?        Z    16:21   0:00 [cilium-dbg] <defunct>
root        2020  0.0  0.0      0     0 ?        Z    16:21   0:00 [cilium] <defunct>
