filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_to_container-lxcb7c0ed9dd42e direct-action not_in_hw id 4035 tag aa40f2ef1982a563 jited 
