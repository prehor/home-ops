KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30 (v1.30.2+k3s2) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumLocalRedirectPolicy", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [lan      192.168.1.11 192.168.1.10 fd61:e2c9:ba8b:0:8f4:f8ff:fe8e:5c8c 2a02:768:1b10:ac5e:8f4:f8ff:fe8e:5c8c fe80::8f4:f8ff:fe8e:5c8c (Direct Routing)]
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 8 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 27/254 allocated from 10.10.0.0/24, 
Allocated addresses:
  10.10.0.103 (storage/minio-0 [restored])
  10.10.0.104 (router)
  10.10.0.114 (flux-system/helm-controller-8b6b769d4-9l6gp [restored])
  10.10.0.137 (network/echo-server-7975c47f84-l9pfk [restored])
  10.10.0.142 (cert-manager/cert-manager-cainjector-7477d56b47-p8h82 [restored])
  10.10.0.148 (kube-system/coredns-6799fbcd5-nfdkr [restored])
  10.10.0.149 (kube-system/hubble-relay-f4457696c-r2rg7)
  10.10.0.151 (storage/minio-kes-6777b4676f-j6sfq [restored])
  10.10.0.160 (kube-system/k8tz-6c9d89b4bf-drdcm [restored])
  10.10.0.161 (cert-manager/cert-manager-webhook-6d5cb854fc-gp94j [restored])
  10.10.0.175 (storage/snapshot-controller-6c64f66dc-tmwtc [restored])
  10.10.0.180 (flux-system/kustomize-controller-78b78bf57d-sx42s [restored])
  10.10.0.204 (kube-system/hubble-ui-75f899dc7c-jnphv [restored])
  10.10.0.21 (system-upgrade/system-upgrade-controller-d67784b5b-4rw8c [restored])
  10.10.0.234 (kube-system/reloader-7fb44dcc5f-fmsxj [restored])
  10.10.0.25 (storage/openebs-zfs-localpv-controller-6c66fff5bd-trkl2 [restored])
  10.10.0.29 (network/k8s-gateway-67ff7c6b99-qbzzk [restored])
  10.10.0.35 (storage/snapshot-validation-webhook-5697d649bc-vgwmq [restored])
  10.10.0.36 (kube-system/metrics-server-bc7c58fdf-wnd6t [restored])
  10.10.0.37 (storage/minio-kes-6777b4676f-w866r [restored])
  10.10.0.40 (flux-system/image-reflector-controller-65df777f5c-bwn9d [restored])
  10.10.0.51 (cert-manager/cert-manager-77cdc7956d-xj7vw [restored])
  10.10.0.62 (network/ingress-nginx-internal-controller-5d8459498c-gz5jp [restored])
  10.10.0.71 (flux-system/source-controller-7944c8d8b4-fm8bt [restored])
  10.10.0.73 (health)
  10.10.0.83 (flux-system/image-automation-controller-79447887bb-45xt5 [restored])
  10.10.0.88 (flux-system/notification-controller-685bdc466d-kcqmc [restored])
ClusterMesh:            0/0 remote clusters ready, 0 global-services
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Native   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      176/176 healthy
  Name                                                                        Last success   Last error   Count   Message
  bpf-map-sync-cilium_lxc                                                     7s ago         never        0       no error   
  cilium-health-ep                                                            32s ago        never        0       no error   
  ct-map-pressure                                                             32s ago        never        0       no error   
  daemon-validate-config                                                      56s ago        never        0       no error   
  dns-garbage-collector-job                                                   38s ago        never        0       no error   
  endpoint-1037-regeneration-recovery                                         never          never        0       no error   
  endpoint-1130-regeneration-recovery                                         never          never        0       no error   
  endpoint-1157-regeneration-recovery                                         never          never        0       no error   
  endpoint-1372-regeneration-recovery                                         never          never        0       no error   
  endpoint-1730-regeneration-recovery                                         never          never        0       no error   
  endpoint-1818-regeneration-recovery                                         never          never        0       no error   
  endpoint-1840-regeneration-recovery                                         never          never        0       no error   
  endpoint-2180-regeneration-recovery                                         never          never        0       no error   
  endpoint-2211-regeneration-recovery                                         never          never        0       no error   
  endpoint-2611-regeneration-recovery                                         never          never        0       no error   
  endpoint-265-regeneration-recovery                                          never          never        0       no error   
  endpoint-2708-regeneration-recovery                                         never          never        0       no error   
  endpoint-2776-regeneration-recovery                                         never          never        0       no error   
  endpoint-312-regeneration-recovery                                          never          never        0       no error   
  endpoint-3129-regeneration-recovery                                         never          never        0       no error   
  endpoint-323-regeneration-recovery                                          never          never        0       no error   
  endpoint-3253-regeneration-recovery                                         never          never        0       no error   
  endpoint-338-regeneration-recovery                                          never          never        0       no error   
  endpoint-3601-regeneration-recovery                                         never          never        0       no error   
  endpoint-361-regeneration-recovery                                          never          never        0       no error   
  endpoint-369-regeneration-recovery                                          never          never        0       no error   
  endpoint-3884-regeneration-recovery                                         never          never        0       no error   
  endpoint-3931-regeneration-recovery                                         never          never        0       no error   
  endpoint-745-regeneration-recovery                                          never          never        0       no error   
  endpoint-832-regeneration-recovery                                          never          never        0       no error   
  endpoint-84-regeneration-recovery                                           never          never        0       no error   
  endpoint-889-regeneration-recovery                                          never          never        0       no error   
  endpoint-gc                                                                 3m38s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                        32s ago        never        0       no error   
  ipcache-inject-labels                                                       33s ago        never        0       no error   
  k8s-heartbeat                                                               8s ago         never        0       no error   
  link-cache                                                                  2s ago         never        0       no error   
  node-neighbor-link-updater                                                  3s ago         never        0       no error   
  resolve-identity-1130                                                       3m1s ago       never        0       no error   
  resolve-identity-1372                                                       3m1s ago       never        0       no error   
  resolve-identity-3129                                                       3m1s ago       never        0       no error   
  resolve-identity-3253                                                       3m32s ago      never        0       no error   
  resolve-identity-3601                                                       3m1s ago       never        0       no error   
  resolve-identity-361                                                        3m33s ago      never        0       no error   
  resolve-identity-369                                                        3m1s ago       never        0       no error   
  resolve-identity-84                                                         3m1s ago       never        0       no error   
  resolve-labels-/                                                            38m33s ago     never        0       no error   
  resolve-labels-cert-manager/cert-manager-77cdc7956d-xj7vw                   38m28s ago     never        0       no error   
  resolve-labels-cert-manager/cert-manager-cainjector-7477d56b47-p8h82        38m29s ago     never        0       no error   
  resolve-labels-cert-manager/cert-manager-webhook-6d5cb854fc-gp94j           38m28s ago     never        0       no error   
  resolve-labels-flux-system/helm-controller-8b6b769d4-9l6gp                  38m28s ago     never        0       no error   
  resolve-labels-flux-system/image-automation-controller-79447887bb-45xt5     38m28s ago     never        0       no error   
  resolve-labels-flux-system/image-reflector-controller-65df777f5c-bwn9d      38m29s ago     never        0       no error   
  resolve-labels-flux-system/kustomize-controller-78b78bf57d-sx42s            38m29s ago     never        0       no error   
  resolve-labels-flux-system/notification-controller-685bdc466d-kcqmc         38m28s ago     never        0       no error   
  resolve-labels-flux-system/source-controller-7944c8d8b4-fm8bt               38m28s ago     never        0       no error   
  resolve-labels-kube-system/coredns-6799fbcd5-nfdkr                          38m29s ago     never        0       no error   
  resolve-labels-kube-system/hubble-relay-f4457696c-r2rg7                     38m33s ago     never        0       no error   
  resolve-labels-kube-system/hubble-ui-75f899dc7c-jnphv                       38m29s ago     never        0       no error   
  resolve-labels-kube-system/k8tz-6c9d89b4bf-drdcm                            38m29s ago     never        0       no error   
  resolve-labels-kube-system/metrics-server-bc7c58fdf-wnd6t                   38m28s ago     never        0       no error   
  resolve-labels-kube-system/reloader-7fb44dcc5f-fmsxj                        38m28s ago     never        0       no error   
  resolve-labels-network/echo-server-7975c47f84-l9pfk                         38m29s ago     never        0       no error   
  resolve-labels-network/ingress-nginx-internal-controller-5d8459498c-gz5jp   38m28s ago     never        0       no error   
  resolve-labels-network/k8s-gateway-67ff7c6b99-qbzzk                         38m28s ago     never        0       no error   
  resolve-labels-storage/minio-0                                              38m28s ago     never        0       no error   
  resolve-labels-storage/minio-kes-6777b4676f-j6sfq                           38m28s ago     never        0       no error   
  resolve-labels-storage/minio-kes-6777b4676f-w866r                           38m29s ago     never        0       no error   
  resolve-labels-storage/openebs-zfs-localpv-controller-6c66fff5bd-trkl2      38m28s ago     never        0       no error   
  resolve-labels-storage/snapshot-controller-6c64f66dc-tmwtc                  38m28s ago     never        0       no error   
  resolve-labels-storage/snapshot-validation-webhook-5697d649bc-vgwmq         38m28s ago     never        0       no error   
  resolve-labels-system-upgrade/system-upgrade-controller-d67784b5b-4rw8c     38m28s ago     never        0       no error   
  restoring-ep-identity (1037)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (1130)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (1157)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (1372)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (1730)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (1818)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (1840)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (2180)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (2211)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (2611)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (265)                                                 38m33s ago     never        0       no error   
  restoring-ep-identity (2708)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (2776)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (312)                                                 38m33s ago     never        0       no error   
  restoring-ep-identity (3129)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (323)                                                 38m33s ago     never        0       no error   
  restoring-ep-identity (338)                                                 38m33s ago     never        0       no error   
  restoring-ep-identity (3601)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (369)                                                 38m33s ago     never        0       no error   
  restoring-ep-identity (3884)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (3931)                                                38m33s ago     never        0       no error   
  restoring-ep-identity (745)                                                 38m33s ago     never        0       no error   
  restoring-ep-identity (832)                                                 38m33s ago     never        0       no error   
  restoring-ep-identity (84)                                                  38m33s ago     never        0       no error   
  restoring-ep-identity (889)                                                 38m33s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                              38m33s ago     never        0       no error   
  sync-policymap-1037                                                         8m29s ago      never        0       no error   
  sync-policymap-1130                                                         8m29s ago      never        0       no error   
  sync-policymap-1157                                                         8m29s ago      never        0       no error   
  sync-policymap-1372                                                         8m29s ago      never        0       no error   
  sync-policymap-1730                                                         8m29s ago      never        0       no error   
  sync-policymap-1818                                                         8m29s ago      never        0       no error   
  sync-policymap-1840                                                         8m29s ago      never        0       no error   
  sync-policymap-2180                                                         8m29s ago      never        0       no error   
  sync-policymap-2211                                                         8m29s ago      never        0       no error   
  sync-policymap-2611                                                         8m29s ago      never        0       no error   
  sync-policymap-265                                                          8m29s ago      never        0       no error   
  sync-policymap-2708                                                         8m28s ago      never        0       no error   
  sync-policymap-2776                                                         8m29s ago      never        0       no error   
  sync-policymap-312                                                          8m29s ago      never        0       no error   
  sync-policymap-3129                                                         8m29s ago      never        0       no error   
  sync-policymap-323                                                          8m29s ago      never        0       no error   
  sync-policymap-3253                                                         8m28s ago      never        0       no error   
  sync-policymap-338                                                          8m29s ago      never        0       no error   
  sync-policymap-3601                                                         8m29s ago      never        0       no error   
  sync-policymap-361                                                          8m28s ago      never        0       no error   
  sync-policymap-369                                                          8m29s ago      never        0       no error   
  sync-policymap-3884                                                         8m29s ago      never        0       no error   
  sync-policymap-3931                                                         8m29s ago      never        0       no error   
  sync-policymap-745                                                          8m30s ago      never        0       no error   
  sync-policymap-832                                                          8m28s ago      never        0       no error   
  sync-policymap-84                                                           8m29s ago      never        0       no error   
  sync-policymap-889                                                          8m29s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1037)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1130)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1157)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1372)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1730)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1818)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1840)                                           9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2180)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2211)                                           10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2611)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (265)                                            11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2708)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2776)                                           9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (312)                                            11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3129)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (323)                                            10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (338)                                            10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3601)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (361)                                            9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (369)                                            11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3884)                                           11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3931)                                           9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (832)                                            9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (84)                                             11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (889)                                            10s ago        never        0       no error   
  sync-utime                                                                  33s ago        never        0       no error   
  waiting-initial-global-identities-ep (1037)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (1130)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (1157)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (1372)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (1730)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (1818)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (1840)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (2180)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (2211)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (2611)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (265)                                  38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (2708)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (2776)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (312)                                  38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (3129)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (323)                                  38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (338)                                  38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (3601)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (369)                                  38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (3884)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (3931)                                 38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (832)                                  38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (84)                                   38m33s ago     never        0       no error   
  waiting-initial-global-identities-ep (889)                                  38m33s ago     never        0       no error   
  write-cni-file                                                              38m38s ago     never        0       no error   
Proxy Status:            OK, ip 10.10.0.104, 0 redirects active on ports 10000-20000, Envoy: embedded
Global Identity Range:   min 65536, max 131071
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 67.03   Metrics: Ok
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                lan      192.168.1.11 192.168.1.10 fd61:e2c9:ba8b:0:8f4:f8ff:fe8e:5c8c 2a02:768:1b10:ac5e:8f4:f8ff:fe8e:5c8c fe80::8f4:f8ff:fe8e:5c8c (Direct Routing)
  Mode:                   Hybrid
    DSR Dispatch Mode:    IP Option/Extension
  Backend Selection:      Maglev (Table Size: 16381)
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   147297
  TCP connection tracking       294595
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           294595
  Neighbor table                294595
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              147297
  Tunnel                        65536
Encryption:                     Disabled        
Cluster health:                 1/1 reachable   (2024-08-04T16:41:17Z)
  Name                          IP              Node        Endpoints
  home-storage/h1 (localhost)   192.168.1.11    reachable   reachable
Modules Health:
      agent
      ├── controlplane
      │   ├── auth
      │   │   ├── observer-job-auth gc-identity-events            [OK] Primed (38m, x1)
      │   │   ├── observer-job-auth request-authentication        [OK] Primed (38m, x1)
      │   │   └── timer-job-auth gc-cleanup                       [OK] OK (53.13µs) (3m38s, x1)
      │   ├── bgp-control-plane
      │   │   ├── job-bgp-controller                              [OK] Running (38m, x1)
      │   │   ├── job-bgp-policy-observer                         [OK] Running (38m, x1)
      │   │   ├── job-bgpcp-resource-store-events                 [OK] Running (38m, x5)
      │   │   ├── job-cilium-node-observer                        [OK] Running (38m, x1)
      │   │   └── job-diffstore-events                            [OK] Running (38m, x2)
      │   ├── clustermesh
      │   │   ├── job-clustermesh-ipset-notifier                  [OK] Running (38m, x1)
      │   │   └── job-clustermesh-nodemanager-notifier            [OK] Running (38m, x1)
      │   ├── daemon
      │   │   ├──                                                 [OK] daemon-validate-config (56s, x38)
      │   │   ├── ep-bpf-prog-watchdog
      │   │   │   └── ep-bpf-prog-watchdog                        [OK] ep-bpf-prog-watchdog (2s, x78)
      │   │   └── job-sync-hostips                                [OK] Synchronized (33s, x39)
      │   ├── endpoint-manager
      │   │   ├── cilium-endpoint-1037 (network/k8s-gateway-67ff7c6b99-qbzzk)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1037) (1s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1037 (8m29s, x3)
      │   │   ├── cilium-endpoint-1130 (flux-system/kustomize-controller-78b78bf57d-sx42s)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1130) (1s, x233)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (13m, x4)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1130 (8m29s, x3)
      │   │   ├── cilium-endpoint-1157 (kube-system/hubble-ui-75f899dc7c-jnphv)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1157) (0s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1157 (8m29s, x3)
      │   │   ├── cilium-endpoint-1372 (flux-system/image-reflector-controller-65df777f5c-bwn9d)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1372) (1s, x233)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (13m, x4)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1372 (8m29s, x3)
      │   │   ├── cilium-endpoint-1730 (kube-system/coredns-6799fbcd5-nfdkr)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1730) (0s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1730 (8m29s, x3)
      │   │   ├── cilium-endpoint-1818 (cert-manager/cert-manager-77cdc7956d-xj7vw)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1818) (0s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1818 (8m29s, x3)
      │   │   ├── cilium-endpoint-1840 (kube-system/reloader-7fb44dcc5f-fmsxj)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1840) (9s, x231)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1840 (8m29s, x3)
      │   │   ├── cilium-endpoint-2180 (system-upgrade/system-upgrade-controller-d67784b5b-4rw8c)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2180) (1s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2180 (8m29s, x3)
      │   │   ├── cilium-endpoint-2211 (cert-manager/cert-manager-webhook-6d5cb854fc-gp94j)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2211) (0s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2211 (8m29s, x3)
      │   │   ├── cilium-endpoint-2611 (cert-manager/cert-manager-cainjector-7477d56b47-p8h82)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2611) (1s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2611 (8m29s, x3)
      │   │   ├── cilium-endpoint-265 (network/echo-server-7975c47f84-l9pfk)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (265) (1s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-265 (8m29s, x3)
      │   │   ├── cilium-endpoint-2708 (storage/minio-kes-6777b4676f-j6sfq)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2708) (1s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2708 (8m28s, x3)
      │   │   ├── cilium-endpoint-2776 (storage/snapshot-controller-6c64f66dc-tmwtc)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2776) (9s, x231)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2776 (8m29s, x3)
      │   │   ├── cilium-endpoint-312 (storage/openebs-zfs-localpv-controller-6c66fff5bd-trkl2)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (312) (1s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-312 (8m29s, x3)
      │   │   ├── cilium-endpoint-3129 (flux-system/image-automation-controller-79447887bb-45xt5)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3129) (1s, x233)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (13m, x5)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3129 (8m29s, x3)
      │   │   ├── cilium-endpoint-323 (kube-system/k8tz-6c9d89b4bf-drdcm)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (323) (0s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-323 (8m29s, x3)
      │   │   ├── cilium-endpoint-3253 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3253 (8m28s, x3)
      │   │   ├── cilium-endpoint-338 (kube-system/metrics-server-bc7c58fdf-wnd6t)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (338) (0s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-338 (8m29s, x3)
      │   │   ├── cilium-endpoint-3601 (flux-system/notification-controller-685bdc466d-kcqmc)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3601) (1s, x233)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (13m, x5)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3601 (8m29s, x3)
      │   │   ├── cilium-endpoint-361 (kube-system/hubble-relay-f4457696c-r2rg7)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (361) (9s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-361 (8m28s, x3)
      │   │   ├── cilium-endpoint-369 (flux-system/helm-controller-8b6b769d4-9l6gp)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (369) (1s, x233)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (13m, x5)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-369 (8m29s, x3)
      │   │   ├── cilium-endpoint-3884 (storage/minio-kes-6777b4676f-w866r)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3884) (1s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3884 (8m29s, x3)
      │   │   ├── cilium-endpoint-3931 (storage/minio-0)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3931) (9s, x231)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3931 (8m29s, x3)
      │   │   ├── cilium-endpoint-745 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-745 (8m30s, x3)
      │   │   ├── cilium-endpoint-832 (storage/snapshot-validation-webhook-5697d649bc-vgwmq)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (832) (9s, x231)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x1)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-832 (8m28s, x3)
      │   │   ├── cilium-endpoint-84 (flux-system/source-controller-7944c8d8b4-fm8bt)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (84) (1s, x233)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (13m, x5)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-84 (8m29s, x3)
      │   │   ├── cilium-endpoint-889 (network/ingress-nginx-internal-controller-5d8459498c-gz5jp)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (889) (0s, x232)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38m, x2)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-889 (8m29s, x3)
      │   │   └── endpoint-gc                                     [OK] endpoint-gc (3m38s, x8)
      │   ├── envoy-proxy
      │   │   └── timer-job-version-check                         [OK] OK (56.807578ms) (3m33s, x1)
      │   ├── l2-announcer
      │   │   ├── job-l2-announcer run                            [OK] Running (38m, x1)
      │   │   ├── leader-election
      │   │   │   ├── job-leader-election/network/ingress-nginx-internal-controller  [OK] Running (38m, x1)
      │   │   │   └── job-leader-election/network/k8s-gateway     [OK] Running (38m, x1)
      │   │   └── timer-job-l2-announcer lease-gc                 [OK] OK (3.629376ms) (38s, x1)
      │   ├── nat-stats
      │   │   └── timer-job-nat-stats                             [OK] OK (3.305272ms) (3s, x1)
      │   ├── node-manager
      │   │   ├── background-sync                                 [OK] Node validation successful (12s, x55)
      │   │   ├── node-checkpoint-writer                          [OK] node checkpoint written (37m, x2)
      │   │   ├── nodes-add                                       [OK] Node adds successful (38m, x1)
      │   │   └── nodes-delete                                    [OK] Node deletions successful (38m, x1)
      │   ├── service-manager
      │   │   └── job-ServiceReconciler                           [OK] 2 NodePort frontend addresses (38m, x1)
      │   ├── service-resolver
      │   │   └── job-service-reloader-initializer                [OK] Running (38m, x1)
      │   ├── stale-endpoint-cleanup
      │   │   └── job-endpoint-cleanup                            [OK] Running (38m, x1)
      │   └── timer-job-device-reloader                           [OK] OK (9m49.300183813s) (6m36s, x1)
      ├── datapath
      │   ├── agent-liveness-updater
      │   │   └── timer-job-agent-liveness-updater                [OK] OK (22.992µs) (0s, x1)
      │   ├── iptables
      │   │   ├── ipset
      │   │   │   ├── job-ipset-init-finalizer                    [OK] Running (38m, x1)
      │   │   │   └── job-reconciler-loop                         [OK] OK, 1 objects (8m38s, x9)
      │   │   └── job-iptables-reconciliation-loop                [OK] iptables rules full reconciliation completed (38m, x1)
      │   ├── l2-responder
      │   │   └── job-l2-responder-reconciler                     [OK] Running (38m, x1)
      │   ├── maps
      │   │   └── bwmap
      │   │       └── timer-job-pressure-metric-throttle          [OK] OK (3.126µs) (3s, x1)
      │   ├── node-address
      │   │   └── job-node-address-update                         [OK] Running (38m, x1)
      │   └── sysctl
      │       └── job-reconciler-loop                             [OK] OK, 16 objects (8m38s, x21)
      └── infra
          └── k8s-synced-crdsync
              └── job-sync-crds                                   [OK] Running (38m, x1)
      
