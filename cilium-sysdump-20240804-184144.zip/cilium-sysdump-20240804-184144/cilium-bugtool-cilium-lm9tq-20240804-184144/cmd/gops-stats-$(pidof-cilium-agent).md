goroutines: 671
OS threads: 25
GOMAXPROCS: 8
num CPU: 8
