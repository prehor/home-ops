filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_to_container-lxc5d9688897f63 direct-action not_in_hw id 4157 tag fbbc090b0d8ab7d6 jited 
