[
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.160",
          "nodeName": "h1",
          "port": 8443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "k8tz",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.207.131",
        "port": 443,
        "scope": "external"
      },
      "id": 10
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.160",
            "nodeName": "h1",
            "port": 8443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "k8tz",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.207.131",
          "port": 443,
          "scope": "external"
        },
        "id": 10
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 10254,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller-metrics",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.45.147",
        "port": 10254,
        "scope": "external"
      },
      "id": 24
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 10254,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller-metrics",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.45.147",
          "port": 10254,
          "scope": "external"
        },
        "id": 24
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "0.0.0.0",
        "port": 30681,
        "scope": "external"
      },
      "id": 23
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "0.0.0.0",
          "port": 30681,
          "scope": "external"
        },
        "id": 23
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.88",
          "nodeName": "h1",
          "port": 9090,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "notification-controller",
        "namespace": "flux-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.233.8",
        "port": 80,
        "scope": "external"
      },
      "id": 4
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.88",
            "nodeName": "h1",
            "port": 9090,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "notification-controller",
          "namespace": "flux-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.233.8",
          "port": 80,
          "scope": "external"
        },
        "id": 4
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 8443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller-admission",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.200.111",
        "port": 443,
        "scope": "external"
      },
      "id": 15
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 8443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller-admission",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.200.111",
          "port": 443,
          "scope": "external"
        },
        "id": 15
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "192.168.1.11",
        "port": 30681,
        "scope": "external"
      },
      "id": 43
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "192.168.1.11",
          "port": 30681,
          "scope": "external"
        },
        "id": 43
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.103",
          "nodeName": "h1",
          "port": 9000,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio",
        "namespace": "storage",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.182.189",
        "port": 9000,
        "scope": "external"
      },
      "id": 30
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.103",
            "nodeName": "h1",
            "port": 9000,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio",
          "namespace": "storage",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.182.189",
          "port": 9000,
          "scope": "external"
        },
        "id": 30
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.148",
          "nodeName": "h1",
          "port": 53,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.0.10",
        "port": 53,
        "scope": "external"
      },
      "id": 11
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.148",
            "nodeName": "h1",
            "port": 53,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.0.10",
          "port": 53,
          "scope": "external"
        },
        "id": 11
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.29",
          "nodeName": "h1",
          "port": 1053,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "k8s-gateway",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "192.168.1.11",
        "port": 32726,
        "scope": "external"
      },
      "id": 44
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.29",
            "nodeName": "h1",
            "port": 1053,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "k8s-gateway",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "192.168.1.11",
          "port": 32726,
          "scope": "external"
        },
        "id": 44
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.20.152",
        "port": 443,
        "scope": "external"
      },
      "id": 17
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.20.152",
          "port": 443,
          "scope": "external"
        },
        "id": 17
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 80,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.20.152",
        "port": 80,
        "scope": "external"
      },
      "id": 16
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 80,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.20.152",
          "port": 80,
          "scope": "external"
        },
        "id": 16
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 80,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "0.0.0.0",
        "port": 30571,
        "scope": "external"
      },
      "id": 21
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 80,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "0.0.0.0",
          "port": 30571,
          "scope": "external"
        },
        "id": 21
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.29",
          "nodeName": "h1",
          "port": 1053,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "k8s-gateway",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "LoadBalancer"
      },
      "frontend-address": {
        "ip": "192.168.1.19",
        "port": 53,
        "scope": "external"
      },
      "id": 26
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.29",
            "nodeName": "h1",
            "port": 1053,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "k8s-gateway",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "LoadBalancer"
        },
        "frontend-address": {
          "ip": "192.168.1.19",
          "port": 53,
          "scope": "external"
        },
        "id": 26
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 80,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "LoadBalancer"
      },
      "frontend-address": {
        "ip": "192.168.1.17",
        "port": 80,
        "scope": "external"
      },
      "id": 19
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 80,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "LoadBalancer"
        },
        "frontend-address": {
          "ip": "192.168.1.17",
          "port": 80,
          "scope": "external"
        },
        "id": 19
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.137",
          "nodeName": "h1",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-server",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.43.95",
        "port": 8080,
        "scope": "external"
      },
      "id": 14
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.137",
            "nodeName": "h1",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-server",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.43.95",
          "port": 8080,
          "scope": "external"
        },
        "id": 14
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.71",
          "nodeName": "h1",
          "port": 9090,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "source-controller",
        "namespace": "flux-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.167.174",
        "port": 80,
        "scope": "external"
      },
      "id": 5
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.71",
            "nodeName": "h1",
            "port": 9090,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "source-controller",
          "namespace": "flux-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.167.174",
          "port": 80,
          "scope": "external"
        },
        "id": 5
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.36",
          "nodeName": "h1",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "metrics-server",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.117.252",
        "port": 443,
        "scope": "external"
      },
      "id": 13
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.36",
            "nodeName": "h1",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "metrics-server",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.117.252",
          "port": 443,
          "scope": "external"
        },
        "id": 13
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.51",
          "nodeName": "h1",
          "port": 9402,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cert-manager",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.186.206",
        "port": 9402,
        "scope": "external"
      },
      "id": 1
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.51",
            "nodeName": "h1",
            "port": 9402,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cert-manager",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.186.206",
          "port": 9402,
          "scope": "external"
        },
        "id": 1
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "192.168.1.11",
          "nodeName": "h1",
          "port": 4244,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.88.204",
        "port": 443,
        "scope": "external"
      },
      "id": 7
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "192.168.1.11",
            "nodeName": "h1",
            "port": 4244,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.88.204",
          "port": 443,
          "scope": "external"
        },
        "id": 7
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.204",
          "nodeName": "h1",
          "port": 8081,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-ui",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.213.89",
        "port": 80,
        "scope": "external"
      },
      "id": 9
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.204",
            "nodeName": "h1",
            "port": 8081,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-ui",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.213.89",
          "port": 80,
          "scope": "external"
        },
        "id": 9
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.29",
          "nodeName": "h1",
          "port": 1053,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "k8s-gateway",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.240.226",
        "port": 53,
        "scope": "external"
      },
      "id": 25
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.29",
            "nodeName": "h1",
            "port": 1053,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "k8s-gateway",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.240.226",
          "port": 53,
          "scope": "external"
        },
        "id": 25
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.161",
          "nodeName": "h1",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cert-manager-webhook",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.234.10",
        "port": 443,
        "scope": "external"
      },
      "id": 2
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.161",
            "nodeName": "h1",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cert-manager-webhook",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.234.10",
          "port": 443,
          "scope": "external"
        },
        "id": 2
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 80,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "192.168.1.11",
        "port": 30571,
        "scope": "external"
      },
      "id": 42
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 80,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "192.168.1.11",
          "port": 30571,
          "scope": "external"
        },
        "id": 42
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.148",
          "nodeName": "h1",
          "port": 9153,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.0.10",
        "port": 9153,
        "scope": "external"
      },
      "id": 12
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.148",
            "nodeName": "h1",
            "port": 9153,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.0.10",
          "port": 9153,
          "scope": "external"
        },
        "id": 12
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.37",
          "nodeName": "h1",
          "port": 7373,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.10.0.151",
          "nodeName": "h1",
          "port": 7373,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio-kes",
        "namespace": "storage",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.167.155",
        "port": 7373,
        "scope": "external"
      },
      "id": 29
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.37",
            "nodeName": "h1",
            "port": 7373,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.10.0.151",
            "nodeName": "h1",
            "port": 7373,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio-kes",
          "namespace": "storage",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.167.155",
          "port": 7373,
          "scope": "external"
        },
        "id": 29
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.103",
          "nodeName": "h1",
          "port": 9001,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio",
        "namespace": "storage",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.182.189",
        "port": 9001,
        "scope": "external"
      },
      "id": 31
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.103",
            "nodeName": "h1",
            "port": 9001,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio",
          "namespace": "storage",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.182.189",
          "port": 9001,
          "scope": "external"
        },
        "id": 31
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "192.168.1.11",
          "port": 6443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.0.1",
        "port": 443,
        "scope": "external"
      },
      "id": 3
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "192.168.1.11",
            "port": 6443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.0.1",
          "port": 443,
          "scope": "external"
        },
        "id": 3
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.62",
          "nodeName": "h1",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "ingress-nginx-internal-controller",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "LoadBalancer"
      },
      "frontend-address": {
        "ip": "192.168.1.17",
        "port": 443,
        "scope": "external"
      },
      "id": 18
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.62",
            "nodeName": "h1",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "ingress-nginx-internal-controller",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "LoadBalancer"
        },
        "frontend-address": {
          "ip": "192.168.1.17",
          "port": 443,
          "scope": "external"
        },
        "id": 18
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.149",
          "nodeName": "h1",
          "port": 4245,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-relay",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.194.196",
        "port": 80,
        "scope": "external"
      },
      "id": 8
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.149",
            "nodeName": "h1",
            "port": 4245,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-relay",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.194.196",
          "port": 80,
          "scope": "external"
        },
        "id": 8
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.29",
          "nodeName": "h1",
          "port": 1053,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "k8s-gateway",
        "namespace": "network",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "0.0.0.0",
        "port": 32726,
        "scope": "external"
      },
      "id": 28
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.29",
            "nodeName": "h1",
            "port": 1053,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "k8s-gateway",
          "namespace": "network",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "0.0.0.0",
          "port": 32726,
          "scope": "external"
        },
        "id": 28
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.35",
          "nodeName": "h1",
          "port": 8443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "snapshot-validation-webhook",
        "namespace": "storage",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.75.113",
        "port": 443,
        "scope": "external"
      },
      "id": 32
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.35",
            "nodeName": "h1",
            "port": 8443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "snapshot-validation-webhook",
          "namespace": "storage",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.75.113",
          "port": 443,
          "scope": "external"
        },
        "id": 32
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.10.0.88",
          "nodeName": "h1",
          "port": 9292,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "webhook-receiver",
        "namespace": "flux-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.11.160.141",
        "port": 80,
        "scope": "external"
      },
      "id": 6
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.10.0.88",
            "nodeName": "h1",
            "port": 9292,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "webhook-receiver",
          "namespace": "flux-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.11.160.141",
          "port": 80,
          "scope": "external"
        },
        "id": 6
      }
    }
  }
]

