Total: 883
TCP:   753 (estab 402, closed 318, orphaned 1, timewait 188)

Transport Total     IP        IPv6
RAW	  2         2         0        
UDP	  3         2         1        
TCP	  435       374       61       
INET	  440       378       62       
FRAG	  0         0         0        

State  Recv-Q Send-Q Local Address:Port  Peer Address:PortProcess                                                                                                                                                                                                                                                                         
UNCONN 0      0            0.0.0.0:111        0.0.0.0:*    ino:17529 sk:5015 cgroup:/system.slice/rpcbind.socket <->                                                                                                                                                                                                                      
UNCONN 0      0          127.0.0.1:37317      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=53)) ino:200833 sk:aa19 fwmark:0xb00 cgroup:/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e6ab653_a903_4f9e_a05c_858166617590.slice/cri-containerd-63a915cbd65a4bdacbb1d2b03694b8c26ac9ed828e289d833515af601341d365.scope <->
UNCONN 0      0               [::]:111           [::]:*    ino:18741 sk:c8f8 cgroup:/system.slice/rpcbind.socket v6only:1 <->                                                                                                                                                                                                             
