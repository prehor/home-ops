Local AS   Peer AS   Peer Address   Session   Uptime   Family   Received   Advertised
