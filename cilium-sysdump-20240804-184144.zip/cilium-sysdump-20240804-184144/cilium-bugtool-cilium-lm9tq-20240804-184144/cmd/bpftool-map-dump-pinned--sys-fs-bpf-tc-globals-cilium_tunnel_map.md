Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_tunnel_map): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_tunnel_map':  exit status 255

