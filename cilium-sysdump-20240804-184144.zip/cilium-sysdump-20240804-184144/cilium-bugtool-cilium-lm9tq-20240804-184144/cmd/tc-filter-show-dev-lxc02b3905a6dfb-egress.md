filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_to_container-lxc02b3905a6dfb direct-action not_in_hw id 4436 tag 70b7fae252447d7a jited 
