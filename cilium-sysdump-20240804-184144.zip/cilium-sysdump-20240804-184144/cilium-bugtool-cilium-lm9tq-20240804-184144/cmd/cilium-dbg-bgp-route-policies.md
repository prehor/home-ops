VRouter   Policy Name   Type   Match Peers   Match Prefixes (Min..Max Len)   RIB Action   Path Actions
