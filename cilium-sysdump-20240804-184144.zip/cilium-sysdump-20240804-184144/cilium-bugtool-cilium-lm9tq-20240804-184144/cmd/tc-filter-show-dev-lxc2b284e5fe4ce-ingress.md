filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2b284e5fe4ce direct-action not_in_hw id 4423 tag eadcd298a6c610e5 jited 
