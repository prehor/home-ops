xdp:

tc:
lan(6) clsact/ingress cil_from_netdev-lan id 4245
lan(6) clsact/egress cil_to_netdev-lan id 4277
cilium_net(8) clsact/ingress cil_to_host-cilium_net id 4239
cilium_host(9) clsact/ingress cil_to_host-cilium_host id 4135
cilium_host(9) clsact/egress cil_from_host-cilium_host id 4134
lxcf228d89e07e3(13) clsact/ingress cil_from_container-lxcf228d89e07e3 id 4203
lxcf228d89e07e3(13) clsact/egress cil_to_container-lxcf228d89e07e3 id 4185
lxc5d9688897f63(15) clsact/ingress cil_from_container-lxc5d9688897f63 id 4155
lxc5d9688897f63(15) clsact/egress cil_to_container-lxc5d9688897f63 id 4157
lxc02b3905a6dfb(17) clsact/ingress cil_from_container-lxc02b3905a6dfb id 4434
lxc02b3905a6dfb(17) clsact/egress cil_to_container-lxc02b3905a6dfb id 4436
lxc859384ae38a5(19) clsact/ingress cil_from_container-lxc859384ae38a5 id 4053
lxc859384ae38a5(19) clsact/egress cil_to_container-lxc859384ae38a5 id 4056
lxc503b32a2c6a7(21) clsact/ingress cil_from_container-lxc503b32a2c6a7 id 4092
lxc503b32a2c6a7(21) clsact/egress cil_to_container-lxc503b32a2c6a7 id 4091
lxc910004d47ea4(23) clsact/ingress cil_from_container-lxc910004d47ea4 id 4002
lxc910004d47ea4(23) clsact/egress cil_to_container-lxc910004d47ea4 id 4047
lxce3e3ac922558(27) clsact/ingress cil_from_container-lxce3e3ac922558 id 4196
lxce3e3ac922558(27) clsact/egress cil_to_container-lxce3e3ac922558 id 4220
lxcbadff7f8234a(29) clsact/ingress cil_from_container-lxcbadff7f8234a id 4176
lxcbadff7f8234a(29) clsact/egress cil_to_container-lxcbadff7f8234a id 4191
lxcef0c82914670(31) clsact/ingress cil_from_container-lxcef0c82914670 id 4425
lxcef0c82914670(31) clsact/egress cil_to_container-lxcef0c82914670 id 4424
lxc2b284e5fe4ce(33) clsact/ingress cil_from_container-lxc2b284e5fe4ce id 4423
lxc2b284e5fe4ce(33) clsact/egress cil_to_container-lxc2b284e5fe4ce id 4394
lxcd458e6709d60(35) clsact/ingress cil_from_container-lxcd458e6709d60 id 4255
lxcd458e6709d60(35) clsact/egress cil_to_container-lxcd458e6709d60 id 4207
lxc4c920d1320f1(37) clsact/ingress cil_from_container-lxc4c920d1320f1 id 4248
lxc4c920d1320f1(37) clsact/egress cil_to_container-lxc4c920d1320f1 id 4249
lxcfd427869bc62(39) clsact/ingress cil_from_container-lxcfd427869bc62 id 4142
lxcfd427869bc62(39) clsact/egress cil_to_container-lxcfd427869bc62 id 4146
lxce316820ded76(41) clsact/ingress cil_from_container-lxce316820ded76 id 4432
lxce316820ded76(41) clsact/egress cil_to_container-lxce316820ded76 id 4418
lxc3b052960bf39(43) clsact/ingress cil_from_container-lxc3b052960bf39 id 4406
lxc3b052960bf39(43) clsact/egress cil_to_container-lxc3b052960bf39 id 4411
lxc83b895bb0fa9(45) clsact/ingress cil_from_container-lxc83b895bb0fa9 id 4021
lxc83b895bb0fa9(45) clsact/egress cil_to_container-lxc83b895bb0fa9 id 4022
lxcf8bd3ef502c5(47) clsact/ingress cil_from_container-lxcf8bd3ef502c5 id 4075
lxcf8bd3ef502c5(47) clsact/egress cil_to_container-lxcf8bd3ef502c5 id 4071
lxcbdbcfb757b99(49) clsact/ingress cil_from_container-lxcbdbcfb757b99 id 4122
lxcbdbcfb757b99(49) clsact/egress cil_to_container-lxcbdbcfb757b99 id 4104
lxc3136ad64a403(51) clsact/ingress cil_from_container-lxc3136ad64a403 id 4264
lxc3136ad64a403(51) clsact/egress cil_to_container-lxc3136ad64a403 id 4217
lxccc2dfd51c9f5(53) clsact/ingress cil_from_container-lxccc2dfd51c9f5 id 4063
lxccc2dfd51c9f5(53) clsact/egress cil_to_container-lxccc2dfd51c9f5 id 4064
lxcefb5df718e0f(55) clsact/ingress cil_from_container-lxcefb5df718e0f id 4170
lxcefb5df718e0f(55) clsact/egress cil_to_container-lxcefb5df718e0f id 4128
lxcb7c0ed9dd42e(59) clsact/ingress cil_from_container-lxcb7c0ed9dd42e id 4000
lxcb7c0ed9dd42e(59) clsact/egress cil_to_container-lxcb7c0ed9dd42e id 4035
lxcbf04ad6c9b4a(61) clsact/ingress cil_from_container-lxcbf04ad6c9b4a id 4447
lxcbf04ad6c9b4a(61) clsact/egress cil_to_container-lxcbf04ad6c9b4a id 4398
lxca7a944ff01cc(63) clsact/ingress cil_from_container-lxca7a944ff01cc id 4018
lxca7a944ff01cc(63) clsact/egress cil_to_container-lxca7a944ff01cc id 4057
lxc_health(75) clsact/ingress cil_from_container-lxc_health id 4080
lxc_health(75) clsact/egress cil_to_container-lxc_health id 4151
lxcb9692533e4ab(77) clsact/ingress cil_from_container-lxcb9692533e4ab id 4077
lxcb9692533e4ab(77) clsact/egress cil_to_container-lxcb9692533e4ab id 4090

flow_dissector:

netfilter:

