2024-08-04T15:25:12,000000+00:00 Linux version 6.1.0-23-amd64 (debian-kernel@lists.debian.org) (gcc-12 (Debian 12.2.0-14) 12.2.0, GNU ld (GNU Binutils for Debian) 2.40) #1 SMP PREEMPT_DYNAMIC Debian 6.1.99-1 (2024-07-15)
2024-08-04T15:25:12,000000+00:00 Command line: BOOT_IMAGE=/BOOT/debian@/vmlinuz-6.1.0-23-amd64 root=ZFS=/ROOT/debian ro root=ZFS=zroot/ROOT/debian
2024-08-04T15:25:12,000000+00:00 BIOS-provided physical RAM map:
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x0000000000057fff] usable
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x0000000000058000-0x0000000000058fff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x0000000000059000-0x000000000009efff] usable
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x000000000009f000-0x000000000009ffff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x0000000083156fff] usable
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x0000000083157000-0x0000000083157fff] ACPI NVS
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x0000000083158000-0x00000000831a1fff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x00000000831a2000-0x000000008bc70fff] usable
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x000000008bc71000-0x000000008bcd9fff] type 20
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x000000008bcda000-0x000000008f264fff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x000000008f265000-0x000000008fb99fff] ACPI NVS
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x000000008fb9a000-0x000000008fbfefff] ACPI data
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x000000008fbff000-0x000000008fbfffff] usable
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x00000000e0000000-0x00000000efffffff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x00000000fe000000-0x00000000fe010fff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x00000000fec00000-0x00000000fec00fff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x00000000fee00000-0x00000000fee00fff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x00000000ff000000-0x00000000ffffffff] reserved
2024-08-04T15:25:12,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000086fffffff] usable
2024-08-04T15:25:12,000000+00:00 NX (Execute Disable) protection: active
2024-08-04T15:25:12,000000+00:00 efi: EFI v2.40 by American Megatrends
2024-08-04T15:25:12,000000+00:00 efi: TPMFinalLog=0x8fb69000 ACPI=0x8fbd1000 ACPI 2.0=0x8fbd1000 ESRT=0x8da51718 SMBIOS=0xf05e0 SMBIOS 3.0=0xf0600 MOKvar=0x8c2e5000 
2024-08-04T15:25:12,000000+00:00 secureboot: Secure boot disabled
2024-08-04T15:25:12,000000+00:00 SMBIOS 3.0.0 present.
2024-08-04T15:25:12,000000+00:00 DMI: ASUSTeK COMPUTER INC. P10S-C Series/P10S-C Series, BIOS 4503 07/23/2019
2024-08-04T15:25:12,000000+00:00 tsc: Detected 2100.000 MHz processor
2024-08-04T15:25:12,000000+00:00 tsc: Detected 2099.944 MHz TSC
2024-08-04T15:25:12,000521+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2024-08-04T15:25:12,000525+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2024-08-04T15:25:12,000537+00:00 last_pfn = 0x870000 max_arch_pfn = 0x400000000
2024-08-04T15:25:12,000665+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2024-08-04T15:25:12,001249+00:00 last_pfn = 0x8fc00 max_arch_pfn = 0x400000000
2024-08-04T15:25:12,011891+00:00 found SMP MP-table at [mem 0x000fce80-0x000fce8f]
2024-08-04T15:25:12,011905+00:00 esrt: Reserving ESRT space from 0x000000008da51718 to 0x000000008da51750.
2024-08-04T15:25:12,011917+00:00 Using GB pages for direct mapping
2024-08-04T15:25:12,012858+00:00 RAMDISK: [mem 0x333e7000-0x359eafff]
2024-08-04T15:25:12,012862+00:00 ACPI: Early table checksum verification disabled
2024-08-04T15:25:12,012865+00:00 ACPI: RSDP 0x000000008FBD1000 000024 (v02 ALASKA)
2024-08-04T15:25:12,012870+00:00 ACPI: XSDT 0x000000008FBD10B0 0000DC (v01 ALASKA A M I    01072009 AMI  00010013)
2024-08-04T15:25:12,012876+00:00 ACPI: FACP 0x000000008FBF38F0 00010C (v05 ALASKA A M I    01072009 AMI  00010013)
2024-08-04T15:25:12,012882+00:00 ACPI: DSDT 0x000000008FBD1228 0226C4 (v02 ALASKA A M I    01072009 INTL 20120913)
2024-08-04T15:25:12,012886+00:00 ACPI: FACS 0x000000008FB68F80 000040
2024-08-04T15:25:12,012889+00:00 ACPI: APIC 0x000000008FBF3A00 0000BC (v03 ALASKA A M I    01072009 AMI  00010013)
2024-08-04T15:25:12,012893+00:00 ACPI: FPDT 0x000000008FBF3AC0 000044 (v01 ALASKA A M I    01072009 AMI  00010013)
2024-08-04T15:25:12,012897+00:00 ACPI: FIDT 0x000000008FBF3B08 00009C (v01 ALASKA A M I    01072009 AMI  00010013)
2024-08-04T15:25:12,012900+00:00 ACPI: MCFG 0x000000008FBF3BA8 00003C (v01 ALASKA A M I    01072009 MSFT 00000097)
2024-08-04T15:25:12,012903+00:00 ACPI: HPET 0x000000008FBF3BE8 000038 (v01 ALASKA A M I    01072009 AMI. 0005000B)
2024-08-04T15:25:12,012907+00:00 ACPI: LPIT 0x000000008FBF3C20 000094 (v01 INTEL  GNLR     00000000 MSFT 0000005F)
2024-08-04T15:25:12,012911+00:00 ACPI: SSDT 0x000000008FBF3CB8 000248 (v02 INTEL  sensrhub 00000000 INTL 20120913)
2024-08-04T15:25:12,012914+00:00 ACPI: SSDT 0x000000008FBF3F00 002BAE (v02 INTEL  PtidDevc 00001000 INTL 20120913)
2024-08-04T15:25:12,012918+00:00 ACPI: SSDT 0x000000008FBF6AB0 000BE3 (v02 INTEL  Ther_Rvp 00001000 INTL 20120913)
2024-08-04T15:25:12,012921+00:00 ACPI: DBGP 0x000000008FBF7698 000034 (v01 INTEL           00000000 MSFT 0000005F)
2024-08-04T15:25:12,012925+00:00 ACPI: DBG2 0x000000008FBF76D0 000054 (v00 INTEL           00000000 MSFT 0000005F)
2024-08-04T15:25:12,012929+00:00 ACPI: SSDT 0x000000008FBF7728 000619 (v02 INTEL  xh_zumba 00000000 INTL 20120913)
2024-08-04T15:25:12,012932+00:00 ACPI: HEST 0x000000008FBFE450 0000A8 (v01 AMI    AMI.HEST 00000000 AMI. 00000000)
2024-08-04T15:25:12,012936+00:00 ACPI: SSDT 0x000000008FBF7DA0 00536B (v02 SaSsdt SaSsdt   00003000 INTL 20120913)
2024-08-04T15:25:12,012939+00:00 ACPI: UEFI 0x000000008FBFD110 000042 (v01                 00000000      00000000)
2024-08-04T15:25:12,012943+00:00 ACPI: SSDT 0x000000008FBFD158 000E73 (v02 CpuRef CpuSsdt  00003000 INTL 20120913)
2024-08-04T15:25:12,012946+00:00 ACPI: DMAR 0x000000008FBFDFD0 000070 (v01 INTEL  SKL      00000001 INTL 00000001)
2024-08-04T15:25:12,012950+00:00 ACPI: SPMI 0x000000008FBFE040 000041 (v05 ALASKA A M I    00000000 AMI. 00000000)
2024-08-04T15:25:12,012953+00:00 ACPI: TPM2 0x000000008FBFE088 000034 (v03 ALASKA A M I    00000001 AMI  00000000)
2024-08-04T15:25:12,012957+00:00 ACPI: EINJ 0x000000008FBFE0C0 000130 (v01 AMI    AMI.EINJ 00000000 AMI. 00000000)
2024-08-04T15:25:12,012961+00:00 ACPI: ERST 0x000000008FBFE1F0 000230 (v01 AMIER  AMI.ERST 00000000 AMI. 00000000)
2024-08-04T15:25:12,012964+00:00 ACPI: BERT 0x000000008FBFE420 000030 (v01 AMI    AMI.BERT 00000000 AMI. 00000000)
2024-08-04T15:25:12,012967+00:00 ACPI: Reserving FACP table memory at [mem 0x8fbf38f0-0x8fbf39fb]
2024-08-04T15:25:12,012969+00:00 ACPI: Reserving DSDT table memory at [mem 0x8fbd1228-0x8fbf38eb]
2024-08-04T15:25:12,012970+00:00 ACPI: Reserving FACS table memory at [mem 0x8fb68f80-0x8fb68fbf]
2024-08-04T15:25:12,012971+00:00 ACPI: Reserving APIC table memory at [mem 0x8fbf3a00-0x8fbf3abb]
2024-08-04T15:25:12,012972+00:00 ACPI: Reserving FPDT table memory at [mem 0x8fbf3ac0-0x8fbf3b03]
2024-08-04T15:25:12,012973+00:00 ACPI: Reserving FIDT table memory at [mem 0x8fbf3b08-0x8fbf3ba3]
2024-08-04T15:25:12,012974+00:00 ACPI: Reserving MCFG table memory at [mem 0x8fbf3ba8-0x8fbf3be3]
2024-08-04T15:25:12,012975+00:00 ACPI: Reserving HPET table memory at [mem 0x8fbf3be8-0x8fbf3c1f]
2024-08-04T15:25:12,012976+00:00 ACPI: Reserving LPIT table memory at [mem 0x8fbf3c20-0x8fbf3cb3]
2024-08-04T15:25:12,012977+00:00 ACPI: Reserving SSDT table memory at [mem 0x8fbf3cb8-0x8fbf3eff]
2024-08-04T15:25:12,012978+00:00 ACPI: Reserving SSDT table memory at [mem 0x8fbf3f00-0x8fbf6aad]
2024-08-04T15:25:12,012979+00:00 ACPI: Reserving SSDT table memory at [mem 0x8fbf6ab0-0x8fbf7692]
2024-08-04T15:25:12,012980+00:00 ACPI: Reserving DBGP table memory at [mem 0x8fbf7698-0x8fbf76cb]
2024-08-04T15:25:12,012981+00:00 ACPI: Reserving DBG2 table memory at [mem 0x8fbf76d0-0x8fbf7723]
2024-08-04T15:25:12,012982+00:00 ACPI: Reserving SSDT table memory at [mem 0x8fbf7728-0x8fbf7d40]
2024-08-04T15:25:12,012983+00:00 ACPI: Reserving HEST table memory at [mem 0x8fbfe450-0x8fbfe4f7]
2024-08-04T15:25:12,012984+00:00 ACPI: Reserving SSDT table memory at [mem 0x8fbf7da0-0x8fbfd10a]
2024-08-04T15:25:12,012985+00:00 ACPI: Reserving UEFI table memory at [mem 0x8fbfd110-0x8fbfd151]
2024-08-04T15:25:12,012986+00:00 ACPI: Reserving SSDT table memory at [mem 0x8fbfd158-0x8fbfdfca]
2024-08-04T15:25:12,012987+00:00 ACPI: Reserving DMAR table memory at [mem 0x8fbfdfd0-0x8fbfe03f]
2024-08-04T15:25:12,012988+00:00 ACPI: Reserving SPMI table memory at [mem 0x8fbfe040-0x8fbfe080]
2024-08-04T15:25:12,012989+00:00 ACPI: Reserving TPM2 table memory at [mem 0x8fbfe088-0x8fbfe0bb]
2024-08-04T15:25:12,012990+00:00 ACPI: Reserving EINJ table memory at [mem 0x8fbfe0c0-0x8fbfe1ef]
2024-08-04T15:25:12,012991+00:00 ACPI: Reserving ERST table memory at [mem 0x8fbfe1f0-0x8fbfe41f]
2024-08-04T15:25:12,012992+00:00 ACPI: Reserving BERT table memory at [mem 0x8fbfe420-0x8fbfe44f]
2024-08-04T15:25:12,013106+00:00 No NUMA configuration found
2024-08-04T15:25:12,013107+00:00 Faking a node at [mem 0x0000000000000000-0x000000086fffffff]
2024-08-04T15:25:12,013120+00:00 NODE_DATA(0) allocated [mem 0x86ffd5000-0x86fffffff]
2024-08-04T15:25:12,013437+00:00 Zone ranges:
2024-08-04T15:25:12,013438+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2024-08-04T15:25:12,013440+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2024-08-04T15:25:12,013442+00:00   Normal   [mem 0x0000000100000000-0x000000086fffffff]
2024-08-04T15:25:12,013444+00:00   Device   empty
2024-08-04T15:25:12,013445+00:00 Movable zone start for each node
2024-08-04T15:25:12,013448+00:00 Early memory node ranges
2024-08-04T15:25:12,013449+00:00   node   0: [mem 0x0000000000001000-0x0000000000057fff]
2024-08-04T15:25:12,013451+00:00   node   0: [mem 0x0000000000059000-0x000000000009efff]
2024-08-04T15:25:12,013452+00:00   node   0: [mem 0x0000000000100000-0x0000000083156fff]
2024-08-04T15:25:12,013453+00:00   node   0: [mem 0x00000000831a2000-0x000000008bc70fff]
2024-08-04T15:25:12,013454+00:00   node   0: [mem 0x000000008fbff000-0x000000008fbfffff]
2024-08-04T15:25:12,013455+00:00   node   0: [mem 0x0000000100000000-0x000000086fffffff]
2024-08-04T15:25:12,013461+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000086fffffff]
2024-08-04T15:25:12,013466+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2024-08-04T15:25:12,013468+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2024-08-04T15:25:12,013504+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2024-08-04T15:25:12,018583+00:00 On node 0, zone DMA32: 75 pages in unavailable ranges
2024-08-04T15:25:12,018781+00:00 On node 0, zone DMA32: 16270 pages in unavailable ranges
2024-08-04T15:25:12,019107+00:00 On node 0, zone Normal: 1024 pages in unavailable ranges
2024-08-04T15:25:12,019506+00:00 ACPI: PM-Timer IO Port: 0x1808
2024-08-04T15:25:12,019513+00:00 ACPI: LAPIC_NMI (acpi_id[0x01] high edge lint[0x1])
2024-08-04T15:25:12,019515+00:00 ACPI: LAPIC_NMI (acpi_id[0x02] high edge lint[0x1])
2024-08-04T15:25:12,019516+00:00 ACPI: LAPIC_NMI (acpi_id[0x03] high edge lint[0x1])
2024-08-04T15:25:12,019517+00:00 ACPI: LAPIC_NMI (acpi_id[0x04] high edge lint[0x1])
2024-08-04T15:25:12,019518+00:00 ACPI: LAPIC_NMI (acpi_id[0x05] high edge lint[0x1])
2024-08-04T15:25:12,019519+00:00 ACPI: LAPIC_NMI (acpi_id[0x06] high edge lint[0x1])
2024-08-04T15:25:12,019520+00:00 ACPI: LAPIC_NMI (acpi_id[0x07] high edge lint[0x1])
2024-08-04T15:25:12,019521+00:00 ACPI: LAPIC_NMI (acpi_id[0x08] high edge lint[0x1])
2024-08-04T15:25:12,019550+00:00 IOAPIC[0]: apic_id 2, version 32, address 0xfec00000, GSI 0-119
2024-08-04T15:25:12,019554+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2024-08-04T15:25:12,019556+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2024-08-04T15:25:12,019561+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2024-08-04T15:25:12,019562+00:00 ACPI: HPET id: 0x8086a701 base: 0xfed00000
2024-08-04T15:25:12,019565+00:00 TSC deadline timer available
2024-08-04T15:25:12,019566+00:00 smpboot: Allowing 8 CPUs, 0 hotplug CPUs
2024-08-04T15:25:12,019586+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2024-08-04T15:25:12,019589+00:00 PM: hibernation: Registered nosave memory: [mem 0x00058000-0x00058fff]
2024-08-04T15:25:12,019591+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x0009ffff]
2024-08-04T15:25:12,019592+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000fffff]
2024-08-04T15:25:12,019594+00:00 PM: hibernation: Registered nosave memory: [mem 0x83157000-0x83157fff]
2024-08-04T15:25:12,019595+00:00 PM: hibernation: Registered nosave memory: [mem 0x83158000-0x831a1fff]
2024-08-04T15:25:12,019597+00:00 PM: hibernation: Registered nosave memory: [mem 0x8bc71000-0x8bcd9fff]
2024-08-04T15:25:12,019598+00:00 PM: hibernation: Registered nosave memory: [mem 0x8bcda000-0x8f264fff]
2024-08-04T15:25:12,019598+00:00 PM: hibernation: Registered nosave memory: [mem 0x8f265000-0x8fb99fff]
2024-08-04T15:25:12,019599+00:00 PM: hibernation: Registered nosave memory: [mem 0x8fb9a000-0x8fbfefff]
2024-08-04T15:25:12,019601+00:00 PM: hibernation: Registered nosave memory: [mem 0x8fc00000-0xdfffffff]
2024-08-04T15:25:12,019602+00:00 PM: hibernation: Registered nosave memory: [mem 0xe0000000-0xefffffff]
2024-08-04T15:25:12,019603+00:00 PM: hibernation: Registered nosave memory: [mem 0xf0000000-0xfdffffff]
2024-08-04T15:25:12,019604+00:00 PM: hibernation: Registered nosave memory: [mem 0xfe000000-0xfe010fff]
2024-08-04T15:25:12,019604+00:00 PM: hibernation: Registered nosave memory: [mem 0xfe011000-0xfebfffff]
2024-08-04T15:25:12,019605+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec00000-0xfec00fff]
2024-08-04T15:25:12,019606+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec01000-0xfedfffff]
2024-08-04T15:25:12,019607+00:00 PM: hibernation: Registered nosave memory: [mem 0xfee00000-0xfee00fff]
2024-08-04T15:25:12,019608+00:00 PM: hibernation: Registered nosave memory: [mem 0xfee01000-0xfeffffff]
2024-08-04T15:25:12,019608+00:00 PM: hibernation: Registered nosave memory: [mem 0xff000000-0xffffffff]
2024-08-04T15:25:12,019610+00:00 [mem 0x8fc00000-0xdfffffff] available for PCI devices
2024-08-04T15:25:12,019612+00:00 Booting paravirtualized kernel on bare hardware
2024-08-04T15:25:12,019614+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645519600211568 ns
2024-08-04T15:25:12,025576+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:8 nr_cpu_ids:8 nr_node_ids:1
2024-08-04T15:25:12,025784+00:00 percpu: Embedded 61 pages/cpu s212992 r8192 d28672 u262144
2024-08-04T15:25:12,025792+00:00 pcpu-alloc: s212992 r8192 d28672 u262144 alloc=1*2097152
2024-08-04T15:25:12,025795+00:00 pcpu-alloc: [0] 0 1 2 3 4 5 6 7 
2024-08-04T15:25:12,025827+00:00 Fallback order for Node 0: 0 
2024-08-04T15:25:12,025831+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 8240182
2024-08-04T15:25:12,025832+00:00 Policy zone: Normal
2024-08-04T15:25:12,025833+00:00 Kernel command line: BOOT_IMAGE=/BOOT/debian@/vmlinuz-6.1.0-23-amd64 root=ZFS=/ROOT/debian ro root=ZFS=zroot/ROOT/debian
2024-08-04T15:25:12,025874+00:00 Unknown kernel command line parameters "BOOT_IMAGE=/BOOT/debian@/vmlinuz-6.1.0-23-amd64", will be passed to user space.
2024-08-04T15:25:12,025883+00:00 random: crng init done
2024-08-04T15:25:12,027663+00:00 Dentry cache hash table entries: 4194304 (order: 13, 33554432 bytes, linear)
2024-08-04T15:25:12,028552+00:00 Inode-cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2024-08-04T15:25:12,028656+00:00 mem auto-init: stack:all(zero), heap alloc:on, heap free:off
2024-08-04T15:25:12,028665+00:00 software IO TLB: area num 8.
2024-08-04T15:25:12,058996+00:00 Memory: 2247844K/33484560K available (14342K kernel code, 2332K rwdata, 9068K rodata, 2796K init, 17404K bss, 802132K reserved, 0K cma-reserved)
2024-08-04T15:25:12,059147+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=8, Nodes=1
2024-08-04T15:25:12,059160+00:00 Kernel/User page tables isolation: enabled
2024-08-04T15:25:12,059193+00:00 ftrace: allocating 40236 entries in 158 pages
2024-08-04T15:25:12,067662+00:00 ftrace: allocated 158 pages with 5 groups
2024-08-04T15:25:12,068478+00:00 Dynamic Preempt: voluntary
2024-08-04T15:25:12,068517+00:00 rcu: Preemptible hierarchical RCU implementation.
2024-08-04T15:25:12,068518+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=8.
2024-08-04T15:25:12,068519+00:00 	Trampoline variant of Tasks RCU enabled.
2024-08-04T15:25:12,068520+00:00 	Rude variant of Tasks RCU enabled.
2024-08-04T15:25:12,068521+00:00 	Tracing variant of Tasks RCU enabled.
2024-08-04T15:25:12,068522+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 25 jiffies.
2024-08-04T15:25:12,068523+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=8
2024-08-04T15:25:12,073704+00:00 NR_IRQS: 524544, nr_irqs: 2048, preallocated irqs: 16
2024-08-04T15:25:12,073922+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-08-04T15:25:12,074105+00:00 spurious 8259A interrupt: IRQ7.
2024-08-04T15:25:12,074132+00:00 Console: colour dummy device 80x25
2024-08-04T15:25:12,074476+00:00 printk: console [tty0] enabled
2024-08-04T15:25:12,074497+00:00 ACPI: Core revision 20220331
2024-08-04T15:25:12,074761+00:00 clocksource: hpet: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 79635855245 ns
2024-08-04T15:25:12,074881+00:00 APIC: Switch to symmetric I/O mode setup
2024-08-04T15:25:12,074885+00:00 DMAR: Host address width 39
2024-08-04T15:25:12,074887+00:00 DMAR: DRHD base: 0x000000fed90000 flags: 0x1
2024-08-04T15:25:12,074896+00:00 DMAR: dmar0: reg_base_addr fed90000 ver 1:0 cap d2008c40660462 ecap f050da
2024-08-04T15:25:12,074902+00:00 DMAR: RMRR base: 0x0000008efdc000 end: 0x0000008effbfff
2024-08-04T15:25:12,074907+00:00 DMAR-IR: IOAPIC id 2 under DRHD base  0xfed90000 IOMMU 0
2024-08-04T15:25:12,074910+00:00 DMAR-IR: HPET id 0 under DRHD base 0xfed90000
2024-08-04T15:25:12,074913+00:00 DMAR-IR: Queued invalidation will be enabled to support x2apic and Intr-remapping.
2024-08-04T15:25:12,076328+00:00 DMAR-IR: Enabled IRQ remapping in x2apic mode
2024-08-04T15:25:12,076332+00:00 x2apic enabled
2024-08-04T15:25:12,076349+00:00 Switched APIC routing to cluster x2apic.
2024-08-04T15:25:12,080302+00:00 ..TIMER: vector=0x30 apic1=0 pin1=2 apic2=-1 pin2=-1
2024-08-04T15:25:12,098952+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0x1e44fb6c2ab, max_idle_ns: 440795206594 ns
2024-08-04T15:25:12,098961+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 4199.88 BogoMIPS (lpj=8399776)
2024-08-04T15:25:12,098989+00:00 x86/cpu: SGX disabled by BIOS.
2024-08-04T15:25:12,098997+00:00 CPU0: Thermal monitoring enabled (TM1)
2024-08-04T15:25:12,099033+00:00 process: using mwait in idle threads
2024-08-04T15:25:12,099038+00:00 Last level iTLB entries: 4KB 64, 2MB 8, 4MB 8
2024-08-04T15:25:12,099041+00:00 Last level dTLB entries: 4KB 64, 2MB 0, 4MB 0, 1GB 4
2024-08-04T15:25:12,099046+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2024-08-04T15:25:12,099051+00:00 Spectre V2 : Mitigation: IBRS
2024-08-04T15:25:12,099053+00:00 Spectre V2 : Spectre v2 / SpectreRSB mitigation: Filling RSB on context switch
2024-08-04T15:25:12,099057+00:00 Spectre V2 : Spectre v2 / SpectreRSB : Filling RSB on VMEXIT
2024-08-04T15:25:12,099060+00:00 RETBleed: Mitigation: IBRS
2024-08-04T15:25:12,099063+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2024-08-04T15:25:12,099069+00:00 Spectre V2 : User space: Mitigation: STIBP via prctl
2024-08-04T15:25:12,099074+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl
2024-08-04T15:25:12,099085+00:00 MDS: Mitigation: Clear CPU buffers
2024-08-04T15:25:12,099089+00:00 TAA: Mitigation: Clear CPU buffers
2024-08-04T15:25:12,099093+00:00 MMIO Stale Data: Mitigation: Clear CPU buffers
2024-08-04T15:25:12,099097+00:00 SRBDS: Vulnerable: No microcode
2024-08-04T15:25:12,099101+00:00 GDS: Vulnerable: No microcode
2024-08-04T15:25:12,099110+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2024-08-04T15:25:12,099116+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2024-08-04T15:25:12,099121+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2024-08-04T15:25:12,099125+00:00 x86/fpu: Supporting XSAVE feature 0x008: 'MPX bounds registers'
2024-08-04T15:25:12,099130+00:00 x86/fpu: Supporting XSAVE feature 0x010: 'MPX CSR'
2024-08-04T15:25:12,099135+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2024-08-04T15:25:12,099141+00:00 x86/fpu: xstate_offset[3]:  832, xstate_sizes[3]:   64
2024-08-04T15:25:12,099146+00:00 x86/fpu: xstate_offset[4]:  896, xstate_sizes[4]:   64
2024-08-04T15:25:12,099151+00:00 x86/fpu: Enabled xstate features 0x1f, context size is 960 bytes, using 'compacted' format.
2024-08-04T15:25:12,125690+00:00 Freeing SMP alternatives memory: 36K
2024-08-04T15:25:12,125697+00:00 pid_max: default: 32768 minimum: 301
2024-08-04T15:25:12,129012+00:00 LSM: Security Framework initializing
2024-08-04T15:25:12,129034+00:00 landlock: Up and running.
2024-08-04T15:25:12,129037+00:00 Yama: disabled by default; enable with sysctl kernel.yama.*
2024-08-04T15:25:12,129065+00:00 AppArmor: AppArmor initialized
2024-08-04T15:25:12,129070+00:00 TOMOYO Linux initialized
2024-08-04T15:25:12,129078+00:00 LSM support for eBPF active
2024-08-04T15:25:12,129136+00:00 Mount-cache hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-08-04T15:25:12,129179+00:00 Mountpoint-cache hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-08-04T15:25:12,129857+00:00 smpboot: CPU0: Intel(R) Xeon(R) CPU E3-1240L v5 @ 2.10GHz (family: 0x6, model: 0x5e, stepping: 0x3)
2024-08-04T15:25:12,130002+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-08-04T15:25:12,130008+00:00 cblist_init_generic: Setting shift to 3 and lim to 1.
2024-08-04T15:25:12,130028+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-08-04T15:25:12,130033+00:00 cblist_init_generic: Setting shift to 3 and lim to 1.
2024-08-04T15:25:12,130050+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-08-04T15:25:12,130055+00:00 cblist_init_generic: Setting shift to 3 and lim to 1.
2024-08-04T15:25:12,130075+00:00 Performance Events: PEBS fmt3+, Skylake events, 32-deep LBR, full-width counters, Intel PMU driver.
2024-08-04T15:25:12,130112+00:00 ... version:                4
2024-08-04T15:25:12,130115+00:00 ... bit width:              48
2024-08-04T15:25:12,130118+00:00 ... generic registers:      4
2024-08-04T15:25:12,130121+00:00 ... value mask:             0000ffffffffffff
2024-08-04T15:25:12,130125+00:00 ... max period:             00007fffffffffff
2024-08-04T15:25:12,130128+00:00 ... fixed-purpose events:   3
2024-08-04T15:25:12,130131+00:00 ... event mask:             000000070000000f
2024-08-04T15:25:12,130293+00:00 signal: max sigframe size: 2032
2024-08-04T15:25:12,130314+00:00 Estimated ratio of average max frequency by base frequency (times 1024): 1414
2024-08-04T15:25:12,130340+00:00 rcu: Hierarchical SRCU implementation.
2024-08-04T15:25:12,130344+00:00 rcu: 	Max phase no-delay instances is 1000.
2024-08-04T15:25:12,130959+00:00 NMI watchdog: Enabled. Permanently consumes one hw-PMU counter.
2024-08-04T15:25:12,130959+00:00 smp: Bringing up secondary CPUs ...
2024-08-04T15:25:12,130959+00:00 x86: Booting SMP configuration:
2024-08-04T15:25:12,130959+00:00 .... node  #0, CPUs:      #1 #2 #3 #4
2024-08-04T15:25:12,131093+00:00 MDS CPU bug present and SMT on, data leak possible. See https://www.kernel.org/doc/html/latest/admin-guide/hw-vuln/mds.html for more details.
2024-08-04T15:25:12,131093+00:00 TAA CPU bug present and SMT on, data leak possible. See https://www.kernel.org/doc/html/latest/admin-guide/hw-vuln/tsx_async_abort.html for more details.
2024-08-04T15:25:12,131093+00:00 MMIO Stale Data CPU bug present and SMT on, data leak possible. See https://www.kernel.org/doc/html/latest/admin-guide/hw-vuln/processor_mmio_stale_data.html for more details.
2024-08-04T15:25:12,131125+00:00  #5 #6 #7
2024-08-04T15:25:12,131679+00:00 smp: Brought up 1 node, 8 CPUs
2024-08-04T15:25:12,131679+00:00 smpboot: Max logical packages: 1
2024-08-04T15:25:12,131679+00:00 smpboot: Total of 8 processors activated (33599.10 BogoMIPS)
2024-08-04T15:25:12,172278+00:00 node 0 deferred pages initialised in 36ms
2024-08-04T15:25:12,172280+00:00 devtmpfs: initialized
2024-08-04T15:25:12,172280+00:00 x86/mm: Memory block size: 128MB
2024-08-04T15:25:12,176964+00:00 ACPI: PM: Registering ACPI NVS region [mem 0x83157000-0x83157fff] (4096 bytes)
2024-08-04T15:25:12,176964+00:00 ACPI: PM: Registering ACPI NVS region [mem 0x8f265000-0x8fb99fff] (9654272 bytes)
2024-08-04T15:25:12,176964+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645041785100000 ns
2024-08-04T15:25:12,176964+00:00 futex hash table entries: 2048 (order: 5, 131072 bytes, linear)
2024-08-04T15:25:12,176964+00:00 pinctrl core: initialized pinctrl subsystem
2024-08-04T15:25:12,176964+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-08-04T15:25:12,176964+00:00 DMA: preallocated 4096 KiB GFP_KERNEL pool for atomic allocations
2024-08-04T15:25:12,176964+00:00 DMA: preallocated 4096 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-08-04T15:25:12,179126+00:00 DMA: preallocated 4096 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-08-04T15:25:12,179145+00:00 audit: initializing netlink subsys (disabled)
2024-08-04T15:25:12,179159+00:00 audit: type=2000 audit(1722785112.104:1): state=initialized audit_enabled=0 res=1
2024-08-04T15:25:12,179159+00:00 thermal_sys: Registered thermal governor 'fair_share'
2024-08-04T15:25:12,179159+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2024-08-04T15:25:12,179159+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-08-04T15:25:12,179159+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-08-04T15:25:12,179159+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2024-08-04T15:25:12,179159+00:00 cpuidle: using governor ladder
2024-08-04T15:25:12,179159+00:00 cpuidle: using governor menu
2024-08-04T15:25:12,179176+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-08-04T15:25:12,179176+00:00 PCI: MMCONFIG for domain 0000 [bus 00-ff] at [mem 0xe0000000-0xefffffff] (base 0xe0000000)
2024-08-04T15:25:12,179176+00:00 PCI: MMCONFIG at [mem 0xe0000000-0xefffffff] reserved in E820
2024-08-04T15:25:12,179176+00:00 PCI: Using configuration type 1 for base access
2024-08-04T15:25:12,179464+00:00 ENERGY_PERF_BIAS: Set to 'normal', was 'performance'
2024-08-04T15:25:12,180249+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2024-08-04T15:25:12,180261+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2024-08-04T15:25:12,180261+00:00 HugeTLB: 16380 KiB vmemmap can be freed for a 1.00 GiB page
2024-08-04T15:25:12,180261+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-08-04T15:25:12,180261+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2024-08-04T15:25:12,180261+00:00 ACPI: Added _OSI(Module Device)
2024-08-04T15:25:12,180261+00:00 ACPI: Added _OSI(Processor Device)
2024-08-04T15:25:12,180261+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-08-04T15:25:12,180261+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-08-04T15:25:12,228135+00:00 ACPI: 7 ACPI AML tables successfully acquired and loaded
2024-08-04T15:25:12,238996+00:00 ACPI: Dynamic OEM Table Load:
2024-08-04T15:25:12,239008+00:00 ACPI: SSDT 0xFFFF8E0800DAC800 0004FE (v02 PmRef  Cpu0Ist  00003000 INTL 20120913)
2024-08-04T15:25:12,240442+00:00 ACPI: \_PR_.CPU0: _OSC native thermal LVT Acked
2024-08-04T15:25:12,242503+00:00 ACPI: Dynamic OEM Table Load:
2024-08-04T15:25:12,242514+00:00 ACPI: SSDT 0xFFFF8E0800F95000 00037F (v02 PmRef  Cpu0Cst  00003001 INTL 20120913)
2024-08-04T15:25:12,244602+00:00 ACPI: Dynamic OEM Table Load:
2024-08-04T15:25:12,244613+00:00 ACPI: SSDT 0xFFFF8E08016D7000 0005AA (v02 PmRef  ApIst    00003000 INTL 20120913)
2024-08-04T15:25:12,246383+00:00 ACPI: Dynamic OEM Table Load:
2024-08-04T15:25:12,246391+00:00 ACPI: SSDT 0xFFFF8E080146DA00 000119 (v02 PmRef  ApCst    00003000 INTL 20120913)
2024-08-04T15:25:12,254246+00:00 ACPI: Interpreter enabled
2024-08-04T15:25:12,254304+00:00 ACPI: PM: (supports S0 S3 S4 S5)
2024-08-04T15:25:12,254308+00:00 ACPI: Using IOAPIC for interrupt routing
2024-08-04T15:25:12,254402+00:00 HEST: Table parsing has been initialized.
2024-08-04T15:25:12,254486+00:00 GHES: APEI firmware first mode is enabled by APEI bit and WHEA _OSC.
2024-08-04T15:25:12,254494+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2024-08-04T15:25:12,254500+00:00 PCI: Using E820 reservations for host bridge windows
2024-08-04T15:25:12,255705+00:00 ACPI: Enabled 7 GPEs in block 00 to 7F
2024-08-04T15:25:12,258944+00:00 ACPI: PM: Power Resource [PG00]
2024-08-04T15:25:12,259510+00:00 ACPI: PM: Power Resource [PG01]
2024-08-04T15:25:12,260007+00:00 ACPI: PM: Power Resource [PG02]
2024-08-04T15:25:12,263901+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,264368+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,264828+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,265292+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,265751+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,266144+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,266538+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,266929+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,267335+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,267730+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,268217+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,268671+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,269073+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,269466+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,269857+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,270250+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,270641+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,271040+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,271436+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,271837+00:00 ACPI: PM: Power Resource [WRST]
2024-08-04T15:25:12,286476+00:00 ACPI: PM: Power Resource [FN00]
2024-08-04T15:25:12,286580+00:00 ACPI: PM: Power Resource [FN01]
2024-08-04T15:25:12,286685+00:00 ACPI: PM: Power Resource [FN02]
2024-08-04T15:25:12,286784+00:00 ACPI: PM: Power Resource [FN03]
2024-08-04T15:25:12,286882+00:00 ACPI: PM: Power Resource [FN04]
2024-08-04T15:25:12,288370+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-fe])
2024-08-04T15:25:12,288383+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-08-04T15:25:12,289973+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug SHPCHotplug PME AER PCIeCapability LTR]
2024-08-04T15:25:12,291337+00:00 PCI host bridge to bus 0000:00
2024-08-04T15:25:12,291343+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2024-08-04T15:25:12,291349+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2024-08-04T15:25:12,291354+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2024-08-04T15:25:12,291359+00:00 pci_bus 0000:00: root bus resource [mem 0x90000000-0xdfffffff window]
2024-08-04T15:25:12,291365+00:00 pci_bus 0000:00: root bus resource [mem 0xfd000000-0xfe7fffff window]
2024-08-04T15:25:12,291370+00:00 pci_bus 0000:00: root bus resource [bus 00-fe]
2024-08-04T15:25:12,291489+00:00 pci 0000:00:00.0: [8086:1918] type 00 class 0x060000
2024-08-04T15:25:12,291588+00:00 pci 0000:00:01.0: [8086:1901] type 01 class 0x060400
2024-08-04T15:25:12,291645+00:00 pci 0000:00:01.0: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,292057+00:00 pci 0000:00:01.1: [8086:1905] type 01 class 0x060400
2024-08-04T15:25:12,292113+00:00 pci 0000:00:01.1: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,292596+00:00 pci 0000:00:14.0: [8086:a12f] type 00 class 0x0c0330
2024-08-04T15:25:12,292622+00:00 pci 0000:00:14.0: reg 0x10: [mem 0xde800000-0xde80ffff 64bit]
2024-08-04T15:25:12,292701+00:00 pci 0000:00:14.0: PME# supported from D3hot D3cold
2024-08-04T15:25:12,293436+00:00 pci 0000:00:14.2: [8086:a131] type 00 class 0x118000
2024-08-04T15:25:12,293461+00:00 pci 0000:00:14.2: reg 0x10: [mem 0xde821000-0xde821fff 64bit]
2024-08-04T15:25:12,293659+00:00 pci 0000:00:16.0: [8086:a13a] type 00 class 0x078000
2024-08-04T15:25:12,293689+00:00 pci 0000:00:16.0: reg 0x10: [mem 0xde820000-0xde820fff 64bit]
2024-08-04T15:25:12,293784+00:00 pci 0000:00:16.0: PME# supported from D3hot
2024-08-04T15:25:12,293917+00:00 pci 0000:00:17.0: [8086:a102] type 00 class 0x010601
2024-08-04T15:25:12,293937+00:00 pci 0000:00:17.0: reg 0x10: [mem 0xde810000-0xde811fff]
2024-08-04T15:25:12,293952+00:00 pci 0000:00:17.0: reg 0x14: [mem 0xde81e000-0xde81e0ff]
2024-08-04T15:25:12,293966+00:00 pci 0000:00:17.0: reg 0x18: [io  0xf050-0xf057]
2024-08-04T15:25:12,293980+00:00 pci 0000:00:17.0: reg 0x1c: [io  0xf040-0xf043]
2024-08-04T15:25:12,293994+00:00 pci 0000:00:17.0: reg 0x20: [io  0xf020-0xf03f]
2024-08-04T15:25:12,294004+00:00 pci 0000:00:17.0: reg 0x24: [mem 0xde81d000-0xde81d7ff]
2024-08-04T15:25:12,294057+00:00 pci 0000:00:17.0: PME# supported from D3hot
2024-08-04T15:25:12,294381+00:00 pci 0000:00:1c.0: [8086:a114] type 01 class 0x060400
2024-08-04T15:25:12,294469+00:00 pci 0000:00:1c.0: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,294492+00:00 pci 0000:00:1c.0: Intel SPT PCH root port ACS workaround enabled
2024-08-04T15:25:12,295118+00:00 pci 0000:00:1c.5: [8086:a115] type 01 class 0x060400
2024-08-04T15:25:12,295206+00:00 pci 0000:00:1c.5: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,295228+00:00 pci 0000:00:1c.5: Intel SPT PCH root port ACS workaround enabled
2024-08-04T15:25:12,295814+00:00 pci 0000:00:1c.6: [8086:a116] type 01 class 0x060400
2024-08-04T15:25:12,295901+00:00 pci 0000:00:1c.6: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,295924+00:00 pci 0000:00:1c.6: Intel SPT PCH root port ACS workaround enabled
2024-08-04T15:25:12,296522+00:00 pci 0000:00:1c.7: [8086:a117] type 01 class 0x060400
2024-08-04T15:25:12,296606+00:00 pci 0000:00:1c.7: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,296629+00:00 pci 0000:00:1c.7: Intel SPT PCH root port ACS workaround enabled
2024-08-04T15:25:12,297224+00:00 pci 0000:00:1d.0: [8086:a118] type 01 class 0x060400
2024-08-04T15:25:12,297319+00:00 pci 0000:00:1d.0: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,297340+00:00 pci 0000:00:1d.0: Intel SPT PCH root port ACS workaround enabled
2024-08-04T15:25:12,297939+00:00 pci 0000:00:1d.1: [8086:a119] type 01 class 0x060400
2024-08-04T15:25:12,298030+00:00 pci 0000:00:1d.1: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,298055+00:00 pci 0000:00:1d.1: Intel SPT PCH root port ACS workaround enabled
2024-08-04T15:25:12,298651+00:00 pci 0000:00:1d.2: [8086:a11a] type 01 class 0x060400
2024-08-04T15:25:12,298742+00:00 pci 0000:00:1d.2: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,298766+00:00 pci 0000:00:1d.2: Intel SPT PCH root port ACS workaround enabled
2024-08-04T15:25:12,299366+00:00 pci 0000:00:1d.3: [8086:a11b] type 01 class 0x060400
2024-08-04T15:25:12,299456+00:00 pci 0000:00:1d.3: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,299481+00:00 pci 0000:00:1d.3: Intel SPT PCH root port ACS workaround enabled
2024-08-04T15:25:12,300102+00:00 pci 0000:00:1f.0: [8086:a14a] type 00 class 0x060100
2024-08-04T15:25:12,300519+00:00 pci 0000:00:1f.2: [8086:a121] type 00 class 0x058000
2024-08-04T15:25:12,300539+00:00 pci 0000:00:1f.2: reg 0x10: [mem 0xde818000-0xde81bfff]
2024-08-04T15:25:12,300856+00:00 pci 0000:00:1f.4: [8086:a123] type 00 class 0x0c0500
2024-08-04T15:25:12,300921+00:00 pci 0000:00:1f.4: reg 0x10: [mem 0xde81c000-0xde81c0ff 64bit]
2024-08-04T15:25:12,300999+00:00 pci 0000:00:1f.4: reg 0x20: [io  0xf000-0xf01f]
2024-08-04T15:25:12,301359+00:00 pci 0000:00:01.0: PCI bridge to [bus 01]
2024-08-04T15:25:12,301426+00:00 pci 0000:02:00.0: [8086:f1a8] type 00 class 0x010802
2024-08-04T15:25:12,301448+00:00 pci 0000:02:00.0: reg 0x10: [mem 0xde700000-0xde703fff 64bit]
2024-08-04T15:25:12,301695+00:00 pci 0000:00:01.1: PCI bridge to [bus 02]
2024-08-04T15:25:12,301702+00:00 pci 0000:00:01.1:   bridge window [mem 0xde700000-0xde7fffff]
2024-08-04T15:25:12,301803+00:00 pci 0000:03:00.0: [1a03:1150] type 01 class 0x060400
2024-08-04T15:25:12,301876+00:00 pci 0000:03:00.0: enabling Extended Tags
2024-08-04T15:25:12,301964+00:00 pci 0000:03:00.0: supports D1 D2
2024-08-04T15:25:12,301968+00:00 pci 0000:03:00.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-08-04T15:25:12,302383+00:00 pci 0000:03:00.0: disabling ASPM on pre-1.1 PCIe device.  You can enable it with 'pcie_aspm=force'
2024-08-04T15:25:12,302398+00:00 pci 0000:00:1c.0: PCI bridge to [bus 03-04]
2024-08-04T15:25:12,302408+00:00 pci 0000:00:1c.0:   bridge window [io  0xe000-0xefff]
2024-08-04T15:25:12,302417+00:00 pci 0000:00:1c.0:   bridge window [mem 0xdc000000-0xde0fffff]
2024-08-04T15:25:12,302469+00:00 pci_bus 0000:04: extended config space not accessible
2024-08-04T15:25:12,302505+00:00 pci 0000:04:00.0: [1a03:2000] type 00 class 0x030000
2024-08-04T15:25:12,302535+00:00 pci 0000:04:00.0: reg 0x10: [mem 0xdc000000-0xddffffff]
2024-08-04T15:25:12,302555+00:00 pci 0000:04:00.0: reg 0x14: [mem 0xde000000-0xde01ffff]
2024-08-04T15:25:12,302574+00:00 pci 0000:04:00.0: reg 0x18: [io  0xe000-0xe07f]
2024-08-04T15:25:12,302647+00:00 pci 0000:04:00.0: BAR 0: assigned to efifb
2024-08-04T15:25:12,302662+00:00 pci 0000:04:00.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2024-08-04T15:25:12,302714+00:00 pci 0000:04:00.0: supports D1 D2
2024-08-04T15:25:12,302717+00:00 pci 0000:04:00.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-08-04T15:25:12,302834+00:00 pci 0000:03:00.0: PCI bridge to [bus 04]
2024-08-04T15:25:12,302848+00:00 pci 0000:03:00.0:   bridge window [io  0xe000-0xefff]
2024-08-04T15:25:12,302860+00:00 pci 0000:03:00.0:   bridge window [mem 0xdc000000-0xde0fffff]
2024-08-04T15:25:12,302973+00:00 pci 0000:05:00.0: [1b21:1080] type 01 class 0x060400
2024-08-04T15:25:12,303132+00:00 pci 0000:05:00.0: supports D1 D2
2024-08-04T15:25:12,303136+00:00 pci 0000:05:00.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-08-04T15:25:12,314980+00:00 pci 0000:00:1c.5: PCI bridge to [bus 05-06]
2024-08-04T15:25:12,315043+00:00 pci_bus 0000:06: extended config space not accessible
2024-08-04T15:25:12,315127+00:00 pci 0000:05:00.0: PCI bridge to [bus 06]
2024-08-04T15:25:12,315231+00:00 pci 0000:07:00.0: [15b7:5002] type 00 class 0x010802
2024-08-04T15:25:12,315260+00:00 pci 0000:07:00.0: reg 0x10: [mem 0xde600000-0xde603fff 64bit]
2024-08-04T15:25:12,315293+00:00 pci 0000:07:00.0: reg 0x20: [mem 0xde604000-0xde6040ff 64bit]
2024-08-04T15:25:12,315448+00:00 pci 0000:07:00.0: 7.876 Gb/s available PCIe bandwidth, limited by 8.0 GT/s PCIe x1 link at 0000:00:1c.6 (capable of 31.504 Gb/s with 8.0 GT/s PCIe x4 link)
2024-08-04T15:25:12,315838+00:00 pci 0000:00:1c.6: PCI bridge to [bus 07]
2024-08-04T15:25:12,315850+00:00 pci 0000:00:1c.6:   bridge window [mem 0xde600000-0xde6fffff]
2024-08-04T15:25:12,315933+00:00 pci 0000:08:00.0: [15b7:5002] type 00 class 0x010802
2024-08-04T15:25:12,315961+00:00 pci 0000:08:00.0: reg 0x10: [mem 0xde500000-0xde503fff 64bit]
2024-08-04T15:25:12,315998+00:00 pci 0000:08:00.0: reg 0x20: [mem 0xde504000-0xde5040ff 64bit]
2024-08-04T15:25:12,316151+00:00 pci 0000:08:00.0: 7.876 Gb/s available PCIe bandwidth, limited by 8.0 GT/s PCIe x1 link at 0000:00:1c.7 (capable of 31.504 Gb/s with 8.0 GT/s PCIe x4 link)
2024-08-04T15:25:12,316530+00:00 pci 0000:00:1c.7: PCI bridge to [bus 08]
2024-08-04T15:25:12,316541+00:00 pci 0000:00:1c.7:   bridge window [mem 0xde500000-0xde5fffff]
2024-08-04T15:25:12,316680+00:00 pci 0000:09:00.0: working around ROM BAR overlap defect
2024-08-04T15:25:12,316685+00:00 pci 0000:09:00.0: [8086:1533] type 00 class 0x020000
2024-08-04T15:25:12,316725+00:00 pci 0000:09:00.0: reg 0x10: [mem 0xde400000-0xde47ffff]
2024-08-04T15:25:12,316766+00:00 pci 0000:09:00.0: reg 0x18: [io  0xd000-0xd01f]
2024-08-04T15:25:12,316795+00:00 pci 0000:09:00.0: reg 0x1c: [mem 0xde480000-0xde483fff]
2024-08-04T15:25:12,316965+00:00 pci 0000:09:00.0: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,317450+00:00 pci 0000:00:1d.0: PCI bridge to [bus 09]
2024-08-04T15:25:12,317460+00:00 pci 0000:00:1d.0:   bridge window [io  0xd000-0xdfff]
2024-08-04T15:25:12,317470+00:00 pci 0000:00:1d.0:   bridge window [mem 0xde400000-0xde4fffff]
2024-08-04T15:25:12,317605+00:00 pci 0000:0a:00.0: working around ROM BAR overlap defect
2024-08-04T15:25:12,317610+00:00 pci 0000:0a:00.0: [8086:1533] type 00 class 0x020000
2024-08-04T15:25:12,317651+00:00 pci 0000:0a:00.0: reg 0x10: [mem 0xde300000-0xde37ffff]
2024-08-04T15:25:12,317692+00:00 pci 0000:0a:00.0: reg 0x18: [io  0xc000-0xc01f]
2024-08-04T15:25:12,317709+00:00 pci 0000:0a:00.0: reg 0x1c: [mem 0xde380000-0xde383fff]
2024-08-04T15:25:12,317878+00:00 pci 0000:0a:00.0: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,318354+00:00 pci 0000:00:1d.1: PCI bridge to [bus 0a]
2024-08-04T15:25:12,318364+00:00 pci 0000:00:1d.1:   bridge window [io  0xc000-0xcfff]
2024-08-04T15:25:12,318371+00:00 pci 0000:00:1d.1:   bridge window [mem 0xde300000-0xde3fffff]
2024-08-04T15:25:12,318507+00:00 pci 0000:0b:00.0: working around ROM BAR overlap defect
2024-08-04T15:25:12,318512+00:00 pci 0000:0b:00.0: [8086:1533] type 00 class 0x020000
2024-08-04T15:25:12,318552+00:00 pci 0000:0b:00.0: reg 0x10: [mem 0xde200000-0xde27ffff]
2024-08-04T15:25:12,318593+00:00 pci 0000:0b:00.0: reg 0x18: [io  0xb000-0xb01f]
2024-08-04T15:25:12,318622+00:00 pci 0000:0b:00.0: reg 0x1c: [mem 0xde280000-0xde283fff]
2024-08-04T15:25:12,318792+00:00 pci 0000:0b:00.0: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,319280+00:00 pci 0000:00:1d.2: PCI bridge to [bus 0b]
2024-08-04T15:25:12,319291+00:00 pci 0000:00:1d.2:   bridge window [io  0xb000-0xbfff]
2024-08-04T15:25:12,319300+00:00 pci 0000:00:1d.2:   bridge window [mem 0xde200000-0xde2fffff]
2024-08-04T15:25:12,319437+00:00 pci 0000:0c:00.0: working around ROM BAR overlap defect
2024-08-04T15:25:12,319442+00:00 pci 0000:0c:00.0: [8086:1533] type 00 class 0x020000
2024-08-04T15:25:12,319482+00:00 pci 0000:0c:00.0: reg 0x10: [mem 0xde100000-0xde17ffff]
2024-08-04T15:25:12,319523+00:00 pci 0000:0c:00.0: reg 0x18: [io  0xa000-0xa01f]
2024-08-04T15:25:12,319552+00:00 pci 0000:0c:00.0: reg 0x1c: [mem 0xde180000-0xde183fff]
2024-08-04T15:25:12,319722+00:00 pci 0000:0c:00.0: PME# supported from D0 D3hot D3cold
2024-08-04T15:25:12,320208+00:00 pci 0000:00:1d.3: PCI bridge to [bus 0c]
2024-08-04T15:25:12,320218+00:00 pci 0000:00:1d.3:   bridge window [io  0xa000-0xafff]
2024-08-04T15:25:12,320228+00:00 pci 0000:00:1d.3:   bridge window [mem 0xde100000-0xde1fffff]
2024-08-04T15:25:12,323316+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 11
2024-08-04T15:25:12,323393+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2024-08-04T15:25:12,323465+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2024-08-04T15:25:12,323536+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2024-08-04T15:25:12,323607+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 5
2024-08-04T15:25:12,323678+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 7
2024-08-04T15:25:12,323749+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 5
2024-08-04T15:25:12,323820+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 7
2024-08-04T15:25:12,333546+00:00 iommu: Default domain type: Translated 
2024-08-04T15:25:12,333546+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2024-08-04T15:25:12,333546+00:00 pps_core: LinuxPPS API ver. 1 registered
2024-08-04T15:25:12,333546+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2024-08-04T15:25:12,333546+00:00 PTP clock support registered
2024-08-04T15:25:12,333546+00:00 EDAC MC: Ver: 3.0.0
2024-08-04T15:25:12,333546+00:00 Registered efivars operations
2024-08-04T15:25:12,333546+00:00 NetLabel: Initializing
2024-08-04T15:25:12,333546+00:00 NetLabel:  domain hash size = 128
2024-08-04T15:25:12,333546+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-08-04T15:25:12,333546+00:00 NetLabel:  unlabeled traffic allowed by default
2024-08-04T15:25:12,333546+00:00 PCI: Using ACPI for IRQ routing
2024-08-04T15:25:12,361755+00:00 PCI: pci_cache_line_size set to 64 bytes
2024-08-04T15:25:12,361915+00:00 e820: reserve RAM buffer [mem 0x00058000-0x0005ffff]
2024-08-04T15:25:12,361918+00:00 e820: reserve RAM buffer [mem 0x0009f000-0x0009ffff]
2024-08-04T15:25:12,361919+00:00 e820: reserve RAM buffer [mem 0x83157000-0x83ffffff]
2024-08-04T15:25:12,361921+00:00 e820: reserve RAM buffer [mem 0x8bc71000-0x8bffffff]
2024-08-04T15:25:12,361922+00:00 e820: reserve RAM buffer [mem 0x8fc00000-0x8fffffff]
2024-08-04T15:25:12,361940+00:00 pci 0000:04:00.0: vgaarb: setting as boot VGA device
2024-08-04T15:25:12,361940+00:00 pci 0000:04:00.0: vgaarb: bridge control possible
2024-08-04T15:25:12,361940+00:00 pci 0000:04:00.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2024-08-04T15:25:12,361940+00:00 vgaarb: loaded
2024-08-04T15:25:12,361940+00:00 hpet0: at MMIO 0xfed00000, IRQs 2, 8, 0, 0, 0, 0, 0, 0
2024-08-04T15:25:12,361940+00:00 hpet0: 8 comparators, 64-bit 24.000000 MHz counter
2024-08-04T15:25:12,364007+00:00 clocksource: Switched to clocksource tsc-early
2024-08-04T15:25:12,364191+00:00 VFS: Disk quotas dquot_6.6.0
2024-08-04T15:25:12,364214+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-08-04T15:25:12,364419+00:00 AppArmor: AppArmor Filesystem Enabled
2024-08-04T15:25:12,364445+00:00 pnp: PnP ACPI init
2024-08-04T15:25:12,364955+00:00 system 00:00: [io  0x0290-0x029f] has been reserved
2024-08-04T15:25:12,364965+00:00 system 00:00: [io  0x0290-0x029f] has been reserved
2024-08-04T15:25:12,364973+00:00 system 00:00: [io  0x02b0-0x02bf] has been reserved
2024-08-04T15:25:12,364981+00:00 system 00:00: [io  0x02c0-0x02cf] has been reserved
2024-08-04T15:25:12,365504+00:00 pnp 00:01: [dma 0 disabled]
2024-08-04T15:25:12,366066+00:00 pnp 00:02: [dma 0 disabled]
2024-08-04T15:25:12,366529+00:00 system 00:03: [io  0x0680-0x069f] has been reserved
2024-08-04T15:25:12,366539+00:00 system 00:03: [io  0xffff] has been reserved
2024-08-04T15:25:12,366547+00:00 system 00:03: [io  0xffff] has been reserved
2024-08-04T15:25:12,366554+00:00 system 00:03: [io  0xffff] has been reserved
2024-08-04T15:25:12,366561+00:00 system 00:03: [io  0x1800-0x18fe] has been reserved
2024-08-04T15:25:12,366568+00:00 system 00:03: [io  0x164e-0x164f] has been reserved
2024-08-04T15:25:12,366725+00:00 system 00:04: [io  0x0800-0x087f] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:06: [io  0x1854-0x1857] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xfed10000-0xfed17fff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xfed18000-0xfed18fff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xfed19000-0xfed19fff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xe0000000-0xefffffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xfed20000-0xfed3ffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xfed90000-0xfed93fff] could not be reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xfed45000-0xfed8ffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xff000000-0xffffffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xfee00000-0xfeefffff] could not be reserved
2024-08-04T15:25:12,366843+00:00 system 00:07: [mem 0xdffc0000-0xdffdffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:08: [mem 0xfd000000-0xfdabffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:08: [mem 0xfdad0000-0xfdadffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:08: [mem 0xfdb00000-0xfdffffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:08: [mem 0xfe000000-0xfe01ffff] could not be reserved
2024-08-04T15:25:12,366843+00:00 system 00:08: [mem 0xfe036000-0xfe03bfff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:08: [mem 0xfe03d000-0xfe3fffff] has been reserved
2024-08-04T15:25:12,366843+00:00 system 00:08: [mem 0xfe410000-0xfe7fffff] has been reserved
2024-08-04T15:25:12,366968+00:00 system 00:09: [io  0xff00-0xfffe] has been reserved
2024-08-04T15:25:12,368918+00:00 system 00:0a: [mem 0xfdaf0000-0xfdafffff] has been reserved
2024-08-04T15:25:12,368928+00:00 system 00:0a: [mem 0xfdae0000-0xfdaeffff] has been reserved
2024-08-04T15:25:12,368936+00:00 system 00:0a: [mem 0xfdac0000-0xfdacffff] has been reserved
2024-08-04T15:25:12,370421+00:00 pnp: PnP ACPI: found 11 devices
2024-08-04T15:25:12,377045+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2024-08-04T15:25:12,377165+00:00 NET: Registered PF_INET protocol family
2024-08-04T15:25:12,377374+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-08-04T15:25:12,381313+00:00 tcp_listen_portaddr_hash hash table entries: 16384 (order: 6, 262144 bytes, linear)
2024-08-04T15:25:12,381366+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-08-04T15:25:12,381523+00:00 TCP established hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-08-04T15:25:12,381933+00:00 TCP bind hash table entries: 65536 (order: 9, 2097152 bytes, linear)
2024-08-04T15:25:12,382280+00:00 TCP: Hash tables configured (established 262144 bind 65536)
2024-08-04T15:25:12,382426+00:00 MPTCP token hash table entries: 32768 (order: 7, 786432 bytes, linear)
2024-08-04T15:25:12,382612+00:00 UDP hash table entries: 16384 (order: 7, 524288 bytes, linear)
2024-08-04T15:25:12,382711+00:00 UDP-Lite hash table entries: 16384 (order: 7, 524288 bytes, linear)
2024-08-04T15:25:12,382818+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-08-04T15:25:12,382828+00:00 NET: Registered PF_XDP protocol family
2024-08-04T15:25:12,382849+00:00 pci 0000:00:01.0: PCI bridge to [bus 01]
2024-08-04T15:25:12,382861+00:00 pci 0000:00:01.1: PCI bridge to [bus 02]
2024-08-04T15:25:12,382866+00:00 pci 0000:00:01.1:   bridge window [mem 0xde700000-0xde7fffff]
2024-08-04T15:25:12,382877+00:00 pci 0000:03:00.0: PCI bridge to [bus 04]
2024-08-04T15:25:12,382886+00:00 pci 0000:03:00.0:   bridge window [io  0xe000-0xefff]
2024-08-04T15:25:12,382899+00:00 pci 0000:03:00.0:   bridge window [mem 0xdc000000-0xde0fffff]
2024-08-04T15:25:12,382912+00:00 pci 0000:00:1c.0: PCI bridge to [bus 03-04]
2024-08-04T15:25:12,382921+00:00 pci 0000:00:1c.0:   bridge window [io  0xe000-0xefff]
2024-08-04T15:25:12,382931+00:00 pci 0000:00:1c.0:   bridge window [mem 0xdc000000-0xde0fffff]
2024-08-04T15:25:12,382943+00:00 pci 0000:05:00.0: PCI bridge to [bus 06]
2024-08-04T15:25:12,382965+00:00 pci 0000:00:1c.5: PCI bridge to [bus 05-06]
2024-08-04T15:25:12,382980+00:00 pci 0000:00:1c.6: PCI bridge to [bus 07]
2024-08-04T15:25:12,382989+00:00 pci 0000:00:1c.6:   bridge window [mem 0xde600000-0xde6fffff]
2024-08-04T15:25:12,383001+00:00 pci 0000:00:1c.7: PCI bridge to [bus 08]
2024-08-04T15:25:12,383010+00:00 pci 0000:00:1c.7:   bridge window [mem 0xde500000-0xde5fffff]
2024-08-04T15:25:12,383023+00:00 pci 0000:00:1d.0: PCI bridge to [bus 09]
2024-08-04T15:25:12,383027+00:00 pci 0000:00:1d.0:   bridge window [io  0xd000-0xdfff]
2024-08-04T15:25:12,383037+00:00 pci 0000:00:1d.0:   bridge window [mem 0xde400000-0xde4fffff]
2024-08-04T15:25:12,383050+00:00 pci 0000:00:1d.1: PCI bridge to [bus 0a]
2024-08-04T15:25:12,383058+00:00 pci 0000:00:1d.1:   bridge window [io  0xc000-0xcfff]
2024-08-04T15:25:12,383068+00:00 pci 0000:00:1d.1:   bridge window [mem 0xde300000-0xde3fffff]
2024-08-04T15:25:12,383081+00:00 pci 0000:00:1d.2: PCI bridge to [bus 0b]
2024-08-04T15:25:12,383089+00:00 pci 0000:00:1d.2:   bridge window [io  0xb000-0xbfff]
2024-08-04T15:25:12,383099+00:00 pci 0000:00:1d.2:   bridge window [mem 0xde200000-0xde2fffff]
2024-08-04T15:25:12,383112+00:00 pci 0000:00:1d.3: PCI bridge to [bus 0c]
2024-08-04T15:25:12,383120+00:00 pci 0000:00:1d.3:   bridge window [io  0xa000-0xafff]
2024-08-04T15:25:12,383131+00:00 pci 0000:00:1d.3:   bridge window [mem 0xde100000-0xde1fffff]
2024-08-04T15:25:12,383144+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2024-08-04T15:25:12,383149+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2024-08-04T15:25:12,383154+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2024-08-04T15:25:12,383159+00:00 pci_bus 0000:00: resource 7 [mem 0x90000000-0xdfffffff window]
2024-08-04T15:25:12,383164+00:00 pci_bus 0000:00: resource 8 [mem 0xfd000000-0xfe7fffff window]
2024-08-04T15:25:12,383169+00:00 pci_bus 0000:02: resource 1 [mem 0xde700000-0xde7fffff]
2024-08-04T15:25:12,383174+00:00 pci_bus 0000:03: resource 0 [io  0xe000-0xefff]
2024-08-04T15:25:12,383178+00:00 pci_bus 0000:03: resource 1 [mem 0xdc000000-0xde0fffff]
2024-08-04T15:25:12,383183+00:00 pci_bus 0000:04: resource 0 [io  0xe000-0xefff]
2024-08-04T15:25:12,383187+00:00 pci_bus 0000:04: resource 1 [mem 0xdc000000-0xde0fffff]
2024-08-04T15:25:12,383192+00:00 pci_bus 0000:07: resource 1 [mem 0xde600000-0xde6fffff]
2024-08-04T15:25:12,383196+00:00 pci_bus 0000:08: resource 1 [mem 0xde500000-0xde5fffff]
2024-08-04T15:25:12,383201+00:00 pci_bus 0000:09: resource 0 [io  0xd000-0xdfff]
2024-08-04T15:25:12,383205+00:00 pci_bus 0000:09: resource 1 [mem 0xde400000-0xde4fffff]
2024-08-04T15:25:12,383210+00:00 pci_bus 0000:0a: resource 0 [io  0xc000-0xcfff]
2024-08-04T15:25:12,383214+00:00 pci_bus 0000:0a: resource 1 [mem 0xde300000-0xde3fffff]
2024-08-04T15:25:12,383218+00:00 pci_bus 0000:0b: resource 0 [io  0xb000-0xbfff]
2024-08-04T15:25:12,383223+00:00 pci_bus 0000:0b: resource 1 [mem 0xde200000-0xde2fffff]
2024-08-04T15:25:12,383227+00:00 pci_bus 0000:0c: resource 0 [io  0xa000-0xafff]
2024-08-04T15:25:12,383231+00:00 pci_bus 0000:0c: resource 1 [mem 0xde100000-0xde1fffff]
2024-08-04T15:25:12,390119+00:00 pci 0000:05:00.0: Disabling ASPM L0s/L1
2024-08-04T15:25:12,390182+00:00 PCI: CLS 0 bytes, default 64
2024-08-04T15:25:12,390240+00:00 pci 0000:00:1f.1: [8086:a120] type 00 class 0x058000
2024-08-04T15:25:12,390305+00:00 pci 0000:00:1f.1: reg 0x10: [mem 0xfd000000-0xfdffffff 64bit]
2024-08-04T15:25:12,390581+00:00 DMAR: No ATSR found
2024-08-04T15:25:12,390586+00:00 DMAR: No SATC found
2024-08-04T15:25:12,390590+00:00 DMAR: dmar0: Using Queued invalidation
2024-08-04T15:25:12,390639+00:00 Trying to unpack rootfs image as initramfs...
2024-08-04T15:25:12,390656+00:00 pci 0000:00:00.0: Adding to iommu group 0
2024-08-04T15:25:12,390688+00:00 pci 0000:00:01.0: Adding to iommu group 1
2024-08-04T15:25:12,390705+00:00 pci 0000:00:01.1: Adding to iommu group 1
2024-08-04T15:25:12,390736+00:00 pci 0000:00:14.0: Adding to iommu group 2
2024-08-04T15:25:12,390753+00:00 pci 0000:00:14.2: Adding to iommu group 2
2024-08-04T15:25:12,390775+00:00 pci 0000:00:16.0: Adding to iommu group 3
2024-08-04T15:25:12,390794+00:00 pci 0000:00:17.0: Adding to iommu group 4
2024-08-04T15:25:12,390819+00:00 pci 0000:00:1c.0: Adding to iommu group 5
2024-08-04T15:25:12,390843+00:00 pci 0000:00:1c.5: Adding to iommu group 6
2024-08-04T15:25:12,390868+00:00 pci 0000:00:1c.6: Adding to iommu group 7
2024-08-04T15:25:12,390891+00:00 pci 0000:00:1c.7: Adding to iommu group 8
2024-08-04T15:25:12,390919+00:00 pci 0000:00:1d.0: Adding to iommu group 9
2024-08-04T15:25:12,390943+00:00 pci 0000:00:1d.1: Adding to iommu group 10
2024-08-04T15:25:12,390971+00:00 pci 0000:00:1d.2: Adding to iommu group 11
2024-08-04T15:25:12,390995+00:00 pci 0000:00:1d.3: Adding to iommu group 12
2024-08-04T15:25:12,391031+00:00 pci 0000:00:1f.0: Adding to iommu group 13
2024-08-04T15:25:12,391051+00:00 pci 0000:00:1f.2: Adding to iommu group 13
2024-08-04T15:25:12,391069+00:00 pci 0000:00:1f.4: Adding to iommu group 13
2024-08-04T15:25:12,391079+00:00 pci 0000:02:00.0: Adding to iommu group 1
2024-08-04T15:25:12,391104+00:00 pci 0000:03:00.0: Adding to iommu group 14
2024-08-04T15:25:12,391115+00:00 pci 0000:04:00.0: Adding to iommu group 14
2024-08-04T15:25:12,391140+00:00 pci 0000:05:00.0: Adding to iommu group 15
2024-08-04T15:25:12,391163+00:00 pci 0000:07:00.0: Adding to iommu group 16
2024-08-04T15:25:12,391186+00:00 pci 0000:08:00.0: Adding to iommu group 17
2024-08-04T15:25:12,391210+00:00 pci 0000:09:00.0: Adding to iommu group 18
2024-08-04T15:25:12,391234+00:00 pci 0000:0a:00.0: Adding to iommu group 19
2024-08-04T15:25:12,391257+00:00 pci 0000:0b:00.0: Adding to iommu group 20
2024-08-04T15:25:12,391280+00:00 pci 0000:0c:00.0: Adding to iommu group 21
2024-08-04T15:25:12,393706+00:00 DMAR: Intel(R) Virtualization Technology for Directed I/O
2024-08-04T15:25:12,393715+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2024-08-04T15:25:12,393720+00:00 software IO TLB: mapped [mem 0x0000000083cd9000-0x0000000087cd9000] (64MB)
2024-08-04T15:25:12,394396+00:00 Initialise system trusted keyrings
2024-08-04T15:25:12,394411+00:00 Key type blacklist registered
2024-08-04T15:25:12,394472+00:00 workingset: timestamp_bits=36 max_order=23 bucket_order=0
2024-08-04T15:25:12,397006+00:00 zbud: loaded
2024-08-04T15:25:12,397321+00:00 integrity: Platform Keyring initialized
2024-08-04T15:25:12,397332+00:00 integrity: Machine keyring initialized
2024-08-04T15:25:12,397337+00:00 Key type asymmetric registered
2024-08-04T15:25:12,397341+00:00 Asymmetric key parser 'x509' registered
2024-08-04T15:25:12,746267+00:00 Freeing initrd memory: 38928K
2024-08-04T15:25:12,752853+00:00 alg: self-tests for CTR-KDF (hmac(sha256)) passed
2024-08-04T15:25:12,752881+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 248)
2024-08-04T15:25:12,752927+00:00 io scheduler mq-deadline registered
2024-08-04T15:25:12,754115+00:00 pcieport 0000:00:01.0: PME: Signaling with IRQ 121
2024-08-04T15:25:12,754181+00:00 pcieport 0000:00:01.0: AER: enabled with IRQ 121
2024-08-04T15:25:12,754398+00:00 pcieport 0000:00:01.1: PME: Signaling with IRQ 122
2024-08-04T15:25:12,754461+00:00 pcieport 0000:00:01.1: AER: enabled with IRQ 122
2024-08-04T15:25:12,754690+00:00 pcieport 0000:00:1c.0: PME: Signaling with IRQ 123
2024-08-04T15:25:12,754762+00:00 pcieport 0000:00:1c.0: AER: enabled with IRQ 123
2024-08-04T15:25:12,755004+00:00 pcieport 0000:00:1c.5: PME: Signaling with IRQ 124
2024-08-04T15:25:12,755247+00:00 pcieport 0000:00:1c.6: PME: Signaling with IRQ 125
2024-08-04T15:25:12,755321+00:00 pcieport 0000:00:1c.6: AER: enabled with IRQ 125
2024-08-04T15:25:12,755561+00:00 pcieport 0000:00:1c.7: PME: Signaling with IRQ 126
2024-08-04T15:25:12,755631+00:00 pcieport 0000:00:1c.7: AER: enabled with IRQ 126
2024-08-04T15:25:12,755862+00:00 pcieport 0000:00:1d.0: PME: Signaling with IRQ 127
2024-08-04T15:25:12,755937+00:00 pcieport 0000:00:1d.0: AER: enabled with IRQ 127
2024-08-04T15:25:12,756175+00:00 pcieport 0000:00:1d.1: PME: Signaling with IRQ 128
2024-08-04T15:25:12,756243+00:00 pcieport 0000:00:1d.1: AER: enabled with IRQ 128
2024-08-04T15:25:12,756482+00:00 pcieport 0000:00:1d.2: PME: Signaling with IRQ 129
2024-08-04T15:25:12,756553+00:00 pcieport 0000:00:1d.2: AER: enabled with IRQ 129
2024-08-04T15:25:12,756790+00:00 pcieport 0000:00:1d.3: PME: Signaling with IRQ 130
2024-08-04T15:25:12,756859+00:00 pcieport 0000:00:1d.3: AER: enabled with IRQ 130
2024-08-04T15:25:12,757035+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2024-08-04T15:25:12,758477+00:00 thermal LNXTHERM:00: registered as thermal_zone0
2024-08-04T15:25:12,758484+00:00 ACPI: thermal: Thermal Zone [TZ00] (28 C)
2024-08-04T15:25:12,758667+00:00 thermal LNXTHERM:01: registered as thermal_zone1
2024-08-04T15:25:12,758672+00:00 ACPI: thermal: Thermal Zone [TZ01] (30 C)
2024-08-04T15:25:12,758740+00:00 ERST: Error Record Serialization Table (ERST) support is initialized.
2024-08-04T15:25:12,758746+00:00 pstore: Registered erst as persistent store backend
2024-08-04T15:25:12,758890+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing enabled
2024-08-04T15:25:12,759230+00:00 00:01: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2024-08-04T15:25:12,761157+00:00 00:02: ttyS1 at I/O 0x2f8 (irq = 3, base_baud = 115200) is a 16550A
2024-08-04T15:25:12,763227+00:00 Linux agpgart interface v0.103
2024-08-04T15:25:12,766888+00:00 tpm_tis MSFT0101:00: 2.0 TPM (device-id 0x1A, rev-id 16)
2024-08-04T15:25:12,789163+00:00 AMD-Vi: AMD IOMMUv2 functionality not available on this system - This is not a bug.
2024-08-04T15:25:12,790364+00:00 i8042: PNP: No PS/2 controller found.
2024-08-04T15:25:12,790443+00:00 mousedev: PS/2 mouse device common for all mice
2024-08-04T15:25:12,790473+00:00 rtc_cmos 00:05: RTC can wake from S4
2024-08-04T15:25:12,791184+00:00 rtc_cmos 00:05: registered as rtc0
2024-08-04T15:25:12,791318+00:00 rtc_cmos 00:05: setting system clock to 2024-08-04T15:25:13 UTC (1722785113)
2024-08-04T15:25:12,791357+00:00 rtc_cmos 00:05: alarms up to one month, y3k, 242 bytes nvram
2024-08-04T15:25:12,791701+00:00 intel_pstate: Intel P-state driver initializing
2024-08-04T15:25:12,792244+00:00 intel_pstate: HWP enabled
2024-08-04T15:25:12,792396+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2024-08-04T15:25:12,792758+00:00 efifb: probing for efifb
2024-08-04T15:25:12,792774+00:00 efifb: framebuffer at 0xdc000000, using 1920k, total 1920k
2024-08-04T15:25:12,792779+00:00 efifb: mode is 800x600x32, linelength=3200, pages=1
2024-08-04T15:25:12,792784+00:00 efifb: scrolling: redraw
2024-08-04T15:25:12,792786+00:00 efifb: Truecolor: size=8:8:8:8, shift=24:16:8:0
2024-08-04T15:25:12,803266+00:00 Console: switching to colour frame buffer device 100x37
2024-08-04T15:25:12,813715+00:00 fb0: EFI VGA frame buffer device
2024-08-04T15:25:12,826077+00:00 NET: Registered PF_INET6 protocol family
2024-08-04T15:25:12,831256+00:00 Segment Routing with IPv6
2024-08-04T15:25:12,831368+00:00 In-situ OAM (IOAM) with IPv6
2024-08-04T15:25:12,831507+00:00 mip6: Mobile IPv6
2024-08-04T15:25:12,831592+00:00 NET: Registered PF_PACKET protocol family
2024-08-04T15:25:12,831864+00:00 mpls_gso: MPLS GSO support
2024-08-04T15:25:12,832859+00:00 microcode: sig=0x506e3, pf=0x2, revision=0xcc
2024-08-04T15:25:12,833234+00:00 microcode: Microcode Update Driver: v2.2.
2024-08-04T15:25:12,833253+00:00 IPI shorthand broadcast: enabled
2024-08-04T15:25:12,833555+00:00 sched_clock: Marking stable (832123881, 908775)->(882278928, -49246272)
2024-08-04T15:25:12,834078+00:00 registered taskstats version 1
2024-08-04T15:25:12,839594+00:00 Loading compiled-in X.509 certificates
2024-08-04T15:25:12,860666+00:00 Loaded X.509 cert 'Debian Secure Boot CA: 6ccece7e4c6c0d1f6149f3dd27dfcc5cbb419ea1'
2024-08-04T15:25:12,866322+00:00 Loaded X.509 cert 'Debian Secure Boot Signer 2022 - linux: 14011249c2675ea8e5148542202005810584b25f'
2024-08-04T15:25:12,878021+00:00 zswap: loaded using pool lzo/zbud
2024-08-04T15:25:12,884053+00:00 Key type .fscrypt registered
2024-08-04T15:25:12,889680+00:00 Key type fscrypt-provisioning registered
2024-08-04T15:25:12,895447+00:00 pstore: Using crash dump compression: deflate
2024-08-04T15:25:12,905155+00:00 Key type encrypted registered
2024-08-04T15:25:12,910462+00:00 AppArmor: AppArmor sha1 policy hashing enabled
2024-08-04T15:25:12,917234+00:00 integrity: Loading X.509 certificate: UEFI:db
2024-08-04T15:25:12,922639+00:00 integrity: Loaded X.509 cert 'Microsoft Corporation UEFI CA 2011: 13adbf4309bd82709c8cd54f316ed522988a1bd4'
2024-08-04T15:25:12,933752+00:00 integrity: Loading X.509 certificate: UEFI:db
2024-08-04T15:25:12,939342+00:00 integrity: Loaded X.509 cert 'Microsoft Windows Production PCA 2011: a92902398e16c49778cd90f99e4f9ae17c55af53'
2024-08-04T15:25:12,951775+00:00 ima: Allocated hash algorithm: sha256
2024-08-04T15:25:13,007346+00:00 ima: No architecture policies found
2024-08-04T15:25:13,012975+00:00 evm: Initialising EVM extended attributes:
2024-08-04T15:25:13,018580+00:00 evm: security.selinux
2024-08-04T15:25:13,024105+00:00 evm: security.SMACK64 (disabled)
2024-08-04T15:25:13,029582+00:00 evm: security.SMACK64EXEC (disabled)
2024-08-04T15:25:13,035001+00:00 evm: security.SMACK64TRANSMUTE (disabled)
2024-08-04T15:25:13,040408+00:00 evm: security.SMACK64MMAP (disabled)
2024-08-04T15:25:13,045701+00:00 evm: security.apparmor
2024-08-04T15:25:13,050871+00:00 evm: security.ima
2024-08-04T15:25:13,055945+00:00 evm: security.capability
2024-08-04T15:25:13,060957+00:00 evm: HMAC attrs: 0x1
2024-08-04T15:25:13,147474+00:00 clk: Disabling unused clocks
2024-08-04T15:25:13,153553+00:00 Freeing unused decrypted memory: 2036K
2024-08-04T15:25:13,159117+00:00 Freeing unused kernel image (initmem) memory: 2796K
2024-08-04T15:25:13,164342+00:00 Write protecting the kernel read-only data: 26624k
2024-08-04T15:25:13,170220+00:00 Freeing unused kernel image (text/rodata gap) memory: 2040K
2024-08-04T15:25:13,175843+00:00 Freeing unused kernel image (rodata/data gap) memory: 1172K
2024-08-04T15:25:13,227511+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2024-08-04T15:25:13,232601+00:00 x86/mm: Checking user space page tables
2024-08-04T15:25:13,281993+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2024-08-04T15:25:13,287001+00:00 Run /init as init process
2024-08-04T15:25:13,291853+00:00   with arguments:
2024-08-04T15:25:13,291854+00:00     /init
2024-08-04T15:25:13,291855+00:00   with environment:
2024-08-04T15:25:13,291856+00:00     HOME=/
2024-08-04T15:25:13,291856+00:00     TERM=linux
2024-08-04T15:25:13,291857+00:00     BOOT_IMAGE=/BOOT/debian@/vmlinuz-6.1.0-23-amd64
2024-08-04T15:25:13,416988+00:00 tsc: Refined TSC clocksource calibration: 2112.034 MHz
2024-08-04T15:25:13,421808+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0x1e71987fc4f, max_idle_ns: 440795235828 ns
2024-08-04T15:25:13,431859+00:00 clocksource: Switched to clocksource tsc
2024-08-04T15:25:13,540970+00:00 dca service started, version 1.12.1
2024-08-04T15:25:13,550970+00:00 i801_smbus 0000:00:1f.4: SPD Write Disable is set
2024-08-04T15:25:13,556130+00:00 i801_smbus 0000:00:1f.4: SMBus using PCI interrupt
2024-08-04T15:25:13,562679+00:00 i2c i2c-0: 2/4 memory slots populated (from DMI)
2024-08-04T15:25:13,568127+00:00 SCSI subsystem initialized
2024-08-04T15:25:13,571772+00:00 i2c i2c-0: Successfully instantiated SPD at 0x51
2024-08-04T15:25:13,578479+00:00 i2c i2c-0: Successfully instantiated SPD at 0x53
2024-08-04T15:25:13,588131+00:00 ACPI: bus type USB registered
2024-08-04T15:25:13,592693+00:00 usbcore: registered new interface driver usbfs
2024-08-04T15:25:13,597282+00:00 usbcore: registered new interface driver hub
2024-08-04T15:25:13,601780+00:00 usbcore: registered new device driver usb
2024-08-04T15:25:13,608669+00:00 igb: Intel(R) Gigabit Ethernet Network Driver
2024-08-04T15:25:13,613117+00:00 igb: Copyright (c) 2007-2014 Intel Corporation.
2024-08-04T15:25:13,618497+00:00 igb 0000:09:00.0: PHY reset is blocked due to SOL/IDER session.
2024-08-04T15:25:13,627943+00:00 nvme nvme0: pci function 0000:02:00.0
2024-08-04T15:25:13,632737+00:00 nvme nvme1: pci function 0000:07:00.0
2024-08-04T15:25:13,637859+00:00 nvme nvme2: pci function 0000:08:00.0
2024-08-04T15:25:13,645983+00:00 nvme nvme0: 8/0/0 default/read/poll queues
2024-08-04T15:25:13,652414+00:00  nvme0n1: p1
2024-08-04T15:25:13,657267+00:00 nvme nvme1: 8/0/0 default/read/poll queues
2024-08-04T15:25:13,662760+00:00 nvme nvme2: 8/0/0 default/read/poll queues
2024-08-04T15:25:13,668569+00:00 libata version 3.00 loaded.
2024-08-04T15:25:13,668771+00:00  nvme1n1: p2 p3 p4 p5
2024-08-04T15:25:13,668959+00:00 pps pps0: new PPS source ptp0
2024-08-04T15:25:13,672711+00:00  nvme2n1: p2 p3 p4 p5
2024-08-04T15:25:13,682947+00:00 igb 0000:09:00.0: added PHC on eth0
2024-08-04T15:25:13,687632+00:00 igb 0000:09:00.0: Intel(R) Gigabit Ethernet Network Connection
2024-08-04T15:25:13,692422+00:00 igb 0000:09:00.0: eth0: (PCIe:2.5Gb/s:Width x1) 18:31:bf:d0:6d:0d
2024-08-04T15:25:13,697205+00:00 igb 0000:09:00.0: eth0: PBA No: 001300-000
2024-08-04T15:25:13,701866+00:00 igb 0000:09:00.0: Using MSI-X interrupts. 4 rx queue(s), 4 tx queue(s)
2024-08-04T15:25:13,702302+00:00 xhci_hcd 0000:00:14.0: xHCI Host Controller
2024-08-04T15:25:13,711394+00:00 xhci_hcd 0000:00:14.0: new USB bus registered, assigned bus number 1
2024-08-04T15:25:13,716501+00:00 ahci 0000:00:17.0: version 3.0
2024-08-04T15:25:13,717408+00:00 xhci_hcd 0000:00:14.0: hcc params 0x200077c1 hci version 0x100 quirks 0x0000000001109810
2024-08-04T15:25:13,727281+00:00 ahci 0000:00:17.0: AHCI 0001.0301 32 slots 6 ports 6 Gbps 0x3f impl SATA mode
2024-08-04T15:25:13,732347+00:00 ahci 0000:00:17.0: flags: 64bit ncq sntf pm led clo only pio slum part ems deso sadm sds apst 
2024-08-04T15:25:13,740549+00:00 xhci_hcd 0000:00:14.0: xHCI Host Controller
2024-08-04T15:25:13,746951+00:00 xhci_hcd 0000:00:14.0: new USB bus registered, assigned bus number 2
2024-08-04T15:25:13,751931+00:00 xhci_hcd 0000:00:14.0: Host supports USB 3.0 SuperSpeed
2024-08-04T15:25:13,756982+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.01
2024-08-04T15:25:13,762123+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2024-08-04T15:25:13,767289+00:00 usb usb1: Product: xHCI Host Controller
2024-08-04T15:25:13,772396+00:00 usb usb1: Manufacturer: Linux 6.1.0-23-amd64 xhci-hcd
2024-08-04T15:25:13,777731+00:00 usb usb1: SerialNumber: 0000:00:14.0
2024-08-04T15:25:13,783242+00:00 hub 1-0:1.0: USB hub found
2024-08-04T15:25:13,788397+00:00 hub 1-0:1.0: 12 ports detected
2024-08-04T15:25:13,788729+00:00 pps pps1: new PPS source ptp1
2024-08-04T15:25:13,798757+00:00 igb 0000:0a:00.0: added PHC on eth1
2024-08-04T15:25:13,803927+00:00 igb 0000:0a:00.0: Intel(R) Gigabit Ethernet Network Connection
2024-08-04T15:25:13,809139+00:00 igb 0000:0a:00.0: eth1: (PCIe:2.5Gb/s:Width x1) 18:31:bf:d0:6d:0e
2024-08-04T15:25:13,810402+00:00 scsi host0: ahci
2024-08-04T15:25:13,811420+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.01
2024-08-04T15:25:13,811459+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2024-08-04T15:25:13,811475+00:00 usb usb2: Product: xHCI Host Controller
2024-08-04T15:25:13,811490+00:00 usb usb2: Manufacturer: Linux 6.1.0-23-amd64 xhci-hcd
2024-08-04T15:25:13,811491+00:00 usb usb2: SerialNumber: 0000:00:14.0
2024-08-04T15:25:13,811820+00:00 hub 2-0:1.0: USB hub found
2024-08-04T15:25:13,811930+00:00 hub 2-0:1.0: 6 ports detected
2024-08-04T15:25:13,815312+00:00 igb 0000:0a:00.0: eth1: PBA No: 001300-000
2024-08-04T15:25:13,822318+00:00 scsi host1: ahci
2024-08-04T15:25:13,824903+00:00 igb 0000:0a:00.0: Using MSI-X interrupts. 4 rx queue(s), 4 tx queue(s)
2024-08-04T15:25:13,831118+00:00 scsi host2: ahci
2024-08-04T15:25:13,880701+00:00 scsi host3: ahci
2024-08-04T15:25:13,886545+00:00 scsi host4: ahci
2024-08-04T15:25:13,892281+00:00 scsi host5: ahci
2024-08-04T15:25:13,897709+00:00 ata1: SATA max UDMA/133 abar m2048@0xde81d000 port 0xde81d100 irq 168
2024-08-04T15:25:13,903297+00:00 ata2: SATA max UDMA/133 abar m2048@0xde81d000 port 0xde81d180 irq 168
2024-08-04T15:25:13,908632+00:00 ata3: SATA max UDMA/133 abar m2048@0xde81d000 port 0xde81d200 irq 168
2024-08-04T15:25:13,913878+00:00 ata4: SATA max UDMA/133 abar m2048@0xde81d000 port 0xde81d280 irq 168
2024-08-04T15:25:13,918859+00:00 ata5: SATA max UDMA/133 abar m2048@0xde81d000 port 0xde81d300 irq 168
2024-08-04T15:25:13,923692+00:00 ata6: SATA max UDMA/133 abar m2048@0xde81d000 port 0xde81d380 irq 168
2024-08-04T15:25:13,931916+00:00 pps pps2: new PPS source ptp2
2024-08-04T15:25:13,936492+00:00 igb 0000:0b:00.0: added PHC on eth2
2024-08-04T15:25:13,940918+00:00 igb 0000:0b:00.0: Intel(R) Gigabit Ethernet Network Connection
2024-08-04T15:25:13,945384+00:00 igb 0000:0b:00.0: eth2: (PCIe:2.5Gb/s:Width x1) 18:31:bf:d0:6d:0f
2024-08-04T15:25:13,949938+00:00 igb 0000:0b:00.0: eth2: PBA No: 001300-000
2024-08-04T15:25:13,954262+00:00 igb 0000:0b:00.0: Using MSI-X interrupts. 4 rx queue(s), 4 tx queue(s)
2024-08-04T15:25:13,989583+00:00 pps pps3: new PPS source ptp3
2024-08-04T15:25:13,994073+00:00 igb 0000:0c:00.0: added PHC on eth3
2024-08-04T15:25:13,998417+00:00 igb 0000:0c:00.0: Intel(R) Gigabit Ethernet Network Connection
2024-08-04T15:25:14,002793+00:00 igb 0000:0c:00.0: eth3: (PCIe:2.5Gb/s:Width x1) 18:31:bf:d0:6d:10
2024-08-04T15:25:14,007315+00:00 igb 0000:0c:00.0: eth3: PBA No: 001300-000
2024-08-04T15:25:14,011734+00:00 igb 0000:0c:00.0: Using MSI-X interrupts. 4 rx queue(s), 4 tx queue(s)
2024-08-04T15:25:14,077093+00:00 usb 1-12: new high-speed USB device number 2 using xhci_hcd
2024-08-04T15:25:14,230171+00:00 usb 1-12: New USB device found, idVendor=1a40, idProduct=0101, bcdDevice= 1.11
2024-08-04T15:25:14,234937+00:00 usb 1-12: New USB device strings: Mfr=0, Product=1, SerialNumber=0
2024-08-04T15:25:14,239659+00:00 usb 1-12: Product: USB 2.0 Hub
2024-08-04T15:25:14,243838+00:00 ata3: SATA link down (SStatus 0 SControl 300)
2024-08-04T15:25:14,248873+00:00 ata5: SATA link down (SStatus 0 SControl 300)
2024-08-04T15:25:14,253339+00:00 ata2: SATA link up 6.0 Gbps (SStatus 133 SControl 300)
2024-08-04T15:25:14,257451+00:00 hub 1-12:1.0: USB hub found
2024-08-04T15:25:14,258623+00:00 ata1: SATA link up 6.0 Gbps (SStatus 133 SControl 300)
2024-08-04T15:25:14,262799+00:00 hub 1-12:1.0: 4 ports detected
2024-08-04T15:25:14,266843+00:00 ata6: SATA link down (SStatus 0 SControl 300)
2024-08-04T15:25:14,275756+00:00 ata4: SATA link down (SStatus 0 SControl 300)
2024-08-04T15:25:14,643349+00:00 ata1.00: ATA-12: WDC  WUH722020ALE6L4, PQGNW107, max UDMA/133
2024-08-04T15:25:14,658333+00:00 ata1.00: 39063650304 sectors, multi 16: LBA48 NCQ (depth 32), AA
2024-08-04T15:25:14,663240+00:00 ata1.00: Features: NCQ-sndrcv NCQ-prio
2024-08-04T15:25:14,667787+00:00 ata2.00: ATA-12: WDC  WUH722020ALE6L4, PQGNW108, max UDMA/133
2024-08-04T15:25:14,682470+00:00 ata2.00: 39063650304 sectors, multi 16: LBA48 NCQ (depth 32), AA
2024-08-04T15:25:14,686387+00:00 usb 1-12.1: new full-speed USB device number 3 using xhci_hcd
2024-08-04T15:25:14,692325+00:00 ata2.00: Features: NCQ-sndrcv NCQ-prio
2024-08-04T15:25:14,697293+00:00 ata1.00: configured for UDMA/133
2024-08-04T15:25:14,702459+00:00 scsi 0:0:0:0: Direct-Access     ATA      WDC  WUH722020AL W107 PQ: 0 ANSI: 5
2024-08-04T15:25:14,717395+00:00 ata2.00: configured for UDMA/133
2024-08-04T15:25:14,722905+00:00 scsi 1:0:0:0: Direct-Access     ATA      WDC  WUH722020AL W108 PQ: 0 ANSI: 5
2024-08-04T15:25:14,734938+00:00 sd 1:0:0:0: [sdb] 39063650304 512-byte logical blocks: (20.0 TB/18.2 TiB)
2024-08-04T15:25:14,734941+00:00 sd 0:0:0:0: [sda] 39063650304 512-byte logical blocks: (20.0 TB/18.2 TiB)
2024-08-04T15:25:14,740689+00:00 sd 1:0:0:0: [sdb] 4096-byte physical blocks
2024-08-04T15:25:14,740702+00:00 sd 1:0:0:0: [sdb] Write Protect is off
2024-08-04T15:25:14,740703+00:00 sd 1:0:0:0: [sdb] Mode Sense: 00 3a 00 00
2024-08-04T15:25:14,740715+00:00 sd 1:0:0:0: [sdb] Write cache: enabled, read cache: enabled, doesn't support DPO or FUA
2024-08-04T15:25:14,746675+00:00 sd 0:0:0:0: [sda] 4096-byte physical blocks
2024-08-04T15:25:14,751906+00:00 sd 1:0:0:0: [sdb] Preferred minimum I/O size 4096 bytes
2024-08-04T15:25:14,757486+00:00 sd 0:0:0:0: [sda] Write Protect is off
2024-08-04T15:25:14,784950+00:00 sd 0:0:0:0: [sda] Mode Sense: 00 3a 00 00
2024-08-04T15:25:14,784963+00:00 sd 0:0:0:0: [sda] Write cache: enabled, read cache: enabled, doesn't support DPO or FUA
2024-08-04T15:25:14,796217+00:00 sd 0:0:0:0: [sda] Preferred minimum I/O size 4096 bytes
2024-08-04T15:25:14,801975+00:00 igb 0000:09:00.0 enp9s0: renamed from eth0
2024-08-04T15:25:14,818999+00:00  sdb: sdb1
2024-08-04T15:25:14,824802+00:00 igb 0000:0a:00.0 enp10s0: renamed from eth1
2024-08-04T15:25:14,825476+00:00 sd 1:0:0:0: [sdb] Attached SCSI disk
2024-08-04T15:25:14,855580+00:00  sda: sda1
2024-08-04T15:25:14,861203+00:00 sd 0:0:0:0: [sda] Attached SCSI disk
2024-08-04T15:25:14,884907+00:00 igb 0000:0c:00.0 enp12s0: renamed from eth3
2024-08-04T15:25:14,929078+00:00 usb 1-12.1: New USB device found, idVendor=10c4, idProduct=ea60, bcdDevice= 1.00
2024-08-04T15:25:14,934900+00:00 usb 1-12.1: New USB device strings: Mfr=1, Product=2, SerialNumber=3
2024-08-04T15:25:14,940652+00:00 usb 1-12.1: Product: SkyConnect v1.0
2024-08-04T15:25:14,946322+00:00 usb 1-12.1: Manufacturer: Nabu Casa
2024-08-04T15:25:14,951904+00:00 usb 1-12.1: SerialNumber: aed64477baedec11b616d1d2ac51a8b2
2024-08-04T15:25:14,964899+00:00 igb 0000:0b:00.0 enp11s0: renamed from eth2
2024-08-04T15:25:15,130216+00:00 spl: loading out-of-tree module taints kernel.
2024-08-04T15:25:15,136060+00:00 spl: module verification failed: signature and/or required key missing - tainting kernel
2024-08-04T15:25:15,237051+00:00 zfs: module license 'CDDL' taints kernel.
2024-08-04T15:25:15,242734+00:00 Disabling lock debugging due to kernel taint
2024-08-04T15:25:16,688634+00:00 ZFS: Loaded module v2.2.4-1~bpo12+1, ZFS pool version 5000, ZFS filesystem version 5
2024-08-04T15:25:17,205410+00:00 Not activating Mandatory Access Control as /sbin/tomoyo-init does not exist.
2024-08-04T15:25:17,287689+00:00 systemd[1]: Inserted module 'autofs4'
2024-08-04T15:25:17,374263+00:00 systemd[1]: systemd 252.26-1~deb12u2 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 -PWQUALITY +P11KIT +QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -BPF_FRAMEWORK -XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-08-04T15:25:17,399300+00:00 systemd[1]: Detected architecture x86-64.
2024-08-04T15:25:17,426806+00:00 systemd[1]: Hostname set to <h1>.
2024-08-04T15:25:17,608344+00:00 systemd[1]: Queued start job for default target graphical.target.
2024-08-04T15:25:17,643280+00:00 systemd[1]: Created slice system-getty.slice - Slice /system/getty.
2024-08-04T15:25:17,656715+00:00 systemd[1]: Created slice system-modprobe.slice - Slice /system/modprobe.
2024-08-04T15:25:17,670517+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2024-08-04T15:25:17,684225+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-08-04T15:25:17,705480+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2024-08-04T15:25:17,727907+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2024-08-04T15:25:17,751018+00:00 systemd[1]: Expecting device dev-disk-by\x2did-nvme\x2deui.1852274202160001001b444a44911584\x2dpart2.device - /dev/disk/by-id/nvme-eui.1852274202160001001b444a44911584-part2...
2024-08-04T15:25:17,774794+00:00 systemd[1]: Expecting device dev-disk-by\x2did-nvme\x2deui.1852494204280001001b444a4491ba6f\x2dpart2.device - /dev/disk/by-id/nvme-eui.1852494204280001001b444a4491ba6f-part2...
2024-08-04T15:25:17,798872+00:00 systemd[1]: Reached target cryptsetup.target - Local Encrypted Volumes.
2024-08-04T15:25:17,815411+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2024-08-04T15:25:17,832598+00:00 systemd[1]: Reached target network-online.target - Network is Online.
2024-08-04T15:25:17,849784+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-08-04T15:25:17,866642+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-08-04T15:25:17,883249+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-08-04T15:25:17,899915+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2024-08-04T15:25:17,940147+00:00 systemd[1]: Listening on rpcbind.socket - RPCbind Server Activation Socket.
2024-08-04T15:25:17,957969+00:00 systemd[1]: Listening on systemd-initctl.socket - initctl Compatibility Named Pipe.
2024-08-04T15:25:17,976770+00:00 systemd[1]: Listening on systemd-journald-audit.socket - Journal Audit Socket.
2024-08-04T15:25:17,994850+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2024-08-04T15:25:18,013174+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Socket.
2024-08-04T15:25:18,031679+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-08-04T15:25:18,049658+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-08-04T15:25:18,085265+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2024-08-04T15:25:18,103901+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2024-08-04T15:25:18,122556+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2024-08-04T15:25:18,141136+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2024-08-04T15:25:18,159414+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2024-08-04T15:25:18,176654+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS was skipped because of an unmet condition check (ConditionPathExists=/etc/krb5.keytab).
2024-08-04T15:25:18,194963+00:00 systemd[1]: Starting keyboard-setup.service - Set the console keyboard layout...
2024-08-04T15:25:18,213444+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2024-08-04T15:25:18,240540+00:00 systemd[1]: Starting modprobe@configfs.service - Load Kernel Module configfs...
2024-08-04T15:25:18,259371+00:00 systemd[1]: Starting modprobe@dm_mod.service - Load Kernel Module dm_mod...
2024-08-04T15:25:18,278277+00:00 systemd[1]: Starting modprobe@drm.service - Load Kernel Module drm...
2024-08-04T15:25:18,297166+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2024-08-04T15:25:18,316368+00:00 systemd[1]: Starting modprobe@fuse.service - Load Kernel Module fuse...
2024-08-04T15:25:18,328752+00:00 pstore: ignoring unexpected backend 'efi'
2024-08-04T15:25:18,344610+00:00 systemd[1]: Starting modprobe@loop.service - Load Kernel Module loop...
2024-08-04T15:25:18,357383+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2024-08-04T15:25:18,358019+00:00 device-mapper: uevent: version 1.0.3
2024-08-04T15:25:18,361943+00:00 device-mapper: ioctl: 4.47.0-ioctl (2022-07-28) initialised: dm-devel@redhat.com
2024-08-04T15:25:18,398394+00:00 fuse: init (API version 7.37)
2024-08-04T15:25:18,407179+00:00 systemd[1]: Starting networking.service - Network initialization...
2024-08-04T15:25:18,419940+00:00 loop: module loaded
2024-08-04T15:25:18,432759+00:00 systemd[1]: open-iscsi.service - Login to default iSCSI targets was skipped because no trigger condition checks were met.
2024-08-04T15:25:18,470566+00:00 ACPI: bus type drm_connector registered
2024-08-04T15:25:18,497209+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-08-04T15:25:18,515889+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2024-08-04T15:25:18,533627+00:00 systemd[1]: Starting systemd-remount-fs.service - Remount Root and Kernel File Systems...
2024-08-04T15:25:18,560013+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2024-08-04T15:25:18,578454+00:00 systemd[1]: Starting zfs-import-zboot.service...
2024-08-04T15:25:18,597532+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2024-08-04T15:25:18,614126+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2024-08-04T15:25:18,630802+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2024-08-04T15:25:18,641327+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2024-08-04T15:25:18,644623+00:00 Bridge firewalling registered
2024-08-04T15:25:18,672279+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2024-08-04T15:25:18,689024+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2024-08-04T15:25:18,703624+00:00 FS-Cache: Loaded
2024-08-04T15:25:18,714051+00:00 systemd[1]: Finished keyboard-setup.service - Set the console keyboard layout.
2024-08-04T15:25:18,730915+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2024-08-04T15:25:18,748012+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-08-04T15:25:18,756528+00:00 Key type ceph registered
2024-08-04T15:25:18,756605+00:00 systemd[1]: Finished modprobe@configfs.service - Load Kernel Module configfs.
2024-08-04T15:25:18,765380+00:00 libceph: loaded (mon/osd proto 15/24)
2024-08-04T15:25:18,789741+00:00 systemd[1]: modprobe@dm_mod.service: Deactivated successfully.
2024-08-04T15:25:18,798286+00:00 systemd[1]: Finished modprobe@dm_mod.service - Load Kernel Module dm_mod.
2024-08-04T15:25:18,815263+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-08-04T15:25:18,815854+00:00 ceph: loaded (mds proto 32)
2024-08-04T15:25:18,890587+00:00 IPVS: Registered protocols (TCP, UDP, SCTP, AH, ESP)
2024-08-04T15:25:18,898113+00:00 IPVS: Connection hash table configured (size=4096, memory=32Kbytes)
2024-08-04T15:25:18,905693+00:00 IPVS: ipvs loaded.
2024-08-04T15:25:18,914164+00:00 IPVS: [rr] scheduler registered.
2024-08-04T15:25:18,973498+00:00 nct6775: Found NCT6791D or compatible chip at 0x2e:0x290
2024-08-04T15:25:19,023875+00:00 rbd: loaded (major 253)
2024-08-04T15:25:19,035510+00:00 usbcore: registered new device driver usbip-host
2024-08-04T15:25:19,389153+00:00 systemd-journald[529]: Received client request to flush runtime journal.
2024-08-04T15:25:19,533426+00:00 sd 0:0:0:0: Attached scsi generic sg0 type 0
2024-08-04T15:25:19,544907+00:00 sd 1:0:0:0: Attached scsi generic sg1 type 0
2024-08-04T15:25:19,582723+00:00 lan: port 1(enp9s0) entered blocking state
2024-08-04T15:25:19,587712+00:00 lan: port 1(enp9s0) entered disabled state
2024-08-04T15:25:19,593388+00:00 lan: port 2(enp10s0) entered blocking state
2024-08-04T15:25:19,598091+00:00 lan: port 2(enp10s0) entered disabled state
2024-08-04T15:25:19,602740+00:00 device enp10s0 entered promiscuous mode
2024-08-04T15:25:19,607244+00:00 device enp9s0 entered promiscuous mode
2024-08-04T15:25:19,623563+00:00 input: Sleep Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input0
2024-08-04T15:25:19,628387+00:00 ACPI: button: Sleep Button [SLPB]
2024-08-04T15:25:19,633208+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input1
2024-08-04T15:25:19,647600+00:00 ACPI: button: Power Button [PWRB]
2024-08-04T15:25:19,656019+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input2
2024-08-04T15:25:19,679054+00:00 ACPI: button: Power Button [PWRF]
2024-08-04T15:25:19,702402+00:00 igb 0000:09:00.0 enp9s0: igb: enp9s0 NIC Link is Up 1000 Mbps Full Duplex, Flow Control: RX
2024-08-04T15:25:19,717172+00:00 lan: port 1(enp9s0) entered blocking state
2024-08-04T15:25:19,722799+00:00 lan: port 1(enp9s0) entered forwarding state
2024-08-04T15:25:19,767031+00:00 intel_pmc_core INT33A1:00:  initialized
2024-08-04T15:25:19,773535+00:00 IPMI message handler: version 39.2
2024-08-04T15:25:19,798923+00:00 ipmi device interface
2024-08-04T15:25:19,805928+00:00 8021q: 802.1Q VLAN Support v1.8
2024-08-04T15:25:19,812016+00:00 8021q: adding VLAN 0 to HW filter on device enp9s0
2024-08-04T15:25:19,818002+00:00 8021q: adding VLAN 0 to HW filter on device enp10s0
2024-08-04T15:25:19,821344+00:00 EDAC MC0: Giving out device to module ie31200_edac controller IE31200: DEV 0000:00:00.0 (POLLED)
2024-08-04T15:25:19,837066+00:00 ipmi_si: IPMI System Interface driver
2024-08-04T15:25:19,847829+00:00 device lan entered promiscuous mode
2024-08-04T15:25:19,854812+00:00 ipmi_si dmi-ipmi-si.0: ipmi_platform: probing via SMBIOS
2024-08-04T15:25:19,860712+00:00 ipmi_platform: ipmi_si: SMBIOS: io 0xca2 regsize 1 spacing 1 irq 0
2024-08-04T15:25:19,866874+00:00 ipmi_si: Adding SMBIOS-specified kcs state machine
2024-08-04T15:25:19,873043+00:00 ipmi_si IPI0001:00: ipmi_platform: probing via ACPI
2024-08-04T15:25:19,879431+00:00 ipmi_si IPI0001:00: ipmi_platform: [io  0x0ca2] regsize 1 spacing 1 irq 0
2024-08-04T15:25:19,900528+00:00 usbip-host 1-12.1: usbip-host: register new device (bus 1 dev 3)
2024-08-04T15:25:19,913486+00:00 ipmi_si dmi-ipmi-si.0: Removing SMBIOS-specified kcs state machine in favor of ACPI
2024-08-04T15:25:19,919899+00:00 ipmi_si: Adding ACPI-specified kcs state machine
2024-08-04T15:25:19,931086+00:00 input: PC Speaker as /devices/platform/pcspkr/input/input3
2024-08-04T15:25:19,939097+00:00 ee1004 0-0051: 512 byte EE1004-compliant SPD EEPROM, read-only
2024-08-04T15:25:19,945453+00:00 ee1004 0-0053: 512 byte EE1004-compliant SPD EEPROM, read-only
2024-08-04T15:25:19,957265+00:00 ipmi_si: Trying ACPI-specified kcs state machine at i/o address 0xca2, slave address 0x20, irq 0
2024-08-04T15:25:19,970204+00:00 mei_me 0000:00:16.0: Device doesn't have valid ME Interface
2024-08-04T15:25:19,970449+00:00 usbcore: registered new interface driver usbserial_generic
2024-08-04T15:25:19,982827+00:00 usbserial: USB Serial support registered for generic
2024-08-04T15:25:19,993071+00:00 iTCO_vendor_support: vendor-support=0
2024-08-04T15:25:20,006102+00:00 usbcore: registered new interface driver cp210x
2024-08-04T15:25:20,015900+00:00 usbserial: USB Serial support registered for cp210x
2024-08-04T15:25:20,026115+00:00 Console: switching to colour dummy device 80x25
2024-08-04T15:25:20,026170+00:00 ast 0000:04:00.0: vgaarb: deactivate vga console
2024-08-04T15:25:20,026330+00:00 ast 0000:04:00.0: [drm] Using P2A bridge for configuration
2024-08-04T15:25:20,026336+00:00 ast 0000:04:00.0: [drm] AST 2400 detected
2024-08-04T15:25:20,026348+00:00 ast 0000:04:00.0: [drm] Using analog VGA
2024-08-04T15:25:20,026355+00:00 ast 0000:04:00.0: [drm] dram MCLK=408 Mhz type=6 bus_width=16
2024-08-04T15:25:20,029371+00:00 iTCO_wdt iTCO_wdt: unable to reset NO_REBOOT flag, device disabled by hardware/BIOS
2024-08-04T15:25:20,035685+00:00 RAPL PMU: API unit is 2^-32 Joules, 3 fixed counters, 655360 ms ovfl timer
2024-08-04T15:25:20,035695+00:00 RAPL PMU: hw unit of domain pp0-core 2^-14 Joules
2024-08-04T15:25:20,035699+00:00 RAPL PMU: hw unit of domain package 2^-14 Joules
2024-08-04T15:25:20,035701+00:00 RAPL PMU: hw unit of domain dram 2^-14 Joules
2024-08-04T15:25:20,038758+00:00 [drm] Initialized ast 0.1.0 20120228 for 0000:04:00.0 on minor 0
2024-08-04T15:25:20,049288+00:00 fbcon: astdrmfb (fb0) is primary device
2024-08-04T15:25:20,057798+00:00 cryptd: max_cpu_qlen set to 1000
2024-08-04T15:25:20,078412+00:00 AVX2 version of gcm_enc/dec engaged.
2024-08-04T15:25:20,078456+00:00 AES CTR mode by8 optimization enabled
2024-08-04T15:25:20,088617+00:00 Console: switching to colour frame buffer device 128x48
2024-08-04T15:25:20,109862+00:00 ast 0000:04:00.0: [drm] fb0: astdrmfb frame buffer device
2024-08-04T15:25:20,263550+00:00 ipmi_si IPI0001:00: IPMI message handler: Found new BMC (man_id: 0x000a3f, prod_id: 0x0e73, dev_id: 0x20)
2024-08-04T15:25:20,466596+00:00 ipmi_si IPI0001:00: IPMI kcs interface initialized
2024-08-04T15:25:20,470192+00:00 ipmi_ssif: IPMI SSIF Interface driver
2024-08-04T15:25:20,473955+00:00 intel_rapl_common: Found RAPL domain package
2024-08-04T15:25:20,473978+00:00 intel_rapl_common: Found RAPL domain core
2024-08-04T15:25:20,473994+00:00 intel_rapl_common: Found RAPL domain dram
2024-08-04T15:25:20,616927+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lan: link becomes ready
2024-08-04T15:25:21,765549+00:00 FAT-fs (nvme1n1p2): Volume was not properly unmounted. Some data may be corrupt. Please run fsck.
2024-08-04T15:25:21,773192+00:00 FAT-fs (nvme2n1p2): Volume was not properly unmounted. Some data may be corrupt. Please run fsck.
2024-08-04T15:25:22,834530+00:00 RPC: Registered named UNIX socket transport module.
2024-08-04T15:25:22,834984+00:00 RPC: Registered udp transport module.
2024-08-04T15:25:22,835400+00:00 RPC: Registered tcp transport module.
2024-08-04T15:25:22,835846+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2024-08-04T15:25:28,009089+00:00 usbip-host 1-12.1: stub up
2024-08-04T15:25:28,409358+00:00 usbip-host 1-12.1: endpoint 0 is stalled
2024-08-04T15:25:28,410300+00:00 usbip-host 1-12.1: endpoint 0 is stalled
2024-08-04T15:25:28,410972+00:00 usbip-host 1-12.1: endpoint 0 is stalled
2024-08-04T15:25:37,034036+00:00 audit: type=1400 audit(1722785137.571:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="cri-containerd.apparmor.d" pid=3521 comm="apparmor_parser"
2024-08-04T15:25:46,040461+00:00 Initializing XFRM netlink socket
2024-08-04T15:25:46,423644+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2024-08-04T15:25:47,535684+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-08-04T15:25:49,285036+00:00 eth0: renamed from tmp8868a
2024-08-04T15:25:49,317716+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:25:49,317831+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcf228d89e07e3: link becomes ready
2024-08-04T15:25:51,587054+00:00 eth0: renamed from tmp838eb
2024-08-04T15:25:51,603163+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:25:51,603302+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5d9688897f63: link becomes ready
2024-08-04T15:25:51,854630+00:00 eth0: renamed from tmpdea0c
2024-08-04T15:25:51,890882+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc02b3905a6dfb: link becomes ready
2024-08-04T15:25:52,074771+00:00 eth0: renamed from tmp8cc5d
2024-08-04T15:25:52,104298+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc859384ae38a5: link becomes ready
2024-08-04T15:25:52,275362+00:00 eth0: renamed from tmp824a6
2024-08-04T15:25:52,304541+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc503b32a2c6a7: link becomes ready
2024-08-04T15:25:52,483498+00:00 eth0: renamed from tmp8baec
2024-08-04T15:25:52,515675+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc910004d47ea4: link becomes ready
2024-08-04T15:25:52,730869+00:00 eth0: renamed from tmpa8cf5
2024-08-04T15:25:52,747262+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:25:52,747329+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc11205bc64ac7: link becomes ready
2024-08-04T15:25:52,895235+00:00 eth0: renamed from tmp09457
2024-08-04T15:25:52,937148+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxce3e3ac922558: link becomes ready
2024-08-04T15:25:53,082987+00:00 eth0: renamed from tmpd994e
2024-08-04T15:25:53,124721+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcbadff7f8234a: link becomes ready
2024-08-04T15:25:53,399310+00:00 eth0: renamed from tmpfb373
2024-08-04T15:25:53,423333+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcef0c82914670: link becomes ready
2024-08-04T15:25:53,587468+00:00 eth0: renamed from tmp1f14d
2024-08-04T15:25:53,628973+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc2b284e5fe4ce: link becomes ready
2024-08-04T15:25:53,795492+00:00 eth0: renamed from tmp51b3b
2024-08-04T15:25:53,827831+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:25:53,827880+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcd458e6709d60: link becomes ready
2024-08-04T15:25:53,987580+00:00 eth0: renamed from tmp2790e
2024-08-04T15:25:54,019605+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc4c920d1320f1: link becomes ready
2024-08-04T15:25:54,183888+00:00 eth0: renamed from tmp97ef6
2024-08-04T15:25:54,203667+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcfd427869bc62: link becomes ready
2024-08-04T15:25:54,355662+00:00 eth0: renamed from tmp0f358
2024-08-04T15:25:54,383840+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxce316820ded76: link becomes ready
2024-08-04T15:25:54,550523+00:00 eth0: renamed from tmpa23b1
2024-08-04T15:25:54,567945+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc3b052960bf39: link becomes ready
2024-08-04T15:25:54,719691+00:00 eth0: renamed from tmp7bc47
2024-08-04T15:25:54,743683+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc83b895bb0fa9: link becomes ready
2024-08-04T15:25:54,891772+00:00 eth0: renamed from tmp64120
2024-08-04T15:25:54,919878+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:25:54,920251+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcf8bd3ef502c5: link becomes ready
2024-08-04T15:25:55,095925+00:00 eth0: renamed from tmp2a7a5
2024-08-04T15:25:55,119811+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcbdbcfb757b99: link becomes ready
2024-08-04T15:25:55,284576+00:00 eth0: renamed from tmpb5a8c
2024-08-04T15:25:55,316741+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc3136ad64a403: link becomes ready
2024-08-04T15:25:55,463794+00:00 eth0: renamed from tmp01580
2024-08-04T15:25:55,500176+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxccc2dfd51c9f5: link becomes ready
2024-08-04T15:25:56,172175+00:00 eth0: renamed from tmp53f71
2024-08-04T15:25:56,204086+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:25:56,204506+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcefb5df718e0f: link becomes ready
2024-08-04T15:25:56,760822+00:00 eth0: renamed from tmpe8f47
2024-08-04T15:25:56,780964+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcaf288253fc8a: link becomes ready
2024-08-04T15:25:59,172599+00:00 eth0: renamed from tmp8703a
2024-08-04T15:25:59,196920+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:25:59,197776+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb7c0ed9dd42e: link becomes ready
2024-08-04T15:26:00,341370+00:00 eth0: renamed from tmp357d1
2024-08-04T15:26:00,381768+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:26:00,383259+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcbf04ad6c9b4a: link becomes ready
2024-08-04T15:26:09,149629+00:00 eth0: renamed from tmpf5176
2024-08-04T15:26:09,188039+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:26:09,188430+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxca7a944ff01cc: link becomes ready
2024-08-04T15:42:18,451573+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-08-04T15:45:42,201554+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-08-04T15:45:42,272105+00:00 eth0: renamed from tmpc6307
2024-08-04T15:45:42,303046+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcf874b78c7bcf: link becomes ready
2024-08-04T15:59:26,844703+00:00 eth0: renamed from tmpde091
2024-08-04T15:59:26,873706+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-08-04T15:59:26,874308+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcdcccb41811ea: link becomes ready
2024-08-04T15:59:39,917446+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-08-04T16:03:12,633033+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-08-04T16:03:12,684766+00:00 eth0: renamed from tmp9a214
2024-08-04T16:03:12,713235+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb9692533e4ab: link becomes ready
2024-08-04T16:21:37,075661+00:00 printk: dmesg (24064): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
