[
  {
    "containers": [
      {
        "cgroup-id": 11064,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2414fd0_90c7_4a11_8dd3_9d468fabbba7.slice/cri-containerd-992892b78ec5ea81f888d291b7cb11f22f507758d40731753f006ce972dfc82e.scope"
      }
    ],
    "ips": [
      "10.10.0.62"
    ],
    "name": "ingress-nginx-internal-controller-5d8459498c-gz5jp",
    "namespace": "network"
  },
  {
    "containers": [
      {
        "cgroup-id": 18629,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3948f11_5c0b_4eb1_8f19_655f30bcbca4.slice/cri-containerd-d90cc93570cef9e90c4549e758006c4b0e732d12b8040cb8d689ee31c2252d39.scope"
      }
    ],
    "ips": [
      "192.168.1.11"
    ],
    "name": "cilium-operator-9d6c4d79-mdxcj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9431,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod628e0335_1027_4ece_8433_6248f6318050.slice/cri-containerd-3f26d1b96518599c0e30d37129995b144016e1a75acd3033131eba46ec2d7d4f.scope"
      }
    ],
    "ips": [
      "10.10.0.103"
    ],
    "name": "minio-0",
    "namespace": "storage"
  },
  {
    "containers": [
      {
        "cgroup-id": 12342,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5b8c17e_227c_4daf_b0f9_3a57095cfcb7.slice/cri-containerd-68d3047f0558420ed36fdd88408b58e0a247d4ffcc39f9c11d8560354df7490c.scope"
      },
      {
        "cgroup-id": 12484,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5b8c17e_227c_4daf_b0f9_3a57095cfcb7.slice/cri-containerd-713aeb19bf88522fbf8e03353807bd6c9b7e49e2c77cba03c403a01ae9922c72.scope"
      }
    ],
    "ips": [
      "10.10.0.160"
    ],
    "name": "k8tz-6c9d89b4bf-drdcm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 14756,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd734368_ca17_41bd_81e7_85ea53015cf3.slice/cri-containerd-838d03c781ba140b9bb31e667ceb6099b9257796070acfdfce3ac113b955b5b8.scope"
      }
    ],
    "ips": [
      "10.10.0.148"
    ],
    "name": "coredns-6799fbcd5-nfdkr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8934,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode947d31d_2275_46ce_a304_6236cae0a549.slice/cri-containerd-bb9104ddee8955d788f614effe786a8160899c9aa501fb0c1a3bcfff0bfd1bf6.scope"
      }
    ],
    "ips": [
      "192.168.1.11"
    ],
    "name": "multus-9gfpz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10212,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c0adc62_4c62_44a3_9bc1_9e248709b1cf.slice/cri-containerd-9159c6bbf4e1a6d87de957567253d05f7ebb3ec04fd18e930b3be8fb9eee8d33.scope"
      }
    ],
    "ips": [
      "10.10.0.234"
    ],
    "name": "reloader-7fb44dcc5f-fmsxj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1ceb180_a9e5_4876_a1e9_c63b6ba46559.slice/cri-containerd-b23aea0e9721614bad4f8ac844f0cc57cb6d62582b82c16e21268003b82e3063.scope"
      }
    ],
    "ips": [
      "10.10.0.83"
    ],
    "name": "image-automation-controller-79447887bb-45xt5",
    "namespace": "flux-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10070,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1b3f27_5e7d_4433_bf63_38c1c25663bb.slice/cri-containerd-8435c5b109c1a29d8b05cbcee55aa0167c09c34634202ef9397bddf88e7dc861.scope"
      },
      {
        "cgroup-id": 9999,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1b3f27_5e7d_4433_bf63_38c1c25663bb.slice/cri-containerd-2bcd3a9bbeaea0548235e04aea8d6f215f2a1b829c668f3c03bf0d7eaff8195e.scope"
      }
    ],
    "ips": [
      "10.10.0.204"
    ],
    "name": "hubble-ui-75f899dc7c-jnphv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 18913,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e6ab653_a903_4f9e_a05c_858166617590.slice/cri-containerd-63a915cbd65a4bdacbb1d2b03694b8c26ac9ed828e289d833515af601341d365.scope"
      }
    ],
    "ips": [
      "192.168.1.11"
    ],
    "name": "cilium-lm9tq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 19055,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1f77cdd_3e96_4265_b53e_77a044a0b3cc.slice/cri-containerd-20373b24bafa1dec301a2812b2e21fb2fc82c061151937e3dc2e74a5f2e034c3.scope"
      }
    ],
    "ips": [
      "10.10.0.149"
    ],
    "name": "hubble-relay-f4457696c-r2rg7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 13549,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda21ab570_d5e5_4d3c_8aec_94d7ed05c5f6.slice/cri-containerd-be21bfb49f4e4310cb58edb3efe90942a06a6eeacc64799bc1ada31397b5a2e0.scope"
      }
    ],
    "ips": [
      "10.10.0.37"
    ],
    "name": "minio-kes-6777b4676f-w866r",
    "namespace": "storage"
  },
  {
    "containers": [
      {
        "cgroup-id": 12839,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f182242_3df5_4cac_8a40_60d11db430e4.slice/cri-containerd-570b4e3984c938df54ec244b8b9e8da8c559e1c48b2a3dd4ea67dae826121c17.scope"
      }
    ],
    "ips": [
      "10.10.0.71"
    ],
    "name": "source-controller-7944c8d8b4-fm8bt",
    "namespace": "flux-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 13478,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c249b4e_a5cb_4446_bbd2_748153fe5f90.slice/cri-containerd-cf5e9b5c1772ac80e55e1a99aa2631dd0bbe46ec03d49211e919079a7b3b8d48.scope"
      }
    ],
    "ips": [
      "10.10.0.35"
    ],
    "name": "snapshot-validation-webhook-5697d649bc-vgwmq",
    "namespace": "storage"
  },
  {
    "containers": [
      {
        "cgroup-id": 14472,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3b066ac_3f83_4a5e_b724_3ddddc02ad85.slice/cri-containerd-6b2391bec6437d394e14d255f049507cf419281f0874845611a778d43187c8f8.scope"
      }
    ],
    "ips": [
      "10.10.0.21"
    ],
    "name": "system-upgrade-controller-d67784b5b-4rw8c",
    "namespace": "system-upgrade"
  },
  {
    "containers": [
      {
        "cgroup-id": 14401,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod819bacc7_6bcf_4002_a466_a9b69abd29cf.slice/cri-containerd-911f148b05317ad6fe14bd8d5df34b5addd75e4540b6fef4b78b903b4c91369d.scope"
      }
    ],
    "ips": [
      "10.10.0.142"
    ],
    "name": "cert-manager-cainjector-7477d56b47-p8h82",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 9644,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa52a09a_2afc_49dc_b13a_8ad237aff8ad.slice/cri-containerd-2f5287d07e37c1aa4ea2212e4bad56742eb83c33f34642a9b630610362d473d0.scope"
      }
    ],
    "ips": [
      "10.10.0.36"
    ],
    "name": "metrics-server-bc7c58fdf-wnd6t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8650,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6299ca4e_2925_4349_91b2_a0aac80c6a7e.slice/cri-containerd-3ec32d0c8e103509da7667c1182ca5305249a05c30791c4d05fbecf52ebcb625.scope"
      },
      {
        "cgroup-id": 9502,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6299ca4e_2925_4349_91b2_a0aac80c6a7e.slice/cri-containerd-ada55f855ca0e28739e016b11536e5a860e00c168629696d11446f45a7a1b30c.scope"
      }
    ],
    "ips": [
      "192.168.1.11"
    ],
    "name": "openebs-zfs-localpv-node-2pfwm",
    "namespace": "storage"
  },
  {
    "containers": [
      {
        "cgroup-id": 11774,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda212e8f6_0013_49e6_b00b_72a9e0031917.slice/cri-containerd-dd953768435df1c6873e0d18ec4b00f55feacf8515bd91515990b3ac70ba3723.scope"
      }
    ],
    "ips": [
      "10.10.0.180"
    ],
    "name": "kustomize-controller-78b78bf57d-sx42s",
    "namespace": "flux-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8082,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2470d749_3313_4b51_87d1_487278baa440.slice/cri-containerd-1a1016fd25d882233acbbc0373321af1136b720a2424b5e777dda52719835686.scope"
      }
    ],
    "ips": [
      "192.168.1.11"
    ],
    "name": "kube-vip-98bwj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 11845,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3336091_979b_43e7_8149_16994be41781.slice/cri-containerd-5460cebd6e0587413e5f40b7453262ced58346a9376bda92e6152bc7975adb47.scope"
      }
    ],
    "ips": [
      "10.10.0.51"
    ],
    "name": "cert-manager-77cdc7956d-xj7vw",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 12697,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64714612_fc8f_4056_8a5e_637e5f1cb4b8.slice/cri-containerd-9bbd17ee23cb81c88e41c57fa0b9e4e40d7ee78d8a4f4433dbdf6bbfb209720d.scope"
      }
    ],
    "ips": [
      "10.10.0.161"
    ],
    "name": "cert-manager-webhook-6d5cb854fc-gp94j",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 13620,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03b3a000_ed7a_468a_8d60_2876246beb1d.slice/cri-containerd-c3e73adc957cfd4b9ac8ca7cd217ea3a4b7e5a7ec8a8066ea6a8a377ca4dadf4.scope"
      }
    ],
    "ips": [
      "10.10.0.151"
    ],
    "name": "minio-kes-6777b4676f-j6sfq",
    "namespace": "storage"
  },
  {
    "containers": [
      {
        "cgroup-id": 12626,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04e3966d_d278_4bcc_a89d_4d7bd92ef084.slice/cri-containerd-95c76b5f815a30860862be83fefb357325706b91adc96a832785204106c03f19.scope"
      }
    ],
    "ips": [
      "10.10.0.175"
    ],
    "name": "snapshot-controller-6c64f66dc-tmwtc",
    "namespace": "storage"
  },
  {
    "containers": [
      {
        "cgroup-id": 12910,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65ac5a4f_1c1c_4be9_973a_efbd4ac3aa2b.slice/cri-containerd-8ee434a342b1c5f8b872a9a2ff7a755d96c482f514aea8f71bec92c284de63c2.scope"
      }
    ],
    "ips": [
      "10.10.0.40"
    ],
    "name": "image-reflector-controller-65df777f5c-bwn9d",
    "namespace": "flux-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10354,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1527b7ec_9b5f_4a35_91ca_cf2faf07c46c.slice/cri-containerd-90924bd6251452fafc94cb8fa2f1812169b297a1f59a3055b1eef01761c701b0.scope"
      }
    ],
    "ips": [
      "10.10.0.137"
    ],
    "name": "echo-server-7975c47f84-l9pfk",
    "namespace": "network"
  },
  {
    "containers": [
      {
        "cgroup-id": 14046,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-64f8988b2b9d93d4235ed7d9e61b2bfe22fbd436815506702705c7adac91afa4.scope"
      },
      {
        "cgroup-id": 13762,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-7ab3306de49937a9787f39daae076da52ee14ef22f1712bdbd2f0666b4e46922.scope"
      },
      {
        "cgroup-id": 14117,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-2d485d03de6c5d0d9c3bc3bd8deff09ff6485056f0e5b46269113c0cc16cb00d.scope"
      },
      {
        "cgroup-id": 13407,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-b30d6fddc8df3b6124a59898e45e7d96da6c7a7d18651fe6588e7322c11ee426.scope"
      },
      {
        "cgroup-id": 13904,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-366c4259831dceda6e0208fd6bba131fe4e414b2905af10bfcc03d49310fd8c2.scope"
      }
    ],
    "ips": [
      "10.10.0.25"
    ],
    "name": "openebs-zfs-localpv-controller-6c66fff5bd-trkl2",
    "namespace": "storage"
  },
  {
    "containers": [
      {
        "cgroup-id": 10709,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc39262bb_5abb_47e4_8a64_7f12c675d3b9.slice/cri-containerd-bdf0abb297da42ab7e015ccf1a7a3c16d0b347957705549cf4369878e018591f.scope"
      }
    ],
    "ips": [
      "10.10.0.29"
    ],
    "name": "k8s-gateway-67ff7c6b99-qbzzk",
    "namespace": "network"
  },
  {
    "containers": [
      {
        "cgroup-id": 11916,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf52e8fa7_83f3_44d2_90b2_a6a7ec3d9af2.slice/cri-containerd-50c161e296ca39ae812b8bc2e66db53d86961468c0f64d428a73a7e2d6219c5d.scope"
      }
    ],
    "ips": [
      "10.10.0.88"
    ],
    "name": "notification-controller-685bdc466d-kcqmc",
    "namespace": "flux-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 14614,
        "cgroup-path": "/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19844677_4565_40b4_8e83_e6e1c9e39200.slice/cri-containerd-843ff6a0a51384b9d6f168a399299859b06e2cec86f1dc07d81683dfac14becf.scope"
      }
    ],
    "ips": [
      "10.10.0.114"
    ],
    "name": "helm-controller-8b6b769d4-9l6gp",
    "namespace": "flux-system"
  }
]

