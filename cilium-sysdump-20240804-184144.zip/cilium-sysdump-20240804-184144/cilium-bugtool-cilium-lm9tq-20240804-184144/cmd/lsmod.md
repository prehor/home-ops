Module                  Size  Used by
tcp_diag               16384  0
udp_diag               16384  0
inet_diag              24576  2 tcp_diag,udp_diag
cls_bpf                24576  57
sch_ingress            16384  29
xt_TPROXY              16384  2
nf_tproxy_ipv6         20480  1 xt_TPROXY
nf_tproxy_ipv4         20480  1 xt_TPROXY
nft_chain_nat          16384  3
xt_nat                 16384  1
xt_MASQUERADE          20480  1
xt_set                 16384  1
xt_CT                  16384  5
xt_mark                16384  2
ip_set_hash_ip         45056  2
ip_set                 61440  2 ip_set_hash_ip,xt_set
veth                   36864  0
xfrm_user              53248  1
xfrm_algo              16384  1 xfrm_user
xt_conntrack           16384  1
xt_comment             16384  33
nft_compat             20480  47
nf_tables             303104  156 nft_compat,nft_chain_nat
nfnetlink              20480  4 nft_compat,nf_tables,ip_set
iptable_filter         16384  0
iptable_nat            16384  0
nf_nat                 57344  4 xt_nat,nft_chain_nat,iptable_nat,xt_MASQUERADE
sunrpc                692224  1
nvme_fabrics           32768  0
binfmt_misc            24576  1
nls_ascii              16384  2
nls_cp437              20480  2
vfat                   24576  2
fat                    90112  1 vfat
intel_rapl_msr         20480  0
intel_rapl_common      32768  1 intel_rapl_msr
ipmi_ssif              45056  0
x86_pkg_temp_thermal    20480  0
intel_powerclamp       20480  0
kvm_intel             380928  0
kvm                  1142784  1 kvm_intel
irqbypass              16384  1 kvm
ghash_clmulni_intel    16384  0
sha512_ssse3           49152  0
sha512_generic         16384  1 sha512_ssse3
sha256_ssse3           32768  0
sha1_ssse3             32768  0
evdev                  28672  3
aesni_intel           393216  0
crypto_simd            16384  1 aesni_intel
cryptd                 28672  2 crypto_simd,ghash_clmulni_intel
iTCO_wdt               16384  0
rapl                   20480  0
ast                    61440  0
intel_cstate           20480  0
intel_pmc_bxt          16384  1 iTCO_wdt
cp210x                 36864  0
drm_vram_helper        20480  1 ast
iTCO_vendor_support    16384  1 iTCO_wdt
usbserial              65536  1 cp210x
watchdog               45056  1 iTCO_wdt
drm_ttm_helper         16384  2 drm_vram_helper,ast
mei_me                 53248  0
ttm                    94208  2 drm_vram_helper,drm_ttm_helper
intel_uncore          217088  0
drm_kms_helper        212992  4 drm_vram_helper,ast
ee1004                 20480  0
pcspkr                 16384  0
acpi_ipmi              20480  0
mei                   159744  1 mei_me
intel_pch_thermal      20480  0
ipmi_si                73728  1
ie31200_edac           16384  0
8021q                  40960  0
ipmi_devintf           20480  0
garp                   16384  1 8021q
mrp                    20480  1 8021q
ipmi_msghandler        77824  4 ipmi_devintf,ipmi_si,acpi_ipmi,ipmi_ssif
intel_pmc_core         53248  0
button                 24576  0
sg                     40960  0
xt_socket              16384  1
nf_socket_ipv4         16384  1 xt_socket
nf_socket_ipv6         20480  1 xt_socket
bonding               221184  0
usbip_host             40960  0
usbip_core             40960  1 usbip_host
tls                   135168  1 bonding
rbd                   122880  0
overlay               163840  67
nbd                    57344  0
nct6775                32768  0
nct6775_core           77824  1 nct6775
hwmon_vid              16384  1 nct6775
jc42                   16384  0
coretemp               20480  0
iptable_raw            16384  0
iptable_mangle         16384  0
ip_vs_rr               16384  1
ip_vs                 188416  3 ip_vs_rr
nf_conntrack          188416  6 xt_conntrack,nf_nat,xt_nat,xt_CT,xt_MASQUERADE,ip_vs
nf_defrag_ipv6         24576  4 nf_conntrack,xt_socket,xt_TPROXY,ip_vs
nf_defrag_ipv4         16384  3 nf_conntrack,xt_socket,xt_TPROXY
ceph                  507904  0
libceph               479232  2 ceph,rbd
libcrc32c              16384  5 nf_conntrack,nf_nat,nf_tables,libceph,ip_vs
crc32c_generic         16384  0
fscache               376832  1 ceph
netfs                  57344  2 ceph,fscache
br_netfilter           36864  0
bridge                311296  1 br_netfilter
stp                    16384  2 bridge,garp
llc                    16384  3 bridge,stp,garp
drm                   614400  6 drm_kms_helper,drm_vram_helper,ast,drm_ttm_helper,ttm
loop                   32768  0
fuse                  176128  1
dm_mod                184320  0
efi_pstore             16384  0
configfs               57344  1
efivarfs               24576  1
ip_tables              36864  4 iptable_filter,iptable_raw,iptable_nat,iptable_mangle
x_tables               61440  15 xt_conntrack,iptable_filter,nft_compat,xt_socket,xt_nat,xt_comment,xt_set,xt_TPROXY,xt_CT,iptable_raw,ip_tables,iptable_nat,xt_MASQUERADE,iptable_mangle,xt_mark
autofs4                53248  2
zfs                  5771264  23
spl                   135168  1 zfs
sd_mod                 65536  2
ahci                   49152  2
libahci                49152  1 ahci
xhci_pci               24576  0
libata                401408  2 libahci,ahci
xhci_hcd              319488  1 xhci_pci
nvme                   53248  9
nvme_core             163840  11 nvme,nvme_fabrics
crc32_pclmul           16384  0
t10_pi                 16384  2 sd_mod,nvme_core
crc32c_intel           24576  1
igb                   270336  0
usbcore               348160  5 usbserial,xhci_hcd,cp210x,xhci_pci,usbip_host
scsi_mod              286720  3 sd_mod,libata,sg
i2c_i801               36864  0
i2c_smbus              20480  1 i2c_i801
i2c_algo_bit           16384  2 igb,ast
crc64_rocksoft         20480  1 t10_pi
dca                    16384  1 igb
crc64                  20480  1 crc64_rocksoft
crc_t10dif             20480  1 t10_pi
crct10dif_generic      16384  0
crct10dif_pclmul       16384  1
scsi_common            16384  3 scsi_mod,libata,sg
usb_common             16384  3 xhci_hcd,usbip_core,usbcore
crct10dif_common       16384  3 crct10dif_generic,crc_t10dif,crct10dif_pclmul
fan                    20480  0
video                  65536  0
wmi                    36864  1 video
