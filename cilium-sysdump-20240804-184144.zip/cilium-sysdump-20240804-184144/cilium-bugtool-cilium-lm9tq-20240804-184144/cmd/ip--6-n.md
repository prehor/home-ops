fe80::1ca0:daf0:4c6:ca5c dev lan lladdr 1a:be:2c:18:49:c0 STALE
fe80::835:6b30:48c1:71be dev lan lladdr e8:78:65:07:1b:66 STALE
fe80::1cbe:765b:ecc6:54e8 dev lan lladdr 46:88:44:f1:49:f2 STALE
fe80::da58:d7ff:fe01:7116 dev lan lladdr d8:58:d7:01:71:16 router STALE
fe80::cc4:3836:a6f0:7f3a dev lan lladdr 46:a1:db:1d:c0:c3 STALE
fe80::14be:2831:2af8:4737 dev lan lladdr 58:d3:49:3a:c7:a5 router STALE
