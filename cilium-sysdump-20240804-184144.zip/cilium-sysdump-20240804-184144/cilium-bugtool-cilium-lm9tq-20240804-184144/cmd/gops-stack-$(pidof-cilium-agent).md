goroutine 204 [running]:
runtime/pprof.writeGoroutineStacks({0x7fa85f271880, 0xc0000b18c0})
	/usr/local/go/src/runtime/pprof/pprof.go:743 +0x6a
runtime/pprof.writeGoroutine({0x7fa85f271880?, 0xc0000b18c0?}, 0xb?)
	/usr/local/go/src/runtime/pprof/pprof.go:732 +0x25
runtime/pprof.(*Profile).WriteTo(0x68b4070?, {0x7fa85f271880?, 0xc0000b18c0?}, 0xc?)
	/usr/local/go/src/runtime/pprof/pprof.go:369 +0x14b
github.com/google/gops/agent.handle({0x7fa85f271048, 0xc0000b18c0}, {0xc001710000?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0x28b2
github.com/google/gops/agent.listen({0x44980d0, 0xc0008b2de0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1b4
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x36f

goroutine 1 [select, 39 minutes]:
github.com/cilium/hive.(*Hive).waitForSignalOrShutdown(0xc00019a5a0, 0xc0018383d0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:251 +0x179
github.com/cilium/hive.(*Hive).Run(0xc00019a5a0, 0xc0018383d0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:235 +0x12c
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0xc000798008, {0x3e0677f?, 0x4?, 0x3e065ef?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:40 +0x18a
github.com/spf13/cobra.(*Command).execute(0xc000798008, {0xc00014c010, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:989 +0xab1
github.com/spf13/cobra.(*Command).ExecuteC(0xc000798008)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1117 +0x3ff
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1041
github.com/cilium/cilium/daemon/cmd.Execute(0xc00019a5a0?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:80 +0x13
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x57

goroutine 385 [IO wait, 39 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99f5d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x1b?, 0x3d3b840?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002ad4a80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002ad4a80)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x1?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).AcceptUnix(0xc001b69080)
	/usr/local/go/src/net/unixsock.go:247 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:59 +0xaf
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:54 +0x125

goroutine 82 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008db9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 21576 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0023d2948, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x7?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0023d2930, {0xc0012a4db0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc0012a4db0?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc0023d2900}, {0xc0012a4db0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000893ef0, {0xc005558400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc005428640, 0x0, {0x448e718, 0xc0018ab340})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0009e52e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0016c5300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 465
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 87 [select, 39 minutes]:
io.(*pipe).read(0xc000d4aea0, {0xc001096253, 0xfdad, 0x4489268?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0x0?, {0xc001096253?, 0xc0007d9a40?, 0xc000d9f440?})
	/usr/local/go/src/io/pipe.go:134 +0x1a
bufio.(*Scanner).Scan(0xc004380f28)
	/usr/local/go/src/bufio/scan.go:219 +0x81e
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc00029a620, 0xc000d4aea0, 0xc001838350)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11d
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x31f

goroutine 88 [select, 39 minutes]:
io.(*pipe).read(0xc000d4af00, {0xc001366000, 0x10000, 0x0?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0xc0004e6608?, {0xc001366000?, 0x6ee2e40?, 0xc0004e6690?})
	/usr/local/go/src/io/pipe.go:134 +0x1a
bufio.(*Scanner).Scan(0xc0004e6728)
	/usr/local/go/src/bufio/scan.go:219 +0x81e
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc00029a620, 0xc000d4af00, 0xc001838370)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11d
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x31f

goroutine 89 [select, 39 minutes]:
io.(*pipe).read(0xc000d4af60, {0xc001380000, 0x10000, 0x0?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0xc0004e7e08?, {0xc001380000?, 0x6ee2e40?, 0xc0004e7e90?})
	/usr/local/go/src/io/pipe.go:134 +0x1a
bufio.(*Scanner).Scan(0xc0004e7f28)
	/usr/local/go/src/bufio/scan.go:219 +0x81e
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc00029a620, 0xc000d4af60, 0xc001838390)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11d
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x31f

goroutine 90 [select, 39 minutes]:
io.(*pipe).read(0xc000d4afc0, {0xc001656000, 0x10000, 0x0?})
	/usr/local/go/src/io/pipe.go:57 +0xa5
io.(*PipeReader).Read(0xc0004e1e08?, {0xc001656000?, 0x6ee2e40?, 0xc0004e1e90?})
	/usr/local/go/src/io/pipe.go:134 +0x1a
bufio.(*Scanner).Scan(0xc00046df28)
	/usr/local/go/src/bufio/scan.go:219 +0x81e
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc00029a620, 0xc000d4afc0, 0xc0018383b0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11d
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x31f

goroutine 91 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x58
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x90

goroutine 2051 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555a500, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc0007e01e0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2077
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 191 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001ceb900)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 193 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001cebae0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 194 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x9a
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:141 +0x67

goroutine 195 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001cebb80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 197 [sync.Cond.Wait, 38 minutes]:
sync.runtime_notifyListWait(0xc0007dc5d0, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc00046bf80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
github.com/cilium/cilium/pkg/policy/k8s.(*serviceQueue).dequeue(0xc00188b2c0, {0x44afc68, 0xc002281130})
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:361 +0xd3
github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:398 +0x170
created by github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:387 +0x165

goroutine 198 [chan receive, 39 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x129
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x34f

goroutine 1907 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e2d0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053ca280, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d789c0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2052 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555a640, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc0007e0e40, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2073
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2657 [IO wait, 38 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99f100, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc0066da600?, 0xc002ce6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0066da600, {0xc002ce6000, 0x580, 0x580})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0066da600, {0xc002ce6000?, 0x7fa85f52bd78?, 0xc000e411a0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00184a190, {0xc002ce6000?, 0xc002301850?, 0x411e9b?})
	/usr/local/go/src/net/net.go:185 +0x45
crypto/tls.(*atLeastReader).Read(0xc000e411a0, {0xc002ce6000?, 0x0?, 0xc000e411a0?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x3b
bytes.(*Buffer).ReadFrom(0xc007c50d30, {0x445df80, 0xc000e411a0})
	/usr/local/go/src/bytes/buffer.go:211 +0x98
crypto/tls.(*Conn).readFromUntil(0xc007c50a88, {0x4458400, 0xc00184a190}, 0xc002301898?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0xc007c50a88, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x3cf
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0xc007c50a88, {0xc007958000, 0x8000, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x156
bufio.(*Reader).Read(0xc006ed5f20, {0xc002159d20, 0x9, 0x412245?})
	/usr/local/go/src/bufio/bufio.go:241 +0x197
io.ReadAtLeast({0x4458720, 0xc006ed5f20}, {0xc002159d20, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc002159d20, 0x9, 0xc0007ebcd0?}, {0x4458720?, 0xc006ed5f20?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc002159ce0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x85
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc0023d2180, {0x44afc30, 0xc005bdfda0}, 0xc005bdfdd0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:644 +0x15e
google.golang.org/grpc.(*Server).serveStreams(0xc00221a800, {0x44afac0?, 0x6edd960?}, {0x44ceb00, 0xc0023d2180}, {0x44c69d8?, 0xc00184a190?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x3b6
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x56
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 2599
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1c6

goroutine 2349 [select]:
github.com/servak/go-fastping.(*Pinger).run(0xc000bfddd0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x5c9
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 2331
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x145

goroutine 2292 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fa85f8af510, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x4a?, 0x1?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002c3cd80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002c3cd80)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000e52300)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1e
net.(*TCPListener).Accept(0xc000e52300)
	/usr/local/go/src/net/tcpsock.go:327 +0x30
net/http.(*Server).Serve(0xc001447c20, {0x44980d0, 0xc000e52300})
	/usr/local/go/src/net/http/server.go:3260 +0x33e
net/http.(*Server).ListenAndServe(0xc001447c20)
	/usr/local/go/src/net/http/server.go:3189 +0x71
github.com/cilium/cilium/pkg/hubble/metrics.initMetricsServer.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/metrics/metrics.go:111 +0x365
created by github.com/cilium/cilium/pkg/hubble/metrics.initMetricsServer in goroutine 2231
	/go/src/github.com/cilium/cilium/pkg/hubble/metrics/metrics.go:93 +0x9c

goroutine 2294 [sync.Cond.Wait, 38 minutes]:
sync.runtime_notifyListWait(0xc0010d9290, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2d94d4b?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0029e2660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/hubble/metrics.initEndpointDeletionHandler.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/metrics/metrics.go:125 +0x7b
created by github.com/cilium/cilium/pkg/hubble/metrics.initEndpointDeletionHandler in goroutine 2231
	/go/src/github.com/cilium/cilium/pkg/hubble/metrics/metrics.go:123 +0x9e

goroutine 205 [IO wait, 39 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99fd98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x8?, 0x10?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001cc2000)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc001cc2000)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000964000)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1e
net.(*TCPListener).Accept(0xc000964000)
	/usr/local/go/src/net/tcpsock.go:327 +0x30
net/http.(*Server).Serve(0xc00019a2d0, {0x44980d0, 0xc000964000})
	/usr/local/go/src/net/http/server.go:3260 +0x33e
net/http.(*Server).ListenAndServe(0xc00019a2d0)
	/usr/local/go/src/net/http/server.go:3189 +0x71
github.com/cilium/cilium/pkg/metrics.NewRegistry.func1.1()
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:89 +0xa8
created by github.com/cilium/cilium/pkg/metrics.NewRegistry.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:87 +0xc5

goroutine 206 [select, 38 minutes]:
github.com/cilium/statedb.graveyardWorker(0xc001846e00, {0x44afc68, 0xc0022932c0}, 0x3b9aca00?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/graveyard.go:24 +0x16d
created by github.com/cilium/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/db.go:201 +0x13f

goroutine 52 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00027d7c0, {{{0x3e2567c, 0xd}}, {0x0, 0x0}, 0xc000a3c400, 0x0, 0x4044528, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 220 [chan receive, 39 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1642 +0x25
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1641 +0x14f

goroutine 227 [IO wait]:
internal/poll.runtime_pollWait(0x7fa85f99fca0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc001741a00?, 0xc0023c0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001741a00, {0xc0023c0000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc001741a00, {0xc0023c0000?, 0xc00031d400?, 0x2?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0013fe260, {0xc0023c0000?, 0xc0023c0005?, 0xa5?})
	/usr/local/go/src/net/net.go:185 +0x45
crypto/tls.(*atLeastReader).Read(0xc00886a540, {0xc0023c0000?, 0x0?, 0xc00886a540?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x3b
bytes.(*Buffer).ReadFrom(0xc001acb430, {0x445df80, 0xc00886a540})
	/usr/local/go/src/bytes/buffer.go:211 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001acb188, {0x7fa85f550168, 0xc0024727b0}, 0xc0022bd980?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xde
crypto/tls.(*Conn).readRecordOrCCS(0xc001acb188, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x3cf
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0xc001acb188, {0xc0022d0000, 0x1000, 0x1060b51?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x156
bufio.(*Reader).Read(0xc001e9bc80, {0xc0008df540, 0x9, 0x0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x197
io.ReadAtLeast({0x4458720, 0xc001e9bc80}, {0xc0008df540, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0x90
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0xc0008df540, 0x9, 0x22bddc0?}, {0x4458720?, 0xc001e9bc80?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x65
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0008df500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x85
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc0022bdfa8)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2358 +0xda
golang.org/x/net/http2.(*ClientConn).readLoop(0xc000d20d80)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2254 +0x8b
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 226
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:869 +0xd1b

goroutine 216 [chan receive, 1 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0xc001b3d040, {0x44afc68?, 0xc0008d83c0?}, 0xc001265dc0)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xae
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:134 +0x32
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:133 +0x3b1

goroutine 54 [select, 9 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x44e12e0, {0x44afc30, 0xc001624a20}, {0x44b7c80, 0xc002490000})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x38c
github.com/cilium/hive/job.(*jobOneShot).start(0xc001acc4e0, {0x44afc30, 0xc001624a20}, 0xc000233680?, {0x44b7c80, 0xc001acc120}, {{{0x0, 0x0, 0x0}}, 0xc000bb9d40, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1092 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1658
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1516 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a2f00, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0054d3d10, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 64 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc000e4afd0, 0x23)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00266c720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d7260, {0x44afc68, 0xc002662780}, 0xc001e99740, {0x44c77b8, 0xc002472b58})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 216
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1825 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc000e073c0}, {0x7fa85f8e38b8, 0xc005356c60}, {0x44f3ac8, 0x3d97620}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0008ffc00, {0x0?, 0x0?}, 0xc005510900, 0xc004dff7a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0008ffc00, 0xc005510900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0041eff50, {0x44671a0, 0xc004df2f50}, 0x1, 0xc005510900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0008ffc00, 0xc005510900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1707
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 928 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc002780840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 221 [syscall, 38 minutes]:
syscall.Syscall6(0x2d, 0x15, 0xc002931948, 0x10000, 0x0, 0xc002853730, 0xc0029318fc)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x39
golang.org/x/sys/unix.recvfrom(0x74?, {0xc002931948?, 0x0?, 0x0?}, 0x1900000074?, 0x0?, 0xc00617e110?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0x15, {0xc002931948, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x47?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x59
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1658 +0x9a
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1655 +0x35f

goroutine 1820 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437c140, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000eea240, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2072
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 318 [chan receive, 39 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0xc00230b130, {0x44afc68, 0xc00230b180})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x6e
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x13b

goroutine 338 [select]:
github.com/cilium/cilium/pkg/datapath/iptables.reconciliationLoop({0x44afc30, 0xc0017276b0}, {0x44ef230, 0xc001847a40}, {0x44b7c80, 0xc0027800c0}, 0x1, 0xc00019abe0, 0xc0027add60, 0xc0027add50, ...)
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/reconciler.go:163 +0x73f
github.com/cilium/cilium/pkg/datapath/iptables.newIptablesManager.func2({0x44afc30, 0xc0017276b0}, {0x44b7c80, 0xc0027800c0})
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/iptables.go:345 +0x145
github.com/cilium/hive/job.(*jobOneShot).start(0xc001acd140, {0x44afc30, 0xc0017276b0}, 0xc001b1f260?, {0x44b7c80, 0xc001acd0e0}, {{{0xc000f3f2c0, 0x1, 0x1}}, 0xc000dd5e30, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 320 [IO wait, 31 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99f9b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x19?, 0x7446cb4300000003?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002ad4900)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002ad4900)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x40acfe?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc001b68f00)
	/usr/local/go/src/net/unixsock.go:260 +0x30
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0xc000d7c4a0, {0x44afc68, 0xc001dfb5e0}, 0x2000)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xe2
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x165

goroutine 217 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0xc0013c94a0, 0xc001ce4a80, 0xc001ce4ba0, 0xc001ce4c00)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:356 +0x286
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0xc0013c94a0, {0x44afc68?, 0xc0023826e0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:248 +0x4ac
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0xc0013c94a0, {0x44afc68, 0xc0023826e0})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:183 +0x97
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:163 +0x145

goroutine 223 [syscall, 38 minutes]:
syscall.Syscall6(0x2d, 0x16, 0xc002951e98, 0x10000, 0x0, 0xc0076bf8f0, 0xc002951e4c)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x39
golang.org/x/sys/unix.recvfrom(0x27c?, {0xc002951e98?, 0x0?, 0x0?}, 0x110000027c?, 0x0?, 0xc005133190?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0x16, {0xc002951e98, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xc002961ef0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x59
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2435 +0x8c
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2432 +0x35f

goroutine 355 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002731180, {{{0x3e1c5d2, 0xb}}, {0x44b7c80, 0xc002732ea0}, 0xc000dd4980, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 930 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 219 [syscall, 7 minutes]:
syscall.Syscall6(0x2d, 0x14, 0xc002911d70, 0x10000, 0x0, 0xc007350930, 0xc002911d24)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x39
golang.org/x/sys/unix.recvfrom(0x50?, {0xc002911d70?, 0x0?, 0x0?}, 0x1400000050?, 0x0?, 0xc0059e2f10?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:527 +0x6f
golang.org/x/sys/unix.Recvfrom(0x14, {0xc002911d70, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x70
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0xc00569bcb0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x59
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:368 +0x94
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:365 +0x35f

goroutine 386 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:77 +0x2f
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x185

goroutine 62 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00266c720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 216
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1638 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1091
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 388 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002328fa0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 465 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc0016c5300}, {0x7fa85f8e38b8, 0xc0013c8dc0}, {0x44f3ac8, 0x3da8be0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0008dfdc0, {0x0?, 0x0?}, 0xc0022dd560, 0xc002d543c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0008dfdc0, 0xc0022dd560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0022e7f50, {0x44671a0, 0xc00282e140}, 0x1, 0xc0022dd560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0008dfdc0, 0xc0022dd560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 299
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 356 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x18f9440?, 0xc0023821e0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 218 [chan receive, 39 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:352 +0x25
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:351 +0x14f

goroutine 1700 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc004dfe1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1615
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 222 [chan receive, 39 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2419 +0x25
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2418 +0x14f

goroutine 389 [select, 7 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0xc001d9f7a0, {0x44afc30, 0xc001bf5860}, {0x44b7c80, 0xc00266c900})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:316 +0x3ca
github.com/cilium/hive/job.(*jobOneShot).start(0xc001e9a1e0, {0x44afc30, 0xc001bf5860}, 0xc000994160?, {0x44b7c80, 0xc001acde60}, {{{0x0, 0x0, 0x0}}, 0xc000bb9d40, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 224 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ecdc0, {{{0x3e2a2ce, 0xe}}, {0x0, 0x0}, 0xc00082ca40, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2450 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0052da140, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004dc70e0}, 0xc0007f0e90, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1969
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 632 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc000f439d0, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0013d2660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d72e0, {0x44afc68, 0xc002382b90}, 0xc0029f29c0, {0x44c7810, 0xc000a5b4b8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 450
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 633 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 450
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 993 [chan receive, 14 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:115 +0x145
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit in goroutine 940
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:110 +0x230

goroutine 304 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 299
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 268 [select, 1 minutes]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0xc001a3c900, {0x44afc68, 0xc00230b180})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:401 +0x45f
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x75
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 318
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x5c

goroutine 1546 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc004ec6188, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc000cf66a0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc004ec6160, 0xc0009374c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ceb5e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002cd9ee0, {0x4467180, 0xc001727830}, 0x1, 0xc004e93c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002cd9ee0, 0x3b9aca00, 0x0, 0x1, 0xc004e93c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ceb5e0, 0xc004e93c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0007d01a0, 0xc004e93c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1656
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 319 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0023283c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 80 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0008dfdc0, 0xc0022dd560, 0xc002786ae0, 0xc002d543c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 465
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 387 [IO wait, 39 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99f7c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x1c?, 0xc000117a10?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002ad4c00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002ad4c00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc0012a0d20?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc001b69290)
	/usr/local/go/src/net/unixsock.go:260 +0x30
google.golang.org/grpc.(*Server).Serve(0xc002abd200, {0x4498100, 0xc001b69290})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x49e
github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0xa5
created by github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x191

goroutine 1792 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001127dc0, 0xc004e93c80, 0xc0043c8180, 0xc00561a480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1718
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 233 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc000044918, 0x11)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc000e525a0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0000448f0, 0xc000df6280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc00228b5e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0022e3ee0, {0x4467180, 0xc0015e2900}, 0x1, 0xc0022dc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0022e3ee0, 0x3b9aca00, 0x0, 0x1, 0xc0022dc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc00228b5e0, 0xc0022dc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0008b33a0, 0xc0022dc1e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 55
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 234 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 55
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1091 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc002bb24f8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc00079ae40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002bb24d0, 0xc001975240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc00228a960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0050dbee0, {0x4467180, 0xc00543a870}, 0x1, 0xc004f333e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0050dbee0, 0x3b9aca00, 0x0, 0x1, 0xc004f333e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc00228a960, 0xc004f333e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000918640, 0xc004f333e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1658
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 236 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 233
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 69 [chan receive, 39 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x156
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 338
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x34f

goroutine 238 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 233
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1064 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0024ec7e0, 0xc00058ed20, 0xc00058f7a0, 0xc00270e240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 760
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 239 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc00180b9c0}, {0x7fa85f8e38b8, 0xc0000448f0}, {0x44f3ac8, 0x3da84a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0008df6c0, {0x0?, 0x0?}, 0xc0022dc1e0, 0xc0022dade0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0008df6c0, 0xc0022dc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0022ebf50, {0x44671a0, 0xc002293a90}, 0x1, 0xc0022dc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0008df6c0, 0xc0022dc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 233
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1056 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1006
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 290 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0008df6c0, 0xc0022dc1e0, 0xc0022dc660, 0xc0022dade0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 239
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 934 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc002780900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 622 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func3()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:140 +0x29d
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 939
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:127 +0x2ee

goroutine 931 [select, 14 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:86 +0xdd
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:84 +0x1dd

goroutine 302 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 299
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 634 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0013d28a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1555 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a37c0, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0052fb6d0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1558 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3b80, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc000a554a0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 321 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 216
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 63 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00266c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 216
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1527 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc002697a48, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc002362dd0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002697a20, 0xc0017b03c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc002499540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0027bdee0, {0x4467180, 0xc004df4060}, 0x1, 0xc004db3020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0027bdee0, 0x3b9aca00, 0x0, 0x1, 0xc004db3020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc002499540, 0xc004db3020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc001715720, 0xc004db3020)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1659
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1614 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewBGPCPResourceStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/resource_store.go:70 +0x1aa
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcec00, {0x44afc30, 0xc0054c0060}, 0xc002111fd0?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 665 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 662
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 357 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x4046fa8?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000df6e00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 358 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x44fd580)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa7

goroutine 5363 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc007d84a00, {{{0x3e33a7b, 0x10}}, {0x0, 0x0}, 0xc0014f64d0, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 931
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 19259 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc000846948, 0x9)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc00805b280?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc000846930, {0xc002034c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x88?}, {0xc002034c01?, 0xc0057b9ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc0066a5cc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0066a5cc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc0066a5cc0, {0x36a0480, 0xc007694fc0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc006ef05d0, {0xc007ade800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc006b778b0, 0x0, {0x448e718, 0xc0012b3080})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0013b5c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00805b2c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1533
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 362 [select, 9 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x44e1420, {0x44afc30, 0xc0016a54a0}, {0x44b7c80, 0xc002368780})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x391
github.com/cilium/hive/job.(*jobOneShot).start(0xc001acd980, {0x44afc30, 0xc0016a54a0}, 0x0?, {0x44b7c80, 0xc001acd6e0}, {{{0x0, 0x0, 0x0}}, 0xc000bb9d40, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 21575 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0023d2900, 0xc000e94480, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc0023d2900, 0x10791e5?, 0xc0010c6100?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 465
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 324 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 389
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 927 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc002780540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 621 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:101 +0x17a
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 939
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:95 +0x266

goroutine 323 [chan receive, 39 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x156
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 389
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x34f

goroutine 300 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 430
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 299 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0013c8de8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0009e46a0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0013c8dc0, 0xc000df6ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc00228b900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002302ee0, {0x4467180, 0xc001635a10}, 0x1, 0xc0022dd560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002302ee0, 0x3b9aca00, 0x0, 0x1, 0xc0022dd560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc00228b900, 0xc0022dd560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc00079b740, 0xc0022dd560)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 430
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 929 [sync.Cond.Wait, 14 minutes]:
sync.runtime_notifyListWait(0xc001765a10, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc002780540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d70e0, {0x44afc68, 0xc0020b5590}, 0xc001b1e3c0, {0x44c76b0, 0xc0023a2b58})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 2180 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0029f1e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1649
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 79 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x2c
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 320
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0xa5

goroutine 1908 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xffffffffffffffff?, 0xc0042a2ef8?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x44fe280?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1890 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc004720d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1651
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 2003 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004eec8c0, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001cd1d70, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2067
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 398 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x44fda60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa7

goroutine 428 [select]:
github.com/cilium/cilium/pkg/cgroups/manager.(*cgroupManager).processPodEvents(0xc001da5380)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:218 +0x91
created by github.com/cilium/cilium/pkg/cgroups/manager.newCGroupManager.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/cell.go:48 +0x56

goroutine 328 [select, 39 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xd0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 452
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xca

goroutine 1728 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1723
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 925 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).serviceEventLoop(0xc000dc3040, 0xc001d0c3f8, 0xc000ef5d70)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:111 +0x12f
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:95 +0x15e

goroutine 1004 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc00102b790, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001fc79e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6b60, {0x44afc68, 0xc002affcc0}, 0xc001d810e0, {0x44c6da0, 0xc00049de90})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1653
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1552 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc008b894c0}, {0x7fa85f8e38b8, 0xc004ec60b0}, {0x44f3ac8, 0x3dae680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001127960, {0x0?, 0x0?}, 0xc004e937a0, 0xc0051754a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001127960, 0xc004e937a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002a9ff50, {0x44671a0, 0xc002280c80}, 0x1, 0xc004e937a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001127960, 0xc004e937a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1543
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1618 [select, 5 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0xc002207340)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:903 +0x266
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 1595
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:895 +0x5a

goroutine 1533 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc00805b2c0}, {0x7fa85f8e38b8, 0xc002697a20}, {0x44f3ac8, 0x3d843c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0008ff5e0, {0x0?, 0x0?}, 0xc004db3020, 0xc004720e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0008ff5e0, 0xc004db3020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002a9df50, {0x44671a0, 0xc004df2190}, 0x1, 0xc004db3020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0008ff5e0, 0xc004db3020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1527
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1517 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3040, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0022814a0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1011 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0009945a8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0007fb5a0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000994580, 0xc00118b680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0023ac6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002c7fee0, {0x4467180, 0xc00101b4a0}, 0x1, 0xc001db0c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002c7fee0, 0x3b9aca00, 0x0, 0x1, 0xc001db0c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0023ac6e0, 0xc001db0c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0009bf3c0, 0xc001db0c00)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 359
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1012 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 359
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 2253 [select, 39 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x17c
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 2304
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x205

goroutine 954 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1011
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 23020 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc007cc47c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0013615c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc007cc47b0, {0xc004942c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x8d?}, {0xc004942c01?, 0xc00441bce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc005d99040)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc005d99040)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc005d99040, {0x36a0480, 0xc006f6f128})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc007caaab0, {0xc0022c4800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc005d93a90, 0x0, {0x448e718, 0xc008961d40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0014fa9a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0013616c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1639
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 24666 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0023d2d80, 0xc005159320, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc0023d2d80, 0x10791e5?, 0xc001203200?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 760
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 11764 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fa85f18b8d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc0074ea180?, 0xc004b10000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0074ea180, {0xc004b10000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0074ea180, {0xc004b10000?, 0xc0020cba98?, 0x4f0fa5?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0017d4060, {0xc004b10000?, 0x0?, 0xc00541c308?})
	/usr/local/go/src/net/net.go:185 +0x45
net/http.(*connReader).Read(0xc00541c300, {0xc004b10000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x14b
bufio.(*Reader).fill(0xc00746ff20)
	/usr/local/go/src/bufio/bufio.go:110 +0x103
bufio.(*Reader).Peek(0xc00746ff20, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x53
net/http.(*conn).serve(0xc0065df7a0, {0x44afc30, 0xc004cfff20})
	/usr/local/go/src/net/http/server.go:2079 +0x749
created by net/http.(*Server).Serve in goroutine 2351
	/usr/local/go/src/net/http/server.go:3290 +0x4b4

goroutine 1530 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1527
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1889 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc004720840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1651
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 437 [select]:
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0027b7b08, {0x4467180, 0xc000ecb560}, 0x1, 0xc0027491a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:238 +0x12c
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0027b7b08, 0x2540be400, 0x0, 0x1, 0xc0027491a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/leaderelection.(*LeaderElector).renew(0xc000d9f0e0, {0x44afc68?, 0xc002714730?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:271 +0x118
k8s.io/client-go/tools/leaderelection.(*LeaderElector).Run(0xc000d9f0e0, {0x44afc68, 0xc002714550})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:214 +0xfa
k8s.io/client-go/tools/leaderelection.RunOrDie({0x44afc68, 0xc002714550}, {{0x44be698, 0xc0001237a0}, 0x45d964b800, 0xdf8475800, 0x2540be400, {0xc0009d6bc0, 0xc0009d6bd0, 0x0}, ...})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:228 +0x85
github.com/cilium/cilium/pkg/l2announcer.(*selectedService).serviceLeaderElection(0xc00059a3f0, {0x44afc30?, 0xc000efe330?}, {0xc0027b7d78?, 0x49ef4f?})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:1103 +0x105
github.com/cilium/hive/job.(*jobOneShot).start(0xc001acc540, {0x44afc30, 0xc000efe330}, 0x0?, {0x44b7c80, 0xc001fce1e0}, {{{0xc00125d4e0, 0x1, 0x1}}, 0xc001a8ec90, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).add.func1 in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:207 +0x173

goroutine 672 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc002158460, 0xc0022ddaa0, 0xc0029e4120, 0xc002038300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 668 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc00160c380}, {0x7fa85f8e38b8, 0xc002bb2210}, {0x44f3ac8, 0x3dae680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc002158460, {0x0?, 0x0?}, 0xc0022ddaa0, 0xc002038300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc002158460, 0xc0022ddaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0041e7f50, {0x44671a0, 0xc00282f310}, 0x1, 0xc0022ddaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc002158460, 0xc0022ddaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 662
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 667 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 662
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 535 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc002d4e658, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc000e52580?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002d4e630, 0xc000f43240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc002783360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002797ee0, {0x4467180, 0xc000e4c120}, 0x1, 0xc0026c1320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002797ee0, 0x3b9aca00, 0x0, 0x1, 0xc0026c1320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc002783360, 0xc0026c1320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0009e4f40, 0xc0026c1320)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 449
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 462 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0026960d8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc000a3cc20?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0026960b0, 0xc000ff8040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0024980a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002757ee0, {0x4467180, 0xc000eca1b0}, 0x1, 0xc0027483c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002757ee0, 0x3b9aca00, 0x0, 0x1, 0xc0027483c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0024980a0, 0xc0027483c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000a3c2c0, 0xc0027483c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 298
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 436 [select]:
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0027b5b08, {0x4467180, 0xc000f46270}, 0x1, 0xc000114ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:238 +0x12c
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0027b5b08, 0x2540be400, 0x0, 0x1, 0xc000114ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/leaderelection.(*LeaderElector).renew(0xc00079c000, {0x44afc68?, 0xc002383220?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:271 +0x118
k8s.io/client-go/tools/leaderelection.(*LeaderElector).Run(0xc00079c000, {0x44afc68, 0xc000a12370})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:214 +0xfa
k8s.io/client-go/tools/leaderelection.RunOrDie({0x44afc68, 0xc000a12370}, {{0x44be698, 0xc000123320}, 0x45d964b800, 0xdf8475800, 0x2540be400, {0xc000ba60b0, 0xc000ba60c0, 0x0}, ...})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:228 +0x85
github.com/cilium/cilium/pkg/l2announcer.(*selectedService).serviceLeaderElection(0xc00059a380, {0x44afc30?, 0xc000efe2a0?}, {0xc0027b5d78?, 0x49ef4f?})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:1103 +0x105
github.com/cilium/hive/job.(*jobOneShot).start(0xc001acc060, {0x44afc30, 0xc000efe2a0}, 0x0?, {0x44b7c80, 0xc001fce1e0}, {{{0xc00125d4e0, 0x1, 0x1}}, 0xc001a8ec90, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).add.func1 in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:207 +0x173

goroutine 2554 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0044cc780, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004bbbf20}, 0xc000933670, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2308
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1556 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3900, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc002382550, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 463 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 298
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1636 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1091
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 536 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 449
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1576 [chan receive, 39 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0xf4
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1575
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x34f

goroutine 1075 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001fd62a0, 0xc0024a3980, 0xc001db1620, 0xc002d26d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 973
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 429 [select, 39 minutes]:
github.com/cilium/cilium/pkg/dial.newServiceResolver.func2({0x44afc30, 0xc001c85110}, {0x44b7c80, 0xc0024e8840})
	/go/src/github.com/cilium/cilium/pkg/dial/resolver.go:53 +0xa7
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fce0c0, {0x44afc30, 0xc001c85110}, 0xc002b9ffd0?, {0x44b7c80, 0xc001fce000}, {{{0xc00125c080, 0x1, 0x1}}, 0xc001971710, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 970 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 966
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 967 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 392
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1587 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e38c80, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc002382230, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 431 [IO wait, 39 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99f2f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc002b96780?, 0xc002c8fe3b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002b96780, {0xc002c8fe3b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc001484d30, {0xc002c8fe3b?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc001021e00)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xcf
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 432 [select, 39 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).loop(0xc001021ec0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:158 +0xd1
created by github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:152 +0x267

goroutine 22123 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000847800, 0xc006412b40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc000847800, 0x44afc30?, 0xc004cfff20?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 692
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 450 [select, 7 minutes]:
github.com/cilium/cilium/pkg/l2announcer.(*L2Announcer).run(0xc001edc5a0, {0x44afc30, 0xc001c85470}, {0xc0026c5d78?, 0x49ef4f?})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:175 +0x62f
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fce240, {0x44afc30, 0xc001c85470}, 0x0?, {0x44b7c80, 0xc001fce120}, {{{0xc00125d4e0, 0x1, 0x1}}, 0xc001a8ec90, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 451 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0xc001fce5a0, {0x44afc30, 0xc001c854d0}, 0x0?, {0x44b7c80, 0xc001fce120}, {{{0xc00125d4e0, 0x1, 0x1}}, 0xc001a8ec90, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x3b2
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 452 [chan receive, 39 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x44986c0, {0x44afc30, 0xc001c85590}, 0x0, {0x44b7c80?, 0xc001fce600}, {{{0xc0007fa220, 0x1, 0x1}}, 0xc001a8fa20, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x518
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 453 [chan receive, 39 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x4498680, {0x44afc30, 0xc001c855f0}, 0x0, {0x44b7c80?, 0xc001fce600}, {{{0xc0007fa220, 0x1, 0x1}}, 0xc001a8fa20, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x518
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 454 [select, 5 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0xc001fce900, {0x44afc30, 0xc001c85680}, 0x0?, {0x44b7c80, 0xc001fce600}, {{{0xc0007fa220, 0x1, 0x1}}, 0xc001a8fa20, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x3b2
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 455 [syscall, 39 minutes]:
syscall.Syscall6(0xe8, 0x1e, 0xc002ae1140, 0x8, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x39
golang.org/x/sys/unix.EpollWait(0xc0001480c0?, {0xc002ae1140?, 0xc00249ba70?, 0x4fdd91?}, 0xc0001480c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc000de2680, {0xc002ae1140, 0x8, 0x8}, {0x75fb98?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x26e
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc001bfb680, 0xc00249bbe0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2a8
github.com/cilium/ebpf/perf.(*Reader).Read(0xc000422af0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336 +0x45
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x82
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x118

goroutine 456 [select]:
github.com/cilium/cilium/daemon/cmd.(*syncHostIPs).loop(0xc001fcea20, {0x44afc30, 0xc001c85b60}, {0x44b7c80, 0xc0026ee960})
	/go/src/github.com/cilium/cilium/daemon/cmd/hostips-sync.go:109 +0x4a6
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcea80, {0x44afc30, 0xc001c85b60}, 0x0?, {0x44b7c80, 0xc001119da0}, {{{0x0, 0x0, 0x0}}, 0xc000bb9d40, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 459 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc1c2c0?, 0xc0010249c0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002bff798?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 460 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0023294a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 468 [select, 38 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).k8sServiceHandler(0xc000dc3040)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:190 +0x105
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:203 +0x4f

goroutine 469 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027821e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 470 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 471 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782320)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 472 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027823c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 473 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782460)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 474 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782500)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 475 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027825a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 476 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782640)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 477 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027826e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 478 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782780)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 479 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782820)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 480 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027828c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 497 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782960)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 498 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782a00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 499 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782aa0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 500 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782b40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 501 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782be0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 502 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782c80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 504 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782dc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 505 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782e60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 506 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002782f00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 20824 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc005389980, 0xc002a02d80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc005389980, 0x10791e5?, 0xc00911cf40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 508 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002783040)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 509 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027830e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 510 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002783180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 511 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002783220)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 512 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ecc80, {{{0x3e59b53, 0x19}}, {0x0, 0x0}, 0xc000e15d00, 0x0, 0x4044528, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 513 [IO wait, 39 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99f3e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x34?, 0xc002488978?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc00271ae00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc00271ae00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc0009e4b20)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1e
net.(*TCPListener).Accept(0xc0009e4b20)
	/usr/local/go/src/net/tcpsock.go:327 +0x30
github.com/cilium/dns.(*Server).serveTCP(0xc002848800, {0x44980d0, 0xc0009e4b20})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0x12c
github.com/cilium/dns.(*Server).ActivateAndServe(0xc002848800)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x25d
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc002848800)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x232
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x945

goroutine 514 [IO wait]:
internal/poll.runtime_pollWait(0x7fa85f99f4e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc00271ae80?, 0xc0001fa400?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0xc00271ae80, {0xc0001fa400, 0x200, 0x200}, {0xc0019b8b40, 0x2c, 0x2c}, 0x0, 0xc0023a4848)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x339
net.(*netFD).readMsgInet4(0xc00271ae80, {0xc0001fa400?, 0x41adb8?, 0x7fa85f8966c8?}, {0xc0019b8b40?, 0xc0023a4828?, 0x41164f?}, 0xc0023a4858?, 0x46047e?)
	/usr/local/go/src/net/fd_posix.go:84 +0x31
net.(*UDPConn).readMsg(0x10?, {0xc0001fa400?, 0xc0023a4900?, 0x41aae5?}, {0xc0019b8b40?, 0x48f8?, 0x2?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x170
net.(*UDPConn).ReadMsgUDPAddrPort(0xc001d10800, {0xc0001fa400?, 0x4862bd?, 0x411e9b?}, {0xc0019b8b40?, 0xc0023a49a8?, 0x4860a5?})
	/usr/local/go/src/net/udpsock.go:203 +0x3e
net.(*UDPConn).ReadMsgUDP(0xc000de0ed0?, {0xc0001fa400?, 0x0?, 0x0?}, {0xc0019b8b40?, 0xc0023a4a08?, 0x412245?})
	/usr/local/go/src/net/udpsock.go:191 +0x25
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc001d10800?, 0xc001d10800)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x58
github.com/cilium/dns.(*Server).readUDP(0xc002848900, 0xc001d10800, 0x77359400)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0xeb
github.com/cilium/dns.defaultReader.ReadUDP({0xc002848900?}, 0xc001d10800?, 0x77359400?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x13
github.com/cilium/dns.(*Server).serveUDP(0xc002848900, {0x44c20b0, 0xc001d10800})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x266
github.com/cilium/dns.(*Server).ActivateAndServe(0xc002848900)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x1ba
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc002848900)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x232
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x945

goroutine 1705 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1733
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 516 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0024e9680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 517 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0024e97a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 518 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d7260, {0x44afc68, 0xc00248fb80}, 0xc0026c0900, {0x44c77b8, 0xc002472b58})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:677 +0x60a
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 519 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 22710 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001cd8348, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc00194a280?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc001cd8330, {0xc007641801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x8f?}, {0xc007641801?, 0xc0024c7ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc0044368c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0044368c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc0044368c0, {0x36a0480, 0xc00729f1d0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc007cb8270, {0xc00729cc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0075819a0, 0x0, {0x448e718, 0xc007b72380})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0016c83a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00194a2c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 541
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 763 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0029e3320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 993
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 973 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc00137fb40}, {0x7fa85f8e38b8, 0xc000b376b0}, {0x44f3ac8, 0x3dc7560}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001fd62a0, {0x0?, 0x0?}, 0xc0024a3980, 0xc002d26d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001fd62a0, 0xc0024a3980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0023e3f50, {0x44671a0, 0xc002663360}, 0x1, 0xc0024a3980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001fd62a0, 0xc0024a3980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 966
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1005 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1653
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 972 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 966
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1780 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc004ec62e8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc002480000?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc004ec62c0, 0xc000937e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ceb720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002115ee0, {0x4467180, 0xc004ed4cc0}, 0x1, 0xc004ed8e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002115ee0, 0x3b9aca00, 0x0, 0x1, 0xc004ed8e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ceb720, 0xc004ed8e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000dd6480, 0xc004ed8e40)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1662
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 538 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 535
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 966 [sync.Cond.Wait, 38 minutes]:
sync.runtime_notifyListWait(0xc000b376d8, 0xb)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc001715940?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000b376b0, 0xc000e973c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc002664280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00222bee0, {0x4467180, 0xc001032060}, 0x1, 0xc0024a3980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc00222bee0, 0x3b9aca00, 0x0, 0x1, 0xc0024a3980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc002664280, 0xc0024a3980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000695a00, 0xc0024a3980)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 392
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 540 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 535
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 541 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc00194a2c0}, {0x7fa85f8e38b8, 0xc002d4e630}, {0x44f3ac8, 0x3d83b80}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc002168620, {0x0?, 0x0?}, 0xc0026c1320, 0xc0026efda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc002168620, 0xc0026c1320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002113f50, {0x44671a0, 0xc002382460}, 0x1, 0xc0026c1320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc002168620, 0xc0026c1320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 535
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 491 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc002168620, 0xc0026c1320, 0xc0022dc4e0, 0xc0026efda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 541
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1532 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1527
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 663 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 391
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 965 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 607
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 662 [sync.Cond.Wait, 38 minutes]:
sync.runtime_notifyListWait(0xc002bb2238, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc001715b60?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002bb2210, 0xc000df6f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc00228a640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0023e1ee0, {0x4467180, 0xc001635d40}, 0x1, 0xc0022ddaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0023e1ee0, 0x3b9aca00, 0x0, 0x1, 0xc0022ddaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc00228a640, 0xc0022ddaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000e52f00, 0xc0022ddaa0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 391
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 635 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0013d2a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 964 [sync.Cond.Wait, 38 minutes]:
sync.runtime_notifyListWait(0xc000e97250, 0x18)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00276dda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d7160, {0x44afc68, 0xc002663180}, 0xc0024a3320, {0x44c7708, 0xc0010ce378})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 607
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 963 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00276df20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 607
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 630 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0013d2660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 962 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00276dda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 607
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 994 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc002ae1ce0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x48
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 940
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x68

goroutine 623 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc002ae1620)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x48
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 939
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x68

goroutine 631 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0013d27e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 996 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001fc6120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 621
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1797 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001fd6fc0, 0xc004f333e0, 0xc004722f60, 0xc004720f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1639
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 2275 [chan receive, 39 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x156
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 2231
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x34f

goroutine 997 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001fc6240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 621
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 636 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc000f43dd0, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0013d28a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d73e0, {0x44afc68, 0xc002382c80}, 0xc0029f2fc0, {0x44c7e70, 0xc0008f78d8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 450
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 637 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 450
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 638 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0013d2a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 639 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0013d2c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 640 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc000f43f50, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0013d2a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d71e0, {0x44afc68, 0xc002382d70}, 0xc0029f3560, {0x44c7760, 0xc00217c060})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 450
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 673 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 450
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 689 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 462
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 607 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:212 +0x137
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1 in goroutine 932
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:210 +0xd9

goroutine 691 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 692 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc0088b19c0}, {0x7fa85f8e38b8, 0xc0026960b0}, {0x44f3ac8, 0x3d89ec0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc00214a000, {0x0?, 0x0?}, 0xc0027483c0, 0xc001ab0ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00214a000, 0xc0027483c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0027b9f50, {0x44671a0, 0xc0027141e0}, 0x1, 0xc0027483c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00214a000, 0xc0027483c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 695 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc00214a000, 0xc0027483c0, 0xc002748660, 0xc001ab0ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 692
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 911 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 925
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1948 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00031c280, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc002107080, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2085
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1715 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1546
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1559 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3cc0, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0053ebd10, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1547 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1656
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1906 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053ca140, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562eba0}, 0xc0002a6fc0, 0x0, 0xc005bdf3e0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1878 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1652
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 909 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc002adf5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 925
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 757 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 754
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 755 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1905 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc1c2c0?, 0xc000fd5c00?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc005ac9f98?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 908 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc002adf4a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 925
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1607 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:194 +0xee
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:192 +0x2d5

goroutine 912 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0026962e8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc00125d180?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0026962c0, 0xc000ff95c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0024986e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0028c1ee0, {0x4467180, 0xc00101ae40}, 0x1, 0xc001db0720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0028c1ee0, 0x3b9aca00, 0x0, 0x1, 0xc001db0720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0024986e0, 0xc001db0720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc001209240, 0xc001db0720)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 390
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1615 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x1da
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcecc0, {0x44afc30, 0xc0054c00c0}, 0xca6f25?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 2050 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555a280, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001fdfe00, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1999
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 759 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 754
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 910 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc000ff94d0, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc002adf4a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d72e0, {0x44afc68, 0xc0027156d0}, 0xc001db0360, {0x44c7810, 0xc00217d428})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 925
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 760 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc001587800}, {0x7fa85f8e38b8, 0xc002720210}, {0x44f3ac8, 0x3da8100}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0024ec7e0, {0x0?, 0x0?}, 0xc00058ed20, 0xc00270e240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0024ec7e0, 0xc00058ed20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0028edf50, {0x44671a0, 0xc000a13d10}, 0x1, 0xc00058ed20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0024ec7e0, 0xc00058ed20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 754
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1557 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3a40, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0022811d0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 945 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 390
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1741 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001127960, 0xc004e937a0, 0xc0054dac00, 0xc0051754a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1552
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1551 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1543
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 2008 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004eecf00, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0043e99a0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2070
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2296 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004bdedc0, {{{0x3e18686, 0xa}}, {0x0, 0x0}, 0x4045058, 0x0, 0x4044528, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2231
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 754 [sync.Cond.Wait, 14 minutes]:
sync.runtime_notifyListWait(0xc002720238, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc001510780?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002720210, 0xc0010d8780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc002710460)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002cd3ee0, {0x4467180, 0xc000f459b0}, 0x1, 0xc00058ed20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002cd3ee0, 0x3b9aca00, 0x0, 0x1, 0xc00058ed20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc002710460, 0xc00058ed20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0009d8c40, 0xc00058ed20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 948 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 912
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1795 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0008ff5e0, 0xc004db3020, 0xc004722ba0, 0xc004720e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1533
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 950 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 912
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 935 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc002780a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 936 [sync.Cond.Wait, 38 minutes]:
sync.runtime_notifyListWait(0xc0011663d0, 0xb)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc002780900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6e60, {0x44afc68, 0xc0020b56d0}, 0xc001b1e720, {0x44c74f8, 0xc000a5bd28})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 937 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 938 [select, 38 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:88 +0xef
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:86 +0x1f0

goroutine 939 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit(0xc001ea8480, {0x44afc68, 0xc000a54fa0}, 0xc001d0c410)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:146 +0x356
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:344 +0x365

goroutine 940 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit(0xc001ea8d80, {0x44afc68, 0xc000a54fa0}, 0xc001d0c410)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:134 +0x298
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:82 +0x119

goroutine 951 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc007af1ec0}, {0x7fa85f8e38b8, 0xc0026962c0}, {0x44f3ac8, 0x3da8be0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc00214ad20, {0x0?, 0x0?}, 0xc001db0720, 0xc002ae3020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00214ad20, 0xc001db0720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002d3df50, {0x44671a0, 0xc002715860}, 0x1, 0xc001db0720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00214ad20, 0xc001db0720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 912
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1549 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1543
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 942 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc000da1998, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc002480000?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000da1970, 0xc001166640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001188be0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002769f28, {0x4467180, 0xc0010265a0}, 0x1, 0xc001e99ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002769f28, 0x3b9aca00, 0x0, 0x1, 0xc001e99ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001188be0, 0xc001e99ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc0007fa040, 0xc001e99ec0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumLRPWatcher).ciliumLocalRedirectPolicyInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_local_redirect_policy.go:110 +0x425

goroutine 1840 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e1e0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053ca000, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d78780, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 944 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 942
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1050 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc00214ad20, 0xc001db0720, 0xc000c435c0, 0xc002ae3020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 951
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 977 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc00145f840}, {0x7fa85f8e38b8, 0xc000da1970}, {0x44f3ac8, 0x3d82840}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001127180, {0x0?, 0x0?}, 0xc001e99ec0, 0xc002d26660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001127180, 0xc001e99ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002d2bf50, {0x44671a0, 0xc0020b5770}, 0x1, 0xc001e99ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001127180, 0xc001e99ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 942
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 960 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001127180, 0xc001e99ec0, 0xc001db0f00, 0xc002d26660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 977
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 998 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc00102aad0, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001fc6120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d71e0, {0x44afc68, 0xc002aff6d0}, 0xc002ae1e00, {0x44c7760, 0xc00238a258})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 621
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 999 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 621
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1007 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1661
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 2005 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004eecb40, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc0008c6360, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2079
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 764 [sync.Cond.Wait, 14 minutes]:
sync.runtime_notifyListWait(0xc0010d8950, 0x60)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0029e2c60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6de0, {0x44afc68, 0xc000a13e00}, 0xc00058f0e0, {0x44c74a0, 0xc0023a2c60})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 993
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 765 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 993
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 956 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1011
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 957 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc0017e7c80}, {0x7fa85f8e38b8, 0xc000994580}, {0x44f3ac8, 0x3d89ec0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc00214b0a0, {0x0?, 0x0?}, 0xc001db0c00, 0xc002780de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00214b0a0, 0xc001db0c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002d2ff50, {0x44671a0, 0xc002715950}, 0x1, 0xc001db0c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00214b0a0, 0xc001db0c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1011
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 767 [sync.Cond.Wait, 14 minutes]:
sync.runtime_notifyListWait(0xc0027202e8, 0x30)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc001506c80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0027202c0, 0xc0010d8a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc002710500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0046a7ee0, {0x4467180, 0xc0011720c0}, 0x1, 0xc00058f3e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002768ee0, 0x3b9aca00, 0x0, 0x1, 0xc00058f3e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc002710500, 0xc00058f3e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0009d9040, 0xc00058f3e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 360
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 768 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 360
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1058 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 767
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1006 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0013c8e98, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0003711e0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0013c8e70, 0xc00102b900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc002328500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc002d19ee0, {0x4467180, 0xc0017196b0}, 0x1, 0xc000c43f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc002d19ee0, 0x3b9aca00, 0x0, 0x1, 0xc000c43f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc002328500, 0xc000c43f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000de39c0, 0xc000c43f20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1661
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1060 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 767
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 981 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc00214b0a0, 0xc001db0c00, 0xc0029d5440, 0xc002780de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 957
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1061 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc006c54680}, {0x7fa85f8e38b8, 0xc0027202c0}, {0x44f3ac8, 0x3d81d40}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0024ecee0, {0x0?, 0x0?}, 0xc00058f3e0, 0xc004786660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0024ecee0, 0xc00058f3e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00441df50, {0x44671a0, 0xc000da62d0}, 0x1, 0xc00058f3e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0024ecee0, 0xc00058f3e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 767
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1016 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0024ecee0, 0xc00058f3e0, 0xc001ce5a40, 0xc004786660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1061
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1002 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc001fc79e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1653
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 20809 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000847e00, 0xc004ee5c20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc000847e00, 0x44afc30?, 0xc005396ea0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 957
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 1003 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001fc7b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1653
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1014 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004c4000, {{{0x3e49499, 0x15}}, {0x0, 0x0}, 0xc000cf3ce0, 0x0, 0x4044528, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 938
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22941 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0081e3c80, 0xc005847440, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc0081e3c80, 0x10791e5?, 0xc000749680?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 951
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 20823 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc005389848, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x3?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc005389830, {0xc0018b77a8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc0018b77a8?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc005389800}, {0xc0018b77a8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00877a828, {0xc002aba000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00832d950, 0x0, {0x448e718, 0xc008104500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000c3a500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00137fb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 973
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 20825 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0053899c8, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xd?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0053899b0, {0xc007163508, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc007163508?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc005389980}, {0xc007163508, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00877aaf8, {0xc002aba800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc008bd5950, 0x0, {0x448e718, 0xc008656680})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000c3aaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00160c380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 1777 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc007f2e140}, {0x7fa85f8e38b8, 0xc004ec6210}, {0x44f3ac8, 0x3d8eca0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000ede380, {0x0?, 0x0?}, 0xc004ed8960, 0xc004dff6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000ede380, 0xc004ed8960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc004825f50, {0x44671a0, 0xc002281630}, 0x1, 0xc004ed8960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000ede380, 0xc004ed8960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1723
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1712 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1707
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 19748 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0081e2c48, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc006c54640?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0081e2c30, {0xc0056f6c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x7d?}, {0xc0056f6c01?, 0xc004207ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc005c3a500)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc005c3a500)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc005c3a500, {0x36a0480, 0xc00836bbd8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0070a4ff0, {0xc000c0c400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc005c32eb0, 0x0, {0x448e718, 0xc001b0b140})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00135d060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc006c54680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1061
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 1586 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e38b40, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc00248ec30, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2053 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555a780, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc0007e10e0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2074
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1708 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 395
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1585 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e38a00, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc002382eb0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1568 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e388c0, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0053eba40, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1831 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000ede380, 0xc004ed8960, 0xc0055111a0, 0xc004dff6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1777
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1567 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e38780, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc000a12640, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1566 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e38640, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc00248f7c0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1707 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc005356c88, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc002362dd0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc005356c60, 0xc000748440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0023ad9a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0046a5ee0, {0x4467180, 0xc004df51a0}, 0x1, 0xc005510900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0046a5ee0, 0x3b9aca00, 0x0, 0x1, 0xc005510900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0023ad9a0, 0xc005510900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000c06520, 0xc005510900)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 395
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1710 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1707
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1565 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e38500, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0053eb770, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1703 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1615
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1702 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0017b0510, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc004dfe1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d72e0, {0x44afc68, 0xc004df2960}, 0xc0055101e0, {0x44c7810, 0xc000a5b4b8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1615
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1528 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1659
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1718 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc001306d00}, {0x7fa85f8e38b8, 0xc004ec6160}, {0x44f3ac8, 0x3da8840}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001127dc0, {0x0?, 0x0?}, 0xc004e93c80, 0xc00561a480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001127dc0, 0xc004e93c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc004d1bf50, {0x44671a0, 0xc002280f00}, 0x1, 0xc004e93c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001127dc0, 0xc004e93c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1546
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1701 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc004dfe300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1615
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1564 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e383c0, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc000a54f00, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1562 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e38140, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc00248fd60, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1563 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004e38280, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0053eb4a0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1519 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a32c0, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc000a545f0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1781 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1662
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1560 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3e00, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc0023828c0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1639 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc0013616c0}, {0x7fa85f8e38b8, 0xc002bb24d0}, {0x44f3ac8, 0x3d838c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001fd6fc0, {0x0?, 0x0?}, 0xc004f333e0, 0xc004720f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001fd6fc0, 0xc004f333e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc004d1ff50, {0x44671a0, 0xc0052fb040}, 0x1, 0xc004f333e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001fd6fc0, 0xc004f333e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1091
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 2004 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004eeca00, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001cd1ef0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2066
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1723 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc004ec6238, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc002480000?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc004ec6210, 0xc000937a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ceb680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc004b2bee0, {0x4467180, 0xc004ed4810}, 0x1, 0xc004ed8960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc004b2bee0, 0x3b9aca00, 0x0, 0x1, 0xc004ed8960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ceb680, 0xc004ed8960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0007d0d40, 0xc004ed8960)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 396
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1626 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc005356bd8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc002704000?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc005356bb0, 0xc000748300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0023ad900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0046a9ee0, {0x4467180, 0xc005397050}, 0x1, 0xc0053c0600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0046a9ee0, 0x3b9aca00, 0x0, 0x1, 0xc0053c0600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0023ad900, 0xc0053c0600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0008b3d60, 0xc0053c0600)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1660
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1621 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0051acc00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1654
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1554 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3680, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc00248ef50, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1650 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewBGPCPResourceStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/resource_store.go:70 +0x1aa
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fceea0, {0x44afc30, 0xc0054c01e0}, 0xc004b2ffd0?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1518 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3180, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc00278a500, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1726 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1723
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1717 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1546
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1611 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0x11a
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0xb1

goroutine 1515 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a2dc0, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc00278a820, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1553 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3540, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc000a54140, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2179 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0029f16e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1649
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1520 [select, 38 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a3400, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc000a54a00, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1724 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 396
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1588 [chan receive, 39 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x156
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x34f

goroutine 1589 [select, 39 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:281 +0x1d5
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:271 +0x18a

goroutine 2021 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004c4640, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001ca77d0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2083
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1616 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x1da
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fced80, {0x44afc30, 0xc0054c0120}, 0xc004e57fd0?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1649 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewBGPCPResourceStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/resource_store.go:70 +0x1aa
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcede0, {0x44afc30, 0xc0054c0180}, 0xc0050d7fd0?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1544 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1657
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1594 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0xc000994d38, 0xf)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc001836200?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000994d10, 0xc000d5d340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0023ad5e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc004e79e20, {0x4467180, 0xc001b42f90}, 0x1, 0xc004e518c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0042a5e20, 0x3b9aca00, 0x0, 0x1, 0xc004e518c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0023ad5e0, 0xc004e518c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0xc00014d9a0, 0xc004e518c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0x9e
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0xc001b42ba0, {0x0?, 0xc002b827d0?}, {0x44a0d50, 0xc0022073f8}, 0xc004e518c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x534
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x48
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 1608
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x10f

goroutine 1543 [sync.Cond.Wait, 38 minutes]:
sync.runtime_notifyListWait(0xc004ec60d8, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc001d0a6c0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc004ec60b0, 0xc000937480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ceb540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc004e7bee0, {0x4467180, 0xc0017272f0}, 0x1, 0xc004e937a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc004e7bee0, 0x3b9aca00, 0x0, 0x1, 0xc004e937a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ceb540, 0xc004e937a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc0007d0180, 0xc004e937a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1657
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 23402 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0023d2000, 0xc0081d50e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc0023d2000, 0xc0010354c0?, 0xc0010354d0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1599
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 1598 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1594
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1599 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc008bb4100}, {0x7fa85f8e38b8, 0xc000994d10}, {0x44f3ac8, 0x3d82000}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f46a80, {0x0?, 0x0?}, 0xc004e518c0, 0xc004bf7e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f46a80, 0xc004e518c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc004e59f50, {0x44671a0, 0xc001dfbb80}, 0x1, 0xc004e518c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f46a80, 0xc004e518c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1594
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1609 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f46a80, 0xc004e518c0, 0xc004bf91a0, 0xc004bf7e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1599
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1622 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0051acd20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1654
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1651 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewBGPCPResourceStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/resource_store.go:70 +0x1aa
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcef00, {0x44afc30, 0xc0054c0240}, 0xca6f25?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1652 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewBGPCPResourceStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/resource_store.go:70 +0x1aa
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcefc0, {0x44afc30, 0xc0054c02a0}, 0xc0027e3fa8?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1653 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/bgpv1/agent.NewController.func1({0x44afc30?, 0xc0054c0300?}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/agent/controller.go:131 +0xa5
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcf020, {0x44afc30, 0xc0054c0300}, 0xc002752fd0?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1654 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/bgpv1/agent.NewController.func2({0x44afc30?, 0xc0054c0360?}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/agent/controller.go:143 +0xa5
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcf080, {0x44afc30, 0xc0054c0360}, 0xca6f25?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1655 [select, 38 minutes]:
github.com/cilium/cilium/pkg/bgpv1/agent.(*Controller).Run(0xc001fdc770, {0x44afc30, 0xc0054c03c0})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/agent/controller.go:196 +0x1bc
github.com/cilium/cilium/pkg/bgpv1/agent.NewController.func3({0x44afc30, 0xc0054c03c0}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/agent/controller.go:168 +0x105
github.com/cilium/hive/job.(*jobOneShot).start(0xc001fcf0e0, {0x44afc30, 0xc0054c03c0}, 0xc002b9e7d0?, {0x44b7c80, 0xc001fceb40}, {{{0xc0005df9a0, 0x1, 0x1}}, 0xc0019acab0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1875 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc00561ac00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1652
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 2022 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004c4dc0, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001ca7950, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2071
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2093 [select, 3 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:189 +0x4cb
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:104 +0xa5

goroutine 1861 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc004dfe7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1650
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 2020 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004c43c0, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001ca7440, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2082
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1891 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc000bc2490, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc004720840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6860, {0x44afc68, 0xc004df2370}, 0xc005510360, {0x44c6b90, 0xc001089e18})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1651
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1877 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0010147d0, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00561ac00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6960, {0x44afc68, 0xc0043e8690}, 0xc0043c9440, {0x44c6c40, 0xc00123d098})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1652
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1623 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc000748090, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0051acc00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d71e0, {0x44afc68, 0xc00230aaa0}, 0xc0053c0300, {0x44c7760, 0xc00217c060})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1654
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1624 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1654
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 2181 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc001167bd0, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0029f16e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6a60, {0x44afc68, 0xc000a55a90}, 0xc004a495c0, {0x44c6cf0, 0xc000720a20})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1649
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1663 [IO wait]:
internal/poll.runtime_pollWait(0x7fa85f99f1f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x17?, 0x10?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc004bf1580)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc004bf1580)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc00284de00?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc0054c06f0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
net/http.(*Server).Serve(0xc0051683c0, {0x4498100, 0xc0054c06f0})
	/usr/local/go/src/net/http/server.go:3260 +0x33e
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x4498100?, 0xc0054c06f0?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:467 +0x78
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:465 +0x4d4

goroutine 1666 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004bf5a40, {{{0x3e4406e, 0x14}}, {0x44b7c80, 0xc005174480}, 0xc00219bd10, 0x0, 0x4044528, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1667 [select, 9 minutes]:
github.com/cilium/cilium/pkg/service.serviceReconciler.reconcileLoop({{{}}, {0x44afe60, 0xc00087c660}, {0x445cec0, 0xc000f75040}, {0x44b7c80, 0xc001ab0de0}, 0xc001846e00, {0x44e95c0, 0xc001e94070}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/service/reconciler.go:104 +0x7dc
github.com/cilium/hive/job.(*jobOneShot).start(0xc001ab0f00, {0x44afc30, 0xc0054c0ab0}, 0x0?, {0x44b7c80, 0xc001ab0de0}, {{{0x0, 0x0, 0x0}}, 0xc000bb9d40, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 24667 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0023d2dc8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc004bdb200?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0023d2db0, {0xc001d0c7b8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc001d0c7b8?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc0023d2d80}, {0xc001d0c7b8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc00013e090, {0xc006c31800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc004673b30, 0x0, {0x448e718, 0xc0015878c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0013faba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001587800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 760
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 1668 [select, 5 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0xc001ab0fc0, {0x44afc30, 0xc0054c0b70}, 0x0?, {0x44b7c80, 0xc001ab0f60}, {{{0xc00087cfe0, 0x1, 0x1}}, 0xc0007e8540, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x3b2
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1669 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x44fd8c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa7

goroutine 1670 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x44fd720)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xdf
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa7

goroutine 1686 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0043c4600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1682 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1006
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1672 [select, 38 minutes]:
github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:68 +0x2ee
created by github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:57 +0x74

goroutine 1945 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00031c000, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc002106390, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1997
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1683 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc0013e25c0}, {0x7fa85f8e38b8, 0xc0013c8e70}, {0x44f3ac8, 0x3d87800}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0021695e0, {0x0?, 0x0?}, 0xc000c43f20, 0xc004edd740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0021695e0, 0xc000c43f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc005615f50, {0x44671a0, 0xc0008abb80}, 0x1, 0xc000c43f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0021695e0, 0xc000c43f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1006
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1675 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x93
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x127

goroutine 1676 [select, 7 minutes]:
github.com/cilium/cilium/daemon/cmd.(*deviceReloader).reload(0xc00228a780, {0x44afc30, 0xc0054c0fc0})
	/go/src/github.com/cilium/cilium/daemon/cmd/device-reloader.go:84 +0xba
github.com/cilium/hive/job.(*jobTimer).start(0xc0051745a0, {0x44afc30, 0xc0054c0fc0}, 0x0?, {0x44b7c80, 0xc001ab1500}, {{{0x0, 0x0, 0x0}}, 0xc000bb9d40, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:131 +0x448
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1789 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0021695e0, 0xc000c43f20, 0xc004ed9200, 0xc004edd740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1683
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 23019 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc007cc4780, 0xc0064127e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc007cc4780, 0x44afc30?, 0xc004cfff20?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1639
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 1627 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1660
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 2036 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478c280, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001e71320, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2072
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1629 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1626
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 2018 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004c4140, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001ca6d20, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1998
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1631 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1626
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 22748 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc005152ac8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0013e2580?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc005152ab0, {0xc007640c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x8b?}, {0xc007640c01?, 0xc008679ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc005a63900)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc005a63900)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc005a63900, {0x36a0480, 0xc00886a558})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00889f290, {0xc006c30800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0067c57c0, 0x0, {0x448e718, 0xc0019db100})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011e0c40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0013e25c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1683
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 24756 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000846dc8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc000d20eb8?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc000846db0, {0xc002457200, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002457200?, 0xc006035ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc00438ec80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc00438ec80)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc00438ec80, {0x36a0480, 0xc008b13ae8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc004a7e0c0, {0xc0022c5800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0051eab40, 0x0, {0x448e718, 0xc000e20200})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000e53180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000e201c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1786
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 1680 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0xc005174660, {0x44afc30, 0xc0054c12f0}, 0x0?, {0x44b7c80, 0xc001ab1860}, {{{0xc000b6bb20, 0x1, 0x1}}, 0xc0009c1750, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x3b2
created by github.com/cilium/hive/job.(*group).add.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:207 +0x173

goroutine 1632 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc006c54fc0}, {0x7fa85f8e38b8, 0xc005356bb0}, {0x44f3ac8, 0x3d84680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f47180, {0x0?, 0x0?}, 0xc0053c0600, 0xc005174960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f47180, 0xc0053c0600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0054f5f50, {0x44671a0, 0xc00230ad70}, 0x1, 0xc0053c0600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f47180, 0xc0053c0600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1626
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1729 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0xc001ab1c20, {0x44afc30, 0xc0054c13b0}, 0x0?, {0x44b7c80, 0xc001ab1b60}, {{{0xc00014cbc0, 0x1, 0x1}}, 0xc0009e0470, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x3b2
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1736 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f47180, 0xc0053c0600, 0xc0054da360, 0xc005174960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1632
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1730 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004bf5b80, {{{0x3e191da, 0xa}}, {0x0, 0x0}, 0xc0007d7b80, 0x0, 0x4044528, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1731 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0xc001ab1ce0, {0x44afc30, 0xc0054c1500}, 0x0?, {0x44b7c80, 0xc001ab1c80}, {{{0x0, 0x0, 0x0}}, 0xc0009e1710, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x3b2
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1732 [select, 5 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0xc001740580, {0x44afc30, 0xc0054c1680}, {0x449aa90, 0xc004724000}, 0xc004720360)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:166 +0x292
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0xc001740580, {0x44afc30, 0xc0054c1680}, {0xc00552fd78?, 0x49ef4f?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:106 +0x36e
github.com/cilium/hive/job.(*jobOneShot).start(0xc001118000, {0x44afc30, 0xc0054c1680}, 0x0?, {0x44b7c80, 0xc0002765a0}, {{{0xc000072a20, 0x1, 0x1}}, 0xc0009e83f0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 1733 [select]:
golang.org/x/sync/semaphore.(*Weighted).Acquire(0xc004df2d20, {0x44afc30, 0xc0054c1740}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/semaphore/semaphore.go:74 +0x334
github.com/cilium/cilium/pkg/rate.(*Limiter).WaitN(0xc000d687c0, {0x44afc30, 0xc0054c1740}, 0x1)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:104 +0x6f
github.com/cilium/cilium/pkg/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:91
github.com/cilium/cilium/pkg/hive/health.publishJob({0x44afc30, 0xc0054c1740}, {{{}}, 0xc001846e00, {0x44e9688, 0xc001846e70}, {0x44b1190, 0xc00226de60}, 0xc000c05af0}, 0xc000d69340)
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:85 +0x2ff
github.com/cilium/cilium/pkg/hive/health.metricPublisher.func2({0x44afc30?, 0xc0054c1740?}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:59 +0x39
github.com/cilium/hive/job.(*jobOneShot).start(0xc001118ea0, {0x44afc30, 0xc0054c1740}, 0x0?, {0x44b7c80, 0xc001118e40}, {{{0xc0008b2c60, 0x1, 0x1}}, 0xc000b99230, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x531
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x174

goroutine 22894 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc007cc41c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc006c54f80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc007cc41b0, {0xc005994601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x8b?}, {0xc005994601?, 0xc008677ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc005c3ac80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc005c3ac80)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc005c3ac80, {0x36a0480, 0xc008389cf8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0074ce0f0, {0xc005558c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0053dfae0, 0x0, {0x448e718, 0xc008272880})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000073580)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc006c54fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1632
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 1687 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0043c4780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1688 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0018e0e10, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0043c4600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d7060, {0x44afc68, 0xc0008abcc0}, 0xc0043c8300, {0x44c7658, 0xc00171a318})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1689 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1735 [syscall, 39 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x29
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x13
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x1f

goroutine 1690 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0043c4840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1691 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0043c49c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1692 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0018e1290, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0043c4840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6fe0, {0x44afc68, 0xc0008abe00}, 0xc0043c83c0, {0x44c7600, 0xc001c7c450})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1693 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1694 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0043c4a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1695 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0043c4c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1696 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0018e1690, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0043c4a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6f60, {0x44afc68, 0xc0008abef0}, 0xc0043c8480, {0x44c75a8, 0xc00123cf78})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1761 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1762 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0043c4cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 1763 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0043c4e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1764 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc0018e1b50, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0043c4cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6ee0, {0x44afc68, 0xc0043e80a0}, 0xc0043c8540, {0x44c7550, 0xc00171a240})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 1765 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1770 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1767
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1767 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc002d4faf8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0003711e0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002d4fad0, 0xc0018e1cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001df9540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0043d2ee0, {0x4467180, 0xc0043e4630}, 0x1, 0xc0043c8840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0043d2ee0, 0x3b9aca00, 0x0, 0x1, 0xc0043c8840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001df9540, 0xc0043c8840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000d7c000, 0xc0043c8840)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 397
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1768 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 397
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1776 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc002d4fba8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0003711e0?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc002d4fb80, 0xc0018e1e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x236
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001df95e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x30
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0043fdee0, {0x4467180, 0xc0043e4ae0}, 0x1, 0xc0043c8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0043fdee0, 0x3b9aca00, 0x0, 0x1, 0xc0043c8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x7f
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001df95e0, 0xc0043c8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x35e
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0xc000964040, 0xc0043c8cc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0x9e
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xbb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x2c5

goroutine 1772 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1767
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1811 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1776
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1773 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc00869d780}, {0x7fa85f8e38b8, 0xc002d4fad0}, {0x44f3ac8, 0x3d7e0e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001044700, {0x0?, 0x0?}, 0xc0043c8840, 0xc005174a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001044700, 0xc0043c8840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc004751f50, {0x44671a0, 0xc0043e8230}, 0x1, 0xc0043c8840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001044700, 0xc0043c8840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1767
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1738 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001044700, 0xc0043c8840, 0xc0054da720, 0xc005174a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1773
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1876 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00561ad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1652
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 1783 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1780
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1822 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437c280, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000eea360, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1999
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1785 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1780
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1786 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc000e201c0}, {0x7fa85f8e38b8, 0xc004ec62c0}, {0x44f3ac8, 0x3d84940}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000ede7e0, {0x0?, 0x0?}, 0xc004ed8e40, 0xc0053ec420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000ede7e0, 0xc004ed8e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0043f9f50, {0x44671a0, 0xc0022817c0}, 0x1, 0xc004ed8e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000ede7e0, 0xc004ed8e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1780
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 2054 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555a8c0, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc0007e1350, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2075
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1809 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x53
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xab

goroutine 1813 [chan receive, 39 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x25
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1776
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0xa9

goroutine 1814 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6950580?}, {0x4490030, 0xc0019db740}, {0x7fa85f8e38b8, 0xc002d4fb80}, {0x44f3ac8, 0x3dadba0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x187
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001044c40, {0x0?, 0x0?}, 0xc0043c8cc0, 0xc004dff620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x545
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001044c40, 0xc0043c8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x4d7
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x25
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x33
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0042c3f50, {0x44671a0, 0xc0043e8410}, 0x1, 0xc0043c8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xaf
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001044c40, 0xc0043c8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x1c5
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x1b
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x52
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1776
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x73

goroutine 1829 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001044c40, 0xc0043c8cc0, 0xc005510ea0, 0xc004dff620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1814
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1749 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000ede7e0, 0xc004ed8e40, 0xc0053ced20, 0xc0053ec420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1786
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 23620 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc004d9a348, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc001e1fb88?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc004d9a330, {0xc006736001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x81?}, {0xc006736001?, 0xc001e1fce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc006e2f7c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc006e2f7c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc006e2f7c0, {0x36a0480, 0xc0086244e0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc007d54480, {0xc00534f000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0051f7ae0, 0x0, {0x448e718, 0xc001245bc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000f0eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000e073c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1825
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 1833 [select, 39 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0008ffc00, 0xc005510900, 0xc0055114a0, 0xc004dff7a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0x10f
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1825
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x4ad

goroutine 1862 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc004dff5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1650
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 2476 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478d680, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004b4a240}, 0xc000f8b720, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1957
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1818 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437c000, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc004efaab0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2084
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 24755 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000846d80, 0xc000c6de60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc000846d80, 0x44afc30?, 0xc005396ea0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1786
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 1863 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc000fce490, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc004dfe7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d68e0, {0x44afc68, 0xc0052fa140}, 0xc00545a0c0, {0x44c6be8, 0xc000e413f8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1650
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 2497 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc006e2e000, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004679680}, 0xc000f007c0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1908
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22445 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc00513a1c8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x6?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc00513a1b0, {0xc00620f770, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc00620f770?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc00513a180}, {0xc00620f770, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc008624de0, {0xc006436000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00757fe50, 0x0, {0x448e718, 0xc008355180})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000e53c40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001306d00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1718
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 24167 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001cd8780, 0xc0068abd40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc001cd8780, 0x44afc30?, 0xc005396ea0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1777
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 2661 [select, 38 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*buffer).Pop(0xc0019747c0)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/buffer.go:80 +0x11f
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func3()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:91 +0x39
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:78 +0x56
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 2658
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x96

goroutine 1909 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053ca3c0, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562ed20}, 0xc0002a7420, 0x0, 0xc005bdf590, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2197 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001cead20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 2210
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 1949 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00031c3c0, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc002107290, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2086
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2014 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004eed900, {{{0x3e72158, 0x1e}}, {0x0, 0x0}, 0xc000e41590, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2092
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2295 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/hubble/metrics.EnableMetrics.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/metrics/metrics.go:164 +0x38
created by github.com/cilium/cilium/pkg/hubble/metrics.EnableMetrics in goroutine 2231
	/go/src/github.com/cilium/cilium/pkg/hubble/metrics/metrics.go:163 +0x110

goroutine 2007 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004eecdc0, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc0008c6720, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2070
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1864 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1650
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1892 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1651
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 1910 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e370})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053ca500, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d78b70, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1911 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00545a660?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1912 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053ca640, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562eea0}, 0xc0002a7810, 0x0, 0xc005bdf740, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1913 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e410})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053ca780, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d78ed0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1914 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0029de1e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1915 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053ca8c0, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562f020}, 0xc0002a7dc0, 0x0, 0xc005bdf8f0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1916 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e4b0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053caa00, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d79130, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1917 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1918 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cab40, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562f1a0}, 0xc000468380, 0x0, 0xc005bdfaa0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1919 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e5f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cac80, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d79350, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1920 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x4000105?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002328fa0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1921 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cadc0, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562f320}, 0xc0004689a0, 0x0, 0xc005bdfc50, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1922 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e690})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053caf00, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d79540, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1923 [chan receive, 14 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc000a3cbe0?, 0xc000bb8fd0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0027826e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1924 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cb040, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562f4a0}, 0xc000468e70, 0x0, 0xc005bdfe00, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1925 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e730})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cb180, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d79760, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1926 [chan receive, 14 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc004723320?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1927 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cb2c0, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562f620}, 0xc000469340, 0x0, 0xc001ce0030, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1928 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e7d0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cb400, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d798b0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1929 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0xc001fce5a0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001fce120?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1930 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cb540, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562f7a0}, 0xc000469810, 0x0, 0xc001ce09c0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1931 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e870})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cb680, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000d79be0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1932 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001da5380?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1933 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cba40, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562f920}, 0xc000469c00, 0x0, 0xc001ce0f30, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2511 [select, 38 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc007e6b180, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x113
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc00029a380)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x86
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:334 +0xc7
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 2599
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:332 +0x193e

goroutine 1953 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471e9b0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0053cbe00, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddc160, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1954 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000df6e40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1955 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00098e000, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562fc20}, 0xc0004dc930, 0x0, 0xc001a883f0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1956 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471ea50})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003ede00, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddc350, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1957 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0xc000e31f01?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001810f40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1958 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000a59b80, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562fda0}, 0xc0004dcee0, 0x0, 0xc001a88780, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1959 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471eaf0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000a59e00, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddc570, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1960 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc001b42ba0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0022073f8?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 2512 [select, 38 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc0023d2180)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1168 +0x205
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 2599
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:355 +0x1985

goroutine 1961 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00027cf00, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00562ff20}, 0xc0004dd570, 0x0, 0xc001a88ab0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1962 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471eb90})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00027d2c0, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddce00, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1963 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0xc004ee4000?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002b837a0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1964 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00027d900, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0022da660}, 0xc0004ddf10, 0x0, 0xc001a88e40, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1965 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471ec30})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00027db80, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddcf50, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1966 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002ae0ae0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1967 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ecf00, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0022dacc0}, 0xc000175490, 0x0, 0xc001a890e0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1968 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471ecd0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ed040, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddd120, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1969 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x2540be400?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0053cbcc0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 2310 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004df08c0, {{{0x3e33a7b, 0x10}}, {0x0, 0x0}, 0xc001804b90, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2210
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1970 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471edc0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ed400, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddd370, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1971 [chan receive, 14 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0xc001fce5a0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001fce120?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1972 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ed680, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0022db7a0}, 0xc0002ee2a0, 0x0, 0xc001a89950, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2006 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004eecc80, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc0008c6570, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2078
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1973 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471ee60})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ed7c0, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddd4a0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1974 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0053ca780?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1975 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ed900, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0022dbe60}, 0xc0002ee690, 0x0, 0xc0016a4120, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2097 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a2140, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc002388270, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2081
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1976 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471ef00})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029edb80, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddd860, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1977 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0027497a0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1978 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029edcc0, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0024e8780}, 0xc0002eebd0, 0x0, 0xc0016a45a0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1979 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471efa0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029ede00, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000dddac0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1980 [chan receive, 14 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 2037 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478c500, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001e71830, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2068
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1104 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a2000, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc002388060, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2065
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1981 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118e140, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0024e8c00}, 0xc0002ef180, 0x0, 0xc0016a4870, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1982 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471f040})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118e500, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000dddbf0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1983 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0029ed040?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1984 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118e640, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0024e9260}, 0xc0002ef5e0, 0x0, 0xc0016a4a20, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1985 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471f0e0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118e780, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000ddddc0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1986 [chan receive, 14 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x2540be400?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0053cb2c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1987 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118e8c0, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0024e9c80}, 0xc0002efc70, 0x0, 0xc0016a4c00, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1988 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471f180})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118eb40, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000b98010, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1989 [chan receive, 14 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0053cbe00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1990 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118ec80, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0024e9e60}, 0xc000286460, 0x0, 0xc0016a4db0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1991 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471f220})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118edc0, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000b98350, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1992 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x2540be400?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0029edcc0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1993 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118ef00, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc0024043c0}, 0xc000286af0, 0x0, 0xc0016a5260, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1994 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00471f2c0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118f040, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc000b98480, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 1995 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x2540be400?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00027cf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 1996 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118f180, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc002404540}, 0xc000286fc0, 0x0, 0xc0016a5590, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2489 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00031dcc0, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc00547bbc0}, 0xc001a87010, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1954
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2470 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc006c388c0, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc005399200}, 0xc000e57640, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1963
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2578 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004bdeb40, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc0046c9f20}, 0xc000c139b0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1905
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2545 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fa85f8aee48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc004280c00?, 0xc0052f9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc004280c00, {0xc0052f9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc004280c00, {0xc0052f9000?, 0xc00207af28?, 0xc005f43920?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014a2930, {0xc0052f9000?, 0xc000090700?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x45
net/http.(*persistConn).Read(0xc004754c60, {0xc0052f9000?, 0x4543a0?, 0xc00207af28?})
	/usr/local/go/src/net/http/transport.go:1977 +0x4a
bufio.(*Reader).fill(0xc004b4b4a0)
	/usr/local/go/src/bufio/bufio.go:110 +0x103
bufio.(*Reader).Peek(0xc004b4b4a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x53
net/http.(*persistConn).readLoop(0xc004754c60)
	/usr/local/go/src/net/http/transport.go:2141 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 2479
	/usr/local/go/src/net/http/transport.go:1799 +0x152f

goroutine 2468 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc006c38500, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc005398d80}, 0xc000e56f10, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1995
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 24181 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001cd87c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc00046fb80?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc001cd87b0, {0xc006954600, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc006954600?, 0xc00046fce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc006145b80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc006145b80)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc006145b80, {0x36a0480, 0xc007e5ed08})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc006db1e00, {0xc00729dc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc006a869b0, 0x0, {0x448e718, 0xc007f2e180})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00135c600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc007f2e140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1777
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 2035 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478c140, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001e710b0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2000
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2494 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00438f7c0, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc00545fda0}, 0xc0010303e0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2379
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22893 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc007cc4180, 0xc006740900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc007cc4180, 0xc00082c120?, 0xc00082c180?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1632
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 2659 [select, 38 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:59 +0xc5
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:78 +0x56
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 2658
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x96

goroutine 2991 [IO wait]:
internal/poll.runtime_pollWait(0x7fa85f8ae970, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc0062df300?, 0xc005d32000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0062df300, {0xc005d32000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0062df300, {0xc005d32000?, 0xc002b8df28?, 0xc0080fef60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0016d57c0, {0xc005d32000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x45
net/http.(*persistConn).Read(0xc002a03320, {0xc005d32000?, 0x4543a0?, 0xc002b8df28?})
	/usr/local/go/src/net/http/transport.go:1977 +0x4a
bufio.(*Reader).fill(0xc005d191a0)
	/usr/local/go/src/bufio/bufio.go:110 +0x103
bufio.(*Reader).Peek(0xc005d191a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x53
net/http.(*persistConn).readLoop(0xc002a03320)
	/usr/local/go/src/net/http/transport.go:2141 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 3176
	/usr/local/go/src/net/http/transport.go:1799 +0x152f

goroutine 2544 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004483180, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc001fc77a0}, 0xc0006a05e0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1917
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2023 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004c4f00, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000a3c2c0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2069
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2094 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118f400, {{{0x3e2fe44, 0xf}}, {0x0, 0x0}, 0xc001304ab0, 0x0, 0x4044528, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2098 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a2280, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc002388450, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2080
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2038 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478c640, {{{0x3e5a1f7, 0x19}}, {0x0, 0x0}, 0xc001e71a40, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2069
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2099 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a23c0, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000efc580, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1998
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2102 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a2500, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000efc640, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2000
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2491 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00438ea00, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc00545e900}, 0xc000a1d210, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1966
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2104 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0049a2640, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000efc6e0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1997
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2165 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0029fbf20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1616
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 2057 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555ab40, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000d874e0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2085
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2114 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437c3c0, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000eeab20, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2067
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2502 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555b400, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc0029fb6e0}, 0xc0009e1240, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1920
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2059 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555ac80, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000d87580, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2068
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2345 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000564140, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc0029ddf20}, 0xc000a47d70, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1977
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2041 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478c8c0, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000c07bc0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2078
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2063 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555adc0, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000d87ce0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2081
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2043 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478ca00, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000c07ce0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2080
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2240 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437cb40, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004cf99e0}, 0xc000c04bb0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1911
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2045 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478cc80, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000c07de0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2083
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2047 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478cdc0, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000c07f00, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2074
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2293 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0029e33e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 2231
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 2129 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478cf00, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000694060, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2086
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2131 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478d180, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000694120, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2071
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2133 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478d2c0, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc0006941e0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2075
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2166 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0029f42a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1616
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 2135 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478d400, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000694280, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2084
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2546 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0xc004754c60)
	/usr/local/go/src/net/http/transport.go:2458 +0xf0
created by net/http.(*Transport).dialConn in goroutine 2479
	/usr/local/go/src/net/http/transport.go:1800 +0x1585

goroutine 2117 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437c500, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000eeabe0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2065
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2120 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437c640, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000eeaca0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2066
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2146 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555af00, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000d87da0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2077
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2581 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004bdfe00, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004bf6540}, 0xc000c13f00, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1926
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2123 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437c8c0, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000eeada0, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2079
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 23403 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0023d2048, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc004ec1b88?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0023d2030, {0xc005716001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x7c?}, {0xc005716001?, 0xc004ec1ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc0083a6280)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0083a6280)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc0083a6280, {0x36a0480, 0xc007a3b980})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc008bbfd40, {0xc00013c400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0087f5ea0, 0x0, {0x448e718, 0xc007f6da40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0018245a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc008bb4100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1599
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 2149 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555b040, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000d87e60, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2082
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2126 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00437ca00, {{{0x3e5a210, 0x19}}, {0x0, 0x0}, 0xc000eeae60, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2073
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22863 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0051530c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xd?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0051530b0, {0xc001671d18, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc001671d18?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc005153080}, {0xc001671d18, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000fffd58, {0xc006c31000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0051c0aa0, 0x0, {0x448e718, 0xc00868cac0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00175fe20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0019db740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1814
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 2298 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0xc004bdef00)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x97
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 2231
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:285 +0x271c

goroutine 2182 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1649
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 2167 [sync.Cond.Wait, 38 minutes]:
sync.runtime_notifyListWait(0xc0010d8450, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0029fbf20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6e60, {0x44afc68, 0xc002714460}, 0xc00270b080, {0x44c74f8, 0xc00123cc48})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1616
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 2168 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1616
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 2299 [runnable]:
syscall.Syscall6(0xe8, 0x4e, 0xc004bed080, 0x8, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x39
golang.org/x/sys/unix.EpollWait(0x2455385?, {0xc004bed080?, 0xc00222d950?, 0x24552fb?}, 0x4469ec0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:55 +0x4f
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc000919bc0, {0xc004bed080, 0x8, 0x8}, {0x0?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x26e
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc001c56fc0, 0xc00222db00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2a8
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0xc001847ea0, {0x44afc68, 0xc002714dc0})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x49c
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 2231
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xd0

goroutine 2154 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc0029e03c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x9c
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1614
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a5

goroutine 2155 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0029e0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x2ff
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1614
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x205

goroutine 2156 [sync.Cond.Wait, 39 minutes]:
sync.runtime_notifyListWait(0xc00118a710, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x85
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0029e03c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x93
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x44d6ae0, {0x44afc68, 0xc000a13130}, 0xc00236daa0, {0x44c6d48, 0xc00123ccc0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0x14d
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x345
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1614
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x545

goroutine 2157 [select, 39 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0x134
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1614
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x605

goroutine 2297 [select, 5 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0xc000f45f50, {0x44afc68, 0xc000a54fa0})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xfa
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 2231
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:273 +0x267f

goroutine 2350 [select, 1 minutes]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:400 +0x8b
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 2331
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:395 +0x5a

goroutine 19747 [select, 9 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0081e2c00, 0xc00534d8c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc0081e2c00, 0x44afc30?, 0xc005396ea0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1061
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 2095 [chan receive, 39 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x156
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1612
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x34f

goroutine 2209 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0x115
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0xc001304db0, 0xc001daf380?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x5b1
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1612
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x226

goroutine 2210 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118f7c0, {{{0x3e25182, 0xd}}, {0x0, 0x0}, 0xc0013abe60, 0x0, 0xc000d9bd40, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2213 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2196 [syscall, 39 minutes]:
syscall.Syscall6(0xf7, 0x1, 0x167, 0xc002241cc8, 0x1000004, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x39
os.(*Process).blockUntilWaitable(0xc0017a57a0)
	/usr/local/go/src/os/wait_waitid.go:32 +0x76
os.(*Process).wait(0xc0017a57a0)
	/usr/local/go/src/os/exec_unix.go:22 +0x25
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0xc001cd8900)
	/usr/local/go/src/os/exec/exec.go:901 +0x45
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 2195
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x4c8

goroutine 2214 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2215 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2216 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2217 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2218 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2219 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2220 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2221 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2222 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2223 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2224 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2225 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2226 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2227 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0x130
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x67

goroutine 2228 [IO wait]:
internal/poll.runtime_pollWait(0x7fa85f99f6d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x43?, 0x1?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0026e5e00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0026e5e00)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc0005e0900)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1e
net.(*TCPListener).Accept(0xc0005e0900)
	/usr/local/go/src/net/tcpsock.go:327 +0x30
net/http.(*Server).Serve(0xc004b5bd10, {0x44980d0, 0xc0005e0900})
	/usr/local/go/src/net/http/server.go:3260 +0x33e
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0xc000fc6b60, 0xe}, {0x44980d0, 0xc0005e0900})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xc5
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1612
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x65d

goroutine 24702 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0081e2a80, 0xc001f41d40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc0081e2a80, 0xc001474d50?, 0xc001474d60?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 977
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 2229 [IO wait, 39 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99f8c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x48?, 0x10?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0026e5e80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc0026e5e80)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc0005e0940)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1e
net.(*TCPListener).Accept(0xc0005e0940)
	/usr/local/go/src/net/tcpsock.go:327 +0x30
net/http.(*Server).Serve(0xc002279e00, {0x44980d0, 0xc0005e0940})
	/usr/local/go/src/net/http/server.go:3260 +0x33e
github.com/cilium/cilium/daemon/cmd.(*Daemon).startKubeProxyHealthzHTTPService.func1()
	/go/src/github.com/cilium/cilium/daemon/cmd/kube_proxy_healthz.go:58 +0x37
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startKubeProxyHealthzHTTPService in goroutine 1612
	/go/src/github.com/cilium/cilium/daemon/cmd/kube_proxy_healthz.go:57 +0x47f

goroutine 2230 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118f900, {{{0x3e48edb, 0x15}}, {0x0, 0x0}, 0xc001aa0690, 0x0, 0x4044528, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2232 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00059e280, {{{0x3e4cd48, 0x16}}, {0x44b7c80, 0xc001119da0}, 0xc0019acc60, 0x0, 0x4044528, 0xe33e22200, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2300 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fa85f8af608, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x1a?, 0x10?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc00482c680)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc00482c680)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0x44af80?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc00203c180)
	/usr/local/go/src/net/unixsock.go:260 +0x30
google.golang.org/grpc.(*Server).Serve(0xc002abc600, {0x4498100, 0xc00203c180})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x49e
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:337 +0x4d
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 2231
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:336 +0x383c

goroutine 2301 [chan receive, 39 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:342 +0x38
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 2231
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:341 +0x38ae

goroutine 2302 [IO wait, 39 minutes]:
internal/poll.runtime_pollWait(0x7fa85f8af320, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc004786fc0?, 0xc002b0fe3b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc004786fc0, {0xc002b0fe3b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0xc0013fe8e0, {0xc002b0fe3b?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x52
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000d69e00)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xcf
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 2231
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1c5

goroutine 2303 [select, 39 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0xc0018f14d0)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0xd1
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 2231
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1e5

goroutine 2255 [chan receive, 39 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func7()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:412 +0x38
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 2231
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:411 +0x45f9

goroutine 2254 [IO wait, 38 minutes]:
internal/poll.runtime_pollWait(0x7fa85f8af228, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x5a?, 0x1?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002a85800)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002a85800)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc000e44fc0)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1e
net.(*TCPListener).Accept(0xc000e44fc0)
	/usr/local/go/src/net/tcpsock.go:327 +0x30
google.golang.org/grpc.(*Server).Serve(0xc00221a800, {0x44980d0, 0xc000e44fc0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x49e
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func6()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:403 +0x56
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 2231
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:402 +0x4585

goroutine 2376 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0023acc80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2e5
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 2031
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d8

goroutine 2351 [IO wait]:
internal/poll.runtime_pollWait(0x7fa85f8aed50, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x144?, 0x10?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc004480f80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc004480f80)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*UnixListener).accept(0xc002b78e00?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x16
net.(*UnixListener).Accept(0xc004cffcb0)
	/usr/local/go/src/net/unixsock.go:260 +0x30
net/http.(*Server).Serve(0xc0057534a0, {0x4498100, 0xc004cffcb0})
	/usr/local/go/src/net/http/server.go:3260 +0x33e
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x4498100?, 0xc004cffcb0?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:357 +0x78
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 2331
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:355 +0x4a8

goroutine 5304 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc007c82dc0, {{{0x3e33a7b, 0x10}}, {0x0, 0x0}, 0xc000c5c9d0, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 931
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2341 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004eeda40, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc0027336e0}, 0xc0007f95a0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1992
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2352 [IO wait]:
internal/poll.runtime_pollWait(0x7fa85f8aec58, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x4457da0?, 0x6799b38?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0xc004481200, {0xc0029a3800, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x285
net.(*netFD).readFrom(0xc004481200, {0xc0029a3800?, 0x72?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:61 +0x25
net.(*IPConn).readFrom(0x54e8c8?, {0xc0029a3800, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0xc00184a728, {0xc0029a3800?, 0xc002b77ec8?, 0xc002b77e88?})
	/usr/local/go/src/net/iprawsock.go:129 +0x30
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc1a409b9b9cfda4c?, {0xc0029a3800?, 0x6950580?, 0x6950580?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x2f
github.com/servak/go-fastping.(*Pinger).recvICMP(0xc000bfddd0, 0xc0009d83a0, 0xc0023a0f60, 0xc0009d83c0, 0xc005124490)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x14e
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 2349
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x377

goroutine 2308 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001027ec0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 2210
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 2335 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00436f7c0, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004678b40}, 0xc000f00150, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1971
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2160 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00555bcc0, {{{0x3e217f2, 0xc}}, {0x0, 0x0}, 0xc000933620, 0x0, 0x4044528, 0x12a05f200, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2088
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22942 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0081e3cc8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x7?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0081e3cb0, {0xc007ec5828, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc007ec5828?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc0081e3c80}, {0xc007ec5828, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0084e1e00, {0xc00534e800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc007184af0, 0x0, {0x448e718, 0xc00122b080})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000c3b5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc007af1ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 951
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 2593 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc006e2f900, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc002404e40}, 0xc000dd4fe0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1932
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22376 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0081e2600, 0xc007acb7a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc0081e2600, 0x10791e5?, 0xc000f4f7c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1552
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 2378 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc00065b4f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027308c0, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc0002f5c00, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2031
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2379 [chan receive, 38 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x73
sync.(*Once).doSlow(0x243d1c5?, 0xc001552408?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x3c
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 2031
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x69

goroutine 2380 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002730a00, {{{0x3e5eca0, 0x1a}}, {0x44b7c80, 0xc00429af00}, 0xc000322310, 0x0, 0xc0016254d0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2031
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2381 [select, 39 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002730b40, {{{0x3e2a3f4, 0xe}}, {0x0, 0x0}, 0xc00065b680, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2031
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2386 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002730c80, {{{0x3e33a7b, 0x10}}, {0x0, 0x0}, 0xc000b1b6e0, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2381
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2307 [select, 39 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x44afc68, 0xc0007c8be0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x90
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004df0500, {{{0x3e72a40, 0x1e}}, {0x0, 0x0}, 0xc001804720, 0x0, 0x4044528, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x10f
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2210
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5365 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc007d84c80, {{{0x3e33a7b, 0x10}}, {0x0, 0x0}, 0xc000c5cbe0, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 931
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2270 [IO wait, 38 minutes]:
internal/poll.runtime_pollWait(0x7fa85f8af038, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0x38?, 0x1706?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002bca200)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x2ac
net.(*netFD).accept(0xc002bca200)
	/usr/local/go/src/net/fd_unix.go:172 +0x29
net.(*TCPListener).accept(0xc001714160)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x1e
net.(*TCPListener).Accept(0xc001714160)
	/usr/local/go/src/net/tcpsock.go:327 +0x30
net/http.(*Server).Serve(0xc002279d10, {0x44980d0, 0xc001714160})
	/usr/local/go/src/net/http/server.go:3260 +0x33e
net/http.(*Server).ListenAndServe(0xc002279d10)
	/usr/local/go/src/net/http/server.go:3189 +0x71
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x25
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 2330
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x51

goroutine 2500 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00118f2c0, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc001acdf20}, 0xc0009e0e50, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1983
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2331 [semacquire, 38 minutes]:
sync.runtime_Semacquire(0x44af80?)
	/usr/local/go/src/runtime/sema.go:62 +0x25
sync.(*WaitGroup).Wait(0xc0007f6200?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x48
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0xc0007f6200)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0x95
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0xc0007f6200)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:370 +0x105
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:388 +0x25
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 2329
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0xc7

goroutine 2483 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc005435540, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc00540f740}, 0xc000ef1870, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1986
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2329 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0xc0007f6200)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:392 +0xdc
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x72
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 2209
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1ff

goroutine 2330 [chan receive, 39 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0xc000d9bc80)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xce
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:384 +0x27
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 2329
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x78

goroutine 2547 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fa85f99f008, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc004280c80?, 0xc005a87000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc004280c80, {0xc005a87000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc004280c80, {0xc005a87000?, 0xc002bbfa98?, 0x4f0fa5?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc0014a2938, {0xc005a87000?, 0x0?, 0xc0016e0ab8?})
	/usr/local/go/src/net/net.go:185 +0x45
net/http.(*connReader).Read(0xc0016e0ab0, {0xc005a87000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x14b
bufio.(*Reader).fill(0xc004b4b560)
	/usr/local/go/src/bufio/bufio.go:110 +0x103
bufio.(*Reader).Peek(0xc004b4b560, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x53
net/http.(*conn).serve(0xc000b9a2d0, {0x44afc30, 0xc002bee870})
	/usr/local/go/src/net/http/server.go:2079 +0x749
created by net/http.(*Server).Serve in goroutine 2270
	/usr/local/go/src/net/http/server.go:3290 +0x4b4

goroutine 2992 [select]:
net/http.(*persistConn).writeLoop(0xc002a03320)
	/usr/local/go/src/net/http/transport.go:2458 +0xf0
created by net/http.(*Transport).dialConn in goroutine 3176
	/usr/local/go/src/net/http/transport.go:1800 +0x1585

goroutine 24703 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0081e2ac8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x4862bd?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0081e2ab0, {0xc001c75000, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x43e2e9?}, {0xc001c75000?, 0xc0026dfce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc006e2e280)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc006e2e280)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc006e2e280, {0x36a0480, 0xc000d3e3d8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001ace8d0, {0xc0054be400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc005755d10, 0x0, {0x448e718, 0xc00145f880})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001854dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00145f840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 977
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 2658 [semacquire, 38 minutes]:
sync.runtime_Semacquire(0xc004300b00?)
	/usr/local/go/src/runtime/sema.go:62 +0x25
sync.(*WaitGroup).Wait(0x0?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x48
golang.org/x/sync/errgroup.(*Group).Wait(0xc0019745c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:56 +0x25
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify(0xc002714e10, 0x369f600?, {0x44c4ba0, 0xc0010121e0})
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:106 +0x3fb
github.com/cilium/cilium/api/v1/peer._Peer_Notify_Handler({0x369f600, 0xc002714e10}, {0x44bead0, 0xc007e0e870})
	/go/src/github.com/cilium/cilium/api/v1/peer/peer_grpc.pb.go:119 +0x107
google.golang.org/grpc.(*Server).processStreamingRPC(0xc00221a800, {0x44afc30, 0xc000e4c1e0}, {0x44ceb00, 0xc0023d2180}, 0xc004359c20, 0xc001678ab0, 0x68f5360, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0x1208
google.golang.org/grpc.(*Server).handleStream(0xc00221a800, {0x44ceb00, 0xc0023d2180}, 0xc004359c20)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xe3a
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8b
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 2657
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x125

goroutine 2537 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004c5b80, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004787980}, 0xc000c69d90, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1974
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2444 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004bde140, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc002ade840}, 0xc001970ca0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1989
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22439 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc005389248, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc00869d740?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc005389230, {0xc005994001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x84?}, {0xc005994001?, 0xc002429ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc0078bde00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0078bde00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc0078bde00, {0x36a0480, 0xc000721140})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc008840210, {0xc005131000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0088260f0, 0x0, {0x448e718, 0xc00769d780})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000f135a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00869d780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1773
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 2447 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004bde3c0, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc0046c8ae0}, 0xc000c131b0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1980
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2534 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004c5400, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc0013d2300}, 0xc00082dc70, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1923
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2442 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004bf4000, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc0029f4a80}, 0xc000e438c0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1929
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2660 [select, 38 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func2()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:73 +0x106
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:78 +0x56
created by golang.org/x/sync/errgroup.(*Group).Go in goroutine 2658
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x96

goroutine 2551 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00478d7c0, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc004b4baa0}, 0xc0009323c0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1914
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 2540 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004482000, {{{0x3e2a3e6, 0xe}}, {0x44b7c80, 0xc00429a600}, 0xc000399de0, 0x0, 0x4044528, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1960
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 5364 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc007d84b40, {{{0x3e33a7b, 0x10}}, {0x0, 0x0}, 0xc0014f6560, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 931
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22709 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001cd8300, 0xc001ed25a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc001cd8300, 0xc00118f540?, 0xc004ec6630?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 541
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 5306 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc007c83040, {{{0x3e33a7b, 0x10}}, {0x0, 0x0}, 0xc0014f6430, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 931
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22862 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc005153080, 0xc002d5ad80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc005153080, 0x10791e5?, 0xc0013be900?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1814
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 19258 [select, 11 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000846900, 0xc006b2ac60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc000846900, 0xc00132fb50?, 0xc00132fb60?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1533
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 12267 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0xc001d9eb40)
	/usr/local/go/src/net/http/transport.go:2458 +0xf0
created by net/http.(*Transport).dialConn in goroutine 12265
	/usr/local/go/src/net/http/transport.go:1800 +0x1585

goroutine 22438 [select, 5 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc005389200, 0xc008818480, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc005389200, 0x44afc30?, 0xc005396ea0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1773
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 20822 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc005389800, 0xc002be19e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc005389800, 0x10791e5?, 0xc001360d40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 973
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 12266 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fa85f18b7d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc0062de380?, 0xc0021f1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0062de380, {0xc0021f1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc0062de380, {0xc0021f1000?, 0x0?, 0xc0051dfa40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc001b52048, {0xc0021f1000?, 0x0?, 0xc002060c40?})
	/usr/local/go/src/net/net.go:185 +0x45
net/http.(*persistConn).Read(0xc001d9eb40, {0xc0021f1000?, 0xc002ce46c0?, 0xc008436d38?})
	/usr/local/go/src/net/http/transport.go:1977 +0x4a
bufio.(*Reader).fill(0xc005d3c780)
	/usr/local/go/src/bufio/bufio.go:110 +0x103
bufio.(*Reader).Peek(0xc005d3c780, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x53
net/http.(*persistConn).readLoop(0xc001d9eb40)
	/usr/local/go/src/net/http/transport.go:2141 +0x1b9
created by net/http.(*Transport).dialConn in goroutine 12265
	/usr/local/go/src/net/http/transport.go:1799 +0x152f

goroutine 23619 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc004d9a300, 0xc000c6dd40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc004d9a300, 0x44afc30?, 0xc004cfff20?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1825
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 22444 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00513a180, 0xc00840ac60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc00513a180, 0x10791e5?, 0xc000c48bc0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1718
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 5305 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc007c82f00, {{{0x3e33a7b, 0x10}}, {0x0, 0x0}, 0xc000c5ca60, 0x0, 0x4044528, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x9d6
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 931
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x458

goroutine 22747 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc005152a80, 0xc0021d0d80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc005152a80, 0xc00118f540?, 0xc002696bb0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1683
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 24616 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001cd8648, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0x39f0301?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc001cd8630, {0xc0085cd0f8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc0085cd0f8?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc001cd8600}, {0xc0085cd0f8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0074fe060, {0xc00729c000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00278af00, 0x0, {0x448e718, 0xc00180ba00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000c7aaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00180b9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 239
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 20810 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc000847e48, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0017e7c40?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc000847e30, {0xc005269201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x79?}, {0xc005269201?, 0xc0041e1ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc004437cc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc004437cc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc004437cc0, {0x36a0480, 0xc0084d53b0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc007a17410, {0xc004cd5000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00473caf0, 0x0, {0x448e718, 0xc008032340})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000f4c1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0017e7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 957
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 23996 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fa85f8ae878, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0x85
internal/poll.(*pollDesc).wait(0xc00558c180?, 0xc0041fa000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x27
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00558c180, {0xc0041fa000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x27a
net.(*netFD).Read(0xc00558c180, {0xc0041fa000?, 0xc008a9da98?, 0x4f0fa5?})
	/usr/local/go/src/net/fd_posix.go:55 +0x25
net.(*conn).Read(0xc00184a0d8, {0xc0041fa000?, 0x0?, 0xc007d78608?})
	/usr/local/go/src/net/net.go:185 +0x45
net/http.(*connReader).Read(0xc007d78600, {0xc0041fa000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x14b
bufio.(*Reader).fill(0xc0076c14a0)
	/usr/local/go/src/bufio/bufio.go:110 +0x103
bufio.(*Reader).Peek(0xc0076c14a0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x53
net/http.(*conn).serve(0xc006047cb0, {0x44afc30, 0xc000effd10})
	/usr/local/go/src/net/http/server.go:2079 +0x749
created by net/http.(*Server).Serve in goroutine 2292
	/usr/local/go/src/net/http/server.go:3290 +0x4b4

goroutine 24615 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001cd8600, 0xc0054c2c60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0xa85
golang.org/x/net/http2.(*clientStream).doRequest(0xc001cd8600, 0x10791e5?, 0xc007bbb440?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x56
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 239
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x3e5

goroutine 22377 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0081e2648, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xd?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc0081e2630, {0xc005f5af88, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x40f63f?}, {0xc005f5af88?, 0x38be3e0?, 0x412201?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
io.ReadAtLeast({0x7fa85f924000, 0xc0081e2600}, {0xc005f5af88, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0x90
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc008706708, {0xc00729d400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc007fc6500, 0x0, {0x448e718, 0xc008425080})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011d2960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc008b894c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1552
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105

goroutine 22124 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000847848, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x159
sync.(*Cond).Wait(0xc0088b1900?)
	/usr/local/go/src/sync/cond.go:70 +0x85
golang.org/x/net/http2.(*pipe).Read(0xc000847830, {0xc008c72601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xdf
golang.org/x/net/http2.transportResponseBody.Read({0x79?}, {0xc008c72601?, 0xc005529ce0?, 0x411e9b?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x65
encoding/json.(*Decoder).refill(0xc005c3b180)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc005c3b180)
	/usr/local/go/src/encoding/json/stream.go:140 +0x85
encoding/json.(*Decoder).Decode(0xc005c3b180, {0x36a0480, 0xc0085b8b70})
	/usr/local/go/src/encoding/json/stream.go:63 +0x75
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00892b5f0, {0xc0022c5c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0064093b0, 0x0, {0x448e718, 0xc001811580})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa3
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0009eb000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4b
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0088b19c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdb
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 692
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x105
