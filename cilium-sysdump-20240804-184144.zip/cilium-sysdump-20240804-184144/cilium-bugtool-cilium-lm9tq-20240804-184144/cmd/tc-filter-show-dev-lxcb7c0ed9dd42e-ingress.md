filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb7c0ed9dd42e direct-action not_in_hw id 4000 tag d2e2e967fcd30453 jited 
