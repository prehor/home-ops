CgroupPath
ID       AttachType      AttachFlags     Name           
/sys/fs/cgroup
3920     cgroup_inet4_connect multi           cil_sock4_connect                
3922     cgroup_inet6_connect multi           cil_sock6_connect                
3926     cgroup_inet4_post_bind multi           cil_sock4_post_bind                
3924     cgroup_inet6_post_bind multi           cil_sock6_post_bind                
3918     cgroup_udp4_sendmsg multi           cil_sock4_sendmsg                
3923     cgroup_udp6_sendmsg multi           cil_sock6_sendmsg                
3925     cgroup_udp4_recvmsg multi           cil_sock4_recvmsg                
3919     cgroup_udp6_recvmsg multi           cil_sock6_recvmsg                
3921     cgroup_inet4_getpeername multi           cil_sock4_getpeername                
3917     cgroup_inet6_getpeername multi           cil_sock6_getpeername                
/sys/fs/cgroup/system.slice/haveged.service
    8        cgroup_device   multi           sd_devices                     
/sys/fs/cgroup/system.slice/systemd-udevd.service
    7        cgroup_inet_ingress multi           sd_fw_ingress                  
    6        cgroup_inet_egress multi           sd_fw_egress                   
/sys/fs/cgroup/system.slice/systemd-journald.service
    5        cgroup_inet_ingress multi           sd_fw_ingress                  
    4        cgroup_inet_egress multi           sd_fw_egress                   
    3        cgroup_device   multi           sd_devices                     
/sys/fs/cgroup/system.slice/systemd-timesyncd.service
    9        cgroup_device   multi           sd_devices                     
/sys/fs/cgroup/system.slice/systemd-logind.service
    12       cgroup_inet_ingress multi           sd_fw_ingress                  
    11       cgroup_inet_egress multi           sd_fw_egress                   
    10       cgroup_device   multi           sd_devices                     
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19844677_4565_40b4_8e83_e6e1c9e39200.slice/cri-containerd-843ff6a0a51384b9d6f168a399299859b06e2cec86f1dc07d81683dfac14becf.scope
    991      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19844677_4565_40b4_8e83_e6e1c9e39200.slice/cri-containerd-357d1c1628b96bde122799c6fb2bd4b959e0866489111b7a6f5d31645364a3da.scope
    975      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd734368_ca17_41bd_81e7_85ea53015cf3.slice/cri-containerd-838d03c781ba140b9bb31e667ceb6099b9257796070acfdfce3ac113b955b5b8.scope
    999      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd734368_ca17_41bd_81e7_85ea53015cf3.slice/cri-containerd-f51760bce9df39e0e5ba58c6f5d29d245fc732798bfd806aac28e4e095cc35e6.scope
    995      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda212e8f6_0013_49e6_b00b_72a9e0031917.slice/cri-containerd-dd953768435df1c6873e0d18ec4b00f55feacf8515bd91515990b3ac70ba3723.scope
    822      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda212e8f6_0013_49e6_b00b_72a9e0031917.slice/cri-containerd-1f14dfc76f1ce17793a87a885528e15c28e3df2c7cc5f56a60d323325e40e316.scope
    790      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1ceb180_a9e5_4876_a1e9_c63b6ba46559.slice/cri-containerd-b23aea0e9721614bad4f8ac844f0cc57cb6d62582b82c16e21268003b82e3063.scope
    700      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1ceb180_a9e5_4876_a1e9_c63b6ba46559.slice/cri-containerd-dea0caf55e0e86008a981773a33570200007fa96cc8668edeb44f84309376f33.scope
    692      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f182242_3df5_4cac_8a40_60d11db430e4.slice/cri-containerd-570b4e3984c938df54ec244b8b9e8da8c559e1c48b2a3dd4ea67dae826121c17.scope
    882      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f182242_3df5_4cac_8a40_60d11db430e4.slice/cri-containerd-0f35832e3a2178e726665c83e8836f58019980085ca7b89b3795b720f1b05550.scope
    834      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa52a09a_2afc_49dc_b13a_8ad237aff8ad.slice/cri-containerd-838eb8e813f650ba1aad3ccd3ace05dfa6f7069be37a0c600ddb255b06eb61e2.scope
    585      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa52a09a_2afc_49dc_b13a_8ad237aff8ad.slice/cri-containerd-2f5287d07e37c1aa4ea2212e4bad56742eb83c33f34642a9b630610362d473d0.scope
    589      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2414fd0_90c7_4a11_8dd3_9d468fabbba7.slice/cri-containerd-992892b78ec5ea81f888d291b7cb11f22f507758d40731753f006ce972dfc82e.scope
    786      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2414fd0_90c7_4a11_8dd3_9d468fabbba7.slice/cri-containerd-d994e72a82e4eb8e0b5b675639d6505c70c6201c9656591c3e089866dfc6c3fd.scope
    770      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e6ab653_a903_4f9e_a05c_858166617590.slice/cri-containerd-63a915cbd65a4bdacbb1d2b03694b8c26ac9ed828e289d833515af601341d365.scope
    3488     cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e6ab653_a903_4f9e_a05c_858166617590.slice/cri-containerd-2ba81ffc14ea6b93b4bcc05022d8e0323df98e446c4abb8649a639b4b611322f.scope
    3453     cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03b3a000_ed7a_468a_8d60_2876246beb1d.slice/cri-containerd-c3e73adc957cfd4b9ac8ca7cd217ea3a4b7e5a7ec8a8066ea6a8a377ca4dadf4.scope
    926      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03b3a000_ed7a_468a_8d60_2876246beb1d.slice/cri-containerd-2a7a57d7f97181ea14ec925dd14aee7010c792502489e1350d69b80ac1e7ecdb.scope
    878      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1527b7ec_9b5f_4a35_91ca_cf2faf07c46c.slice/cri-containerd-90924bd6251452fafc94cb8fa2f1812169b297a1f59a3055b1eef01761c701b0.scope
    746      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1527b7ec_9b5f_4a35_91ca_cf2faf07c46c.slice/cri-containerd-8baec9537358188b833bf7589f6a5670cb260161145eec785c637826abb9dbaf.scope
    742      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65ac5a4f_1c1c_4be9_973a_efbd4ac3aa2b.slice/cri-containerd-a23b10ba0a91b421056fc4d659093135aa4117387df18ffd1dcfabfbb3f6e5a2.scope
    842      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65ac5a4f_1c1c_4be9_973a_efbd4ac3aa2b.slice/cri-containerd-8ee434a342b1c5f8b872a9a2ff7a755d96c482f514aea8f71bec92c284de63c2.scope
    886      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda21ab570_d5e5_4d3c_8aec_94d7ed05c5f6.slice/cri-containerd-be21bfb49f4e4310cb58edb3efe90942a06a6eeacc64799bc1ada31397b5a2e0.scope
    922      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda21ab570_d5e5_4d3c_8aec_94d7ed05c5f6.slice/cri-containerd-01580c6baa090ad11579cc2c05e2e1a83677cc13695d6a8bd703c315685f66e6.scope
    902      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf52e8fa7_83f3_44d2_90b2_a6a7ec3d9af2.slice/cri-containerd-fb3736fbd7286be45955fa16b12ccd5f5e15537dd66305fbc4a25f2ccfc2e8ff.scope
    778      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf52e8fa7_83f3_44d2_90b2_a6a7ec3d9af2.slice/cri-containerd-50c161e296ca39ae812b8bc2e66db53d86961468c0f64d428a73a7e2d6219c5d.scope
    830      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode947d31d_2275_46ce_a304_6236cae0a549.slice/cri-containerd-853637006a927d4cb2170aedbf02813ef50cebca27f3fca79a4f97197530e283.scope
    24       cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode947d31d_2275_46ce_a304_6236cae0a549.slice/cri-containerd-bb9104ddee8955d788f614effe786a8160899c9aa501fb0c1a3bcfff0bfd1bf6.scope
    74       cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod628e0335_1027_4ece_8433_6248f6318050.slice/cri-containerd-8868a653985a556fdb7e8bbd039cee1171bc4577ba0568a2eaad8b9907fef51f.scope
    471      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod628e0335_1027_4ece_8433_6248f6318050.slice/cri-containerd-3f26d1b96518599c0e30d37129995b144016e1a75acd3033131eba46ec2d7d4f.scope
    524      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc39262bb_5abb_47e4_8a64_7f12c675d3b9.slice/cri-containerd-09457963c6ce3395186ded9adf7f75b613621ba15811e400b9c0d56d1c57b05b.scope
    758      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc39262bb_5abb_47e4_8a64_7f12c675d3b9.slice/cri-containerd-bdf0abb297da42ab7e015ccf1a7a3c16d0b347957705549cf4369878e018591f.scope
    766      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5b8c17e_227c_4daf_b0f9_3a57095cfcb7.slice/cri-containerd-713aeb19bf88522fbf8e03353807bd6c9b7e49e2c77cba03c403a01ae9922c72.scope
    862      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5b8c17e_227c_4daf_b0f9_3a57095cfcb7.slice/cri-containerd-7bc47ff46543c2955ef55aff3e678f5d67cde5e63aee8a4fe79ddecccffe383d.scope
    850      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5b8c17e_227c_4daf_b0f9_3a57095cfcb7.slice/cri-containerd-68d3047f0558420ed36fdd88408b58e0a247d4ffcc39f9c11d8560354df7490c.scope
    854      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64714612_fc8f_4056_8a5e_637e5f1cb4b8.slice/cri-containerd-2790e776e74f4ff76d7a82f10efb1e8a7ec23ff5cfbd91f5883aa190908ebfd8.scope
    806      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64714612_fc8f_4056_8a5e_637e5f1cb4b8.slice/cri-containerd-9bbd17ee23cb81c88e41c57fa0b9e4e40d7ee78d8a4f4433dbdf6bbfb209720d.scope
    870      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c0adc62_4c62_44a3_9bc1_9e248709b1cf.slice/cri-containerd-9159c6bbf4e1a6d87de957567253d05f7ebb3ec04fd18e930b3be8fb9eee8d33.scope
    738      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c0adc62_4c62_44a3_9bc1_9e248709b1cf.slice/cri-containerd-824a680dfc1443e0f07765382da95f9eb0d82a47fbef411d4fd9082a83f4cd5f.scope
    734      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3336091_979b_43e7_8149_16994be41781.slice/cri-containerd-5460cebd6e0587413e5f40b7453262ced58346a9376bda92e6152bc7975adb47.scope
    826      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3336091_979b_43e7_8149_16994be41781.slice/cri-containerd-51b3b24778dd780506075cb68fa3002d39a4c4eeb56cd4b03d654b73d417ea53.scope
    798      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-b5a8c48931f07b31c6c7f47b5717d1e031692e7036e20d2da55923ff1f2c9ebc.scope
    894      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-b30d6fddc8df3b6124a59898e45e7d96da6c7a7d18651fe6588e7322c11ee426.scope
    914      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-2d485d03de6c5d0d9c3bc3bd8deff09ff6485056f0e5b46269113c0cc16cb00d.scope
    963      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-7ab3306de49937a9787f39daae076da52ee14ef22f1712bdbd2f0666b4e46922.scope
    938      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-366c4259831dceda6e0208fd6bba131fe4e414b2905af10bfcc03d49310fd8c2.scope
    942      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaae468cb_8952_4c2c_b470_3f49ab4c45b8.slice/cri-containerd-64f8988b2b9d93d4235ed7d9e61b2bfe22fbd436815506702705c7adac91afa4.scope
    950      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6299ca4e_2925_4349_91b2_a0aac80c6a7e.slice/cri-containerd-f14ad27faf5ca9498a546f7850cfda564a634ac369937481efaefb0e93b06407.scope
    16       cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6299ca4e_2925_4349_91b2_a0aac80c6a7e.slice/cri-containerd-3ec32d0c8e103509da7667c1182ca5305249a05c30791c4d05fbecf52ebcb625.scope
    64       cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6299ca4e_2925_4349_91b2_a0aac80c6a7e.slice/cri-containerd-ada55f855ca0e28739e016b11536e5a860e00c168629696d11446f45a7a1b30c.scope
    545      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3948f11_5c0b_4eb1_8f19_655f30bcbca4.slice/cri-containerd-aa8833c338372e053581f9bcddaa5f4801eca3d768a2d5e1f9a56863ad8b7495.scope
    3469     cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3948f11_5c0b_4eb1_8f19_655f30bcbca4.slice/cri-containerd-d90cc93570cef9e90c4549e758006c4b0e732d12b8040cb8d689ee31c2252d39.scope
    3473     cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1b3f27_5e7d_4433_bf63_38c1c25663bb.slice/cri-containerd-8cc5d7cf1e08fa4df77e2fe3b7420a2bff37801b3f0ab379c0d1e913fcb196ba.scope
    722      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1b3f27_5e7d_4433_bf63_38c1c25663bb.slice/cri-containerd-2bcd3a9bbeaea0548235e04aea8d6f215f2a1b829c668f3c03bf0d7eaff8195e.scope
    726      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1b3f27_5e7d_4433_bf63_38c1c25663bb.slice/cri-containerd-8435c5b109c1a29d8b05cbcee55aa0167c09c34634202ef9397bddf88e7dc861.scope
    730      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04e3966d_d278_4bcc_a89d_4d7bd92ef084.slice/cri-containerd-95c76b5f815a30860862be83fefb357325706b91adc96a832785204106c03f19.scope
    874      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04e3966d_d278_4bcc_a89d_4d7bd92ef084.slice/cri-containerd-97ef6a7f4e3068cfbe9ca98d85cf2a9319d548a5eefd9a0809ddd15c9572619a.scope
    814      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3b066ac_3f83_4a5e_b724_3ddddc02ad85.slice/cri-containerd-6b2391bec6437d394e14d255f049507cf419281f0874845611a778d43187c8f8.scope
    983      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3b066ac_3f83_4a5e_b724_3ddddc02ad85.slice/cri-containerd-53f712c676b605b8398b68b966af17dd5e2a87c9e20028df7039c5f22b2036e6.scope
    910      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod819bacc7_6bcf_4002_a466_a9b69abd29cf.slice/cri-containerd-8703a93f14d7c8f4e97022030576f54c8f9e3c690ebb3a20b416a88994bf3000.scope
    967      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod819bacc7_6bcf_4002_a466_a9b69abd29cf.slice/cri-containerd-911f148b05317ad6fe14bd8d5df34b5addd75e4540b6fef4b78b903b4c91369d.scope
    979      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2470d749_3313_4b51_87d1_487278baa440.slice/cri-containerd-1a1016fd25d882233acbbc0373321af1136b720a2424b5e777dda52719835686.scope
    32       cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2470d749_3313_4b51_87d1_487278baa440.slice/cri-containerd-a8ed92fdaa176513c2db59436dde170a6eb28e98d0a9f94dd6cf8b25ac841a5f.scope
    20       cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c249b4e_a5cb_4446_bbd2_748153fe5f90.slice/cri-containerd-cf5e9b5c1772ac80e55e1a99aa2631dd0bbe46ec03d49211e919079a7b3b8d48.scope
    918      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c249b4e_a5cb_4446_bbd2_748153fe5f90.slice/cri-containerd-64120775ee0c5f132e32a751b6d8ef61006e93c27a0f1d5346feebe97be52ef8.scope
    858      cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1f77cdd_3e96_4265_b53e_77a044a0b3cc.slice/cri-containerd-20373b24bafa1dec301a2812b2e21fb2fc82c061151937e3dc2e74a5f2e034c3.scope
    4285     cgroup_device   multi                                          
/sys/fs/cgroup/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1f77cdd_3e96_4265_b53e_77a044a0b3cc.slice/cri-containerd-9a214d81c40176f4ae329e979c5bc87ded7a77c49e722abe6c076b942fc0ccb7.scope
    4276     cgroup_device   multi                                          
