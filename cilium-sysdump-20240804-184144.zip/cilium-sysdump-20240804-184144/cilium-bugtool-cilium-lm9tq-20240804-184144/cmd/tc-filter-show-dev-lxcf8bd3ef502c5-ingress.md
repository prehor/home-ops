filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf8bd3ef502c5 direct-action not_in_hw id 4075 tag d0f85e4558f2cf8d jited 
