markdown output at /tmp/cilium-bugtool-20240804-164144.823+0000-UTC-1329664530/cmd/cilium-debuginfo-20240804-164145.18+0000-UTC.md
json output at /tmp/cilium-bugtool-20240804-164144.823+0000-UTC-1329664530/cmd/cilium-debuginfo-20240804-164145.18+0000-UTC.json
