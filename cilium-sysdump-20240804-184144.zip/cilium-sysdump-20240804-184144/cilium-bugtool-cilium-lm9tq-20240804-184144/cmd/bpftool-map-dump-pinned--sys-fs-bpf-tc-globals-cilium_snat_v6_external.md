Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_snat_v6_external): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_snat_v6_external':  exit status 255

