55: hash  name cilium_auth_map  flags 0x1
	key 12B  value 8B  max_entries 524288  memlock 12582912B
56: array  name cilium_runtime_  flags 0x0
	key 4B  value 8B  max_entries 256  memlock 4096B
57: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 8  memlock 4096B
58: hash  name cilium_node_map  flags 0x1
	key 20B  value 2B  max_entries 16384  memlock 393216B
59: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 8  memlock 4096B
60: hash  name cilium_lxc  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 4718592B
62: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 139264B
63: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 147297  memlock 3538944B
64: hash  name cilium_lb4_serv  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1572864B
65: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1048576B
66: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 524288B
67: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524288B
	owner_prog_type sched_cls  owner jited
68: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 294595  memlock 21213184B
69: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 147297  memlock 10608640B
70: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 294595  memlock 16498688B
71: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 294595  memlock 4714496B
72: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 131072B
73: hash  name cilium_lb_affin  flags 0x1
	key 8B  value 1B  max_entries 65536  memlock 1048576B
74: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 2097152B
75: lpm_trie  name cilium_lb4_sour  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 1048576B
77: hash_of_maps  name cilium_lb4_magl  flags 0x1
	key 2B  value 4B  max_entries 65536  memlock 524288B
85: lru_hash  name cilium_ratelimi  flags 0x0
	key 4B  value 16B  max_entries 1024  memlock 24576B
	btf_id 153
86: array  name cilium_encrypt_  flags 0x0
	key 4B  value 1B  max_entries 1  memlock 4096B
	btf_id 154
87: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 65536B
	btf_id 155
88: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
90: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
102: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
106: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
109: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
112: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
115: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
122: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
125: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
129: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
132: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
135: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
139: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
143: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
146: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
149: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
152: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
155: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
158: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
161: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
164: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
167: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
176: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
179: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
239: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
383: hash  name cilium_node_map  flags 0x1
	key 20B  value 4B  max_entries 16384  memlock 393216B
424: hash  name cilium_skip_lb4  flags 0x1
	key 16B  value 1B  max_entries 100  memlock 4096B
	btf_id 813
761: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
762: array  name cilium_maglev_i  flags 0x0
	key 4B  value 65524B  max_entries 1  memlock 65536B
763: array  name cilium_maglev_i  flags 0x0
	key 4B  value 65524B  max_entries 1  memlock 65536B
764: array  name cilium_maglev_i  flags 0x0
	key 4B  value 65524B  max_entries 1  memlock 65536B
765: array  name cilium_maglev_i  flags 0x0
	key 4B  value 65524B  max_entries 1  memlock 65536B
766: array  name cilium_maglev_i  flags 0x0
	key 4B  value 65524B  max_entries 1  memlock 65536B
767: array  name cilium_maglev_i  flags 0x0
	key 4B  value 65524B  max_entries 1  memlock 65536B
805: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2246
806: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
811: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
812: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2253
813: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2255
814: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
815: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
816: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2258
817: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
818: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2260
819: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2262
820: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
821: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2323
822: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
823: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2326
824: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
825: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
826: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
827: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
833: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
834: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2342
835: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
836: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2346
837: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
838: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2359
839: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
840: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2393
841: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2398
842: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
845: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2407
846: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
847: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
848: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2428
849: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2430
850: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
852: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
853: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2440
854: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
857: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2484
858: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
861: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2494
862: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
863: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2496
864: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
866: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
893: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
894: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2676
895: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2677
896: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
897: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
898: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2678
899: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2679
900: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
901: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
902: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2683
903: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
904: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 2685
