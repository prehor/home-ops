Error: ipv6: FIB table does not exist.
Dump terminated
> Error while running 'ip -6 route show table 2004':  exit status 2

