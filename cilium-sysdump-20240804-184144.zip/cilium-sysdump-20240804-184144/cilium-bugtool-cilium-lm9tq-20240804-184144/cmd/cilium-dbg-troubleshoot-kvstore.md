Unable to read etcd configuration: /var/lib/etcd-config/etcd.config
This is expected when Cilium is running in CRD mode
