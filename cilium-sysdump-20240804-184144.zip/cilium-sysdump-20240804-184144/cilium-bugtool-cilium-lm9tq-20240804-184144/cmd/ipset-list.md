Name: cilium_node_set_v4
Type: hash:ip
Revision: 5
Header: family inet hashsize 1024 maxelem 65536 bucketsize 12 initval 0x1c94f87d
Size in memory: 240
References: 1
Number of entries: 1
Members:
192.168.1.11

Name: cilium_node_set_v6
Type: hash:ip
Revision: 5
Header: family inet6 hashsize 1024 maxelem 65536 bucketsize 12 initval 0xe8a5a94d
Size in memory: 208
References: 0
Number of entries: 0
Members:
