1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 promiscuity 0 minmtu 0 maxmtu 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     778159476 1421792      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     778159476 1421792      0       0       0       0 
2: enp9s0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq master lan state UP mode DEFAULT group default qlen 1000
    link/ether 18:31:bf:d0:6d:0d brd ff:ff:ff:ff:ff:ff promiscuity 1 minmtu 68 maxmtu 9216 
    bridge_slave state forwarding priority 32 cost 5 hairpin off guard off root_block off fastleave off learning on flood on port_id 0x8001 port_no 0x1 designated_port 32769 designated_cost 0 designated_bridge 8000.a:f4:f8:8e:5c:8c designated_root 8000.a:f4:f8:8e:5c:8c hold_timer    0.00 message_age_timer    0.00 forward_delay_timer    0.00 topology_change_ack 0 config_pending 0 proxy_arp off proxy_arp_wifi off mcast_router 1 mcast_fast_leave off mcast_flood on mcast_to_unicast off neigh_suppress off group_fwd_mask 0 group_fwd_mask_str 0x0 vlan_tunnel off isolated off addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:09:00.0 
    RX:  bytes packets errors dropped  missed   mcast           
      33778233   81549      0       0       0   29004 
    TX:  bytes packets errors dropped carrier collsns           
      75782346   77633      0       0       0       0 
3: enp10s0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc mq master lan state DOWN mode DEFAULT group default qlen 1000
    link/ether 18:31:bf:d0:6d:0e brd ff:ff:ff:ff:ff:ff promiscuity 1 minmtu 68 maxmtu 9216 
    bridge_slave state disabled priority 32 cost 100 hairpin off guard off root_block off fastleave off learning on flood on port_id 0x8002 port_no 0x2 designated_port 32770 designated_cost 0 designated_bridge 8000.a:f4:f8:8e:5c:8c designated_root 8000.a:f4:f8:8e:5c:8c hold_timer    0.00 message_age_timer    0.00 forward_delay_timer    0.00 topology_change_ack 0 config_pending 0 proxy_arp off proxy_arp_wifi off mcast_router 1 mcast_fast_leave off mcast_flood on mcast_to_unicast off neigh_suppress off group_fwd_mask 0 group_fwd_mask_str 0x0 vlan_tunnel off isolated off addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:0a:00.0 
    RX:  bytes packets errors dropped  missed   mcast           
             0       0      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
             0       0      0       0       0       0 
4: enp11s0: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN mode DEFAULT group default qlen 1000
    link/ether 18:31:bf:d0:6d:0f brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 9216 addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:0b:00.0 
    RX:  bytes packets errors dropped  missed   mcast           
             0       0      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
             0       0      0       0       0       0 
5: enp12s0: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN mode DEFAULT group default qlen 1000
    link/ether 18:31:bf:d0:6d:10 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 9216 addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:0c:00.0 
    RX:  bytes packets errors dropped  missed   mcast           
             0       0      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
             0       0      0       0       0       0 
6: lan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 0a:f4:f8:8e:5c:8c brd ff:ff:ff:ff:ff:ff promiscuity 1 minmtu 68 maxmtu 65535 
    bridge forward_delay 0 hello_time 200 max_age 2000 ageing_time 30000 stp_state 0 priority 32768 vlan_filtering 1 vlan_protocol 802.1Q bridge_id 8000.a:f4:f8:8e:5c:8c designated_root 8000.a:f4:f8:8e:5c:8c root_port 0 root_path_cost 0 topology_change 0 topology_change_detected 0 hello_timer    0.00 tcn_timer    0.00 topology_change_timer    0.00 gc_timer   28.28 vlan_default_pvid 1 vlan_stats_enabled 0 vlan_stats_per_port 0 group_fwd_mask 0 group_address 01:80:c2:00:00:00 mcast_snooping 1 mcast_router 1 mcast_query_use_ifaddr 0 mcast_querier 0 mcast_hash_elasticity 16 mcast_hash_max 4096 mcast_last_member_count 2 mcast_startup_query_count 2 mcast_last_member_interval 100 mcast_membership_interval 26000 mcast_querier_interval 25500 mcast_query_interval 12500 mcast_query_response_interval 1000 mcast_startup_query_interval 3124 mcast_stats_enabled 0 mcast_igmp_version 2 mcast_mld_version 1 nf_call_iptables 0 nf_call_ip6tables 0 nf_call_arptables 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      32366904   76532      0    2293       0   29004 
    TX:  bytes packets errors dropped carrier collsns           
      72891216   33828      0       0       0       0 
7: iot@lan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 0a:f4:f8:8e:5c:8d brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 0 maxmtu 65535 
    vlan protocol 802.1Q id 101 <REORDER_HDR> addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        226000    1338      0       0       0     384 
    TX:  bytes packets errors dropped carrier collsns           
          1506      19      0       0       0       0 
8: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether a2:2a:48:15:b5:3b brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
           770      11      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
           770      11      0       0       0       0 
9: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether fe:d4:d7:ea:50:e6 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
           770      11      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
           770      11      0       0       0       0 
13: lxcf228d89e07e3@if12: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 12:45:0d:33:80:cf brd ff:ff:ff:ff:ff:ff link-netnsid 1 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       5229260    7936      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       8772341    7565      0       0       0       0 
15: lxc5d9688897f63@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 2a:03:8c:ef:b0:66 brd ff:ff:ff:ff:ff:ff link-netnsid 2 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4378025   15953      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       4725634   18489      0       0       0       0 
17: lxc02b3905a6dfb@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 9e:32:a3:f4:26:24 brd ff:ff:ff:ff:ff:ff link-netnsid 3 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1546955    8558      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1686614    8426      0       0       0       0 
19: lxc859384ae38a5@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether f6:10:aa:81:f3:2c brd ff:ff:ff:ff:ff:ff link-netnsid 4 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       5915139    6445      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       2959333    6774      0       0       0       0 
21: lxc503b32a2c6a7@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 0e:5f:8b:18:78:02 brd ff:ff:ff:ff:ff:ff link-netnsid 5 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       3684486    8990      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      16554060    9032      0       0       0       0 
23: lxc910004d47ea4@if22: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether fa:b0:b0:45:5c:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 6 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        837580    3654      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        467400    5457      0       0       0       0 
27: lxce3e3ac922558@if26: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 06:7d:1c:9a:9d:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 8 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4061017   21303      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       6740216   27788      0       0       0       0 
29: lxcbadff7f8234a@if28: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 7e:9b:cc:42:b3:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 9 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      13687643   13127      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      20652905   13736      0       0       0       0 
31: lxcef0c82914670@if30: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 96:86:cd:b0:3a:ac brd ff:ff:ff:ff:ff:ff link-netnsid 10 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1610140    9028      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1815363    9157      0       0       0       0 
33: lxc2b284e5fe4ce@if32: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether da:f1:59:aa:ac:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 11 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       9294173   34968      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      47192415   34803      0       0       0       0 
35: lxcd458e6709d60@if34: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether fa:0c:0e:33:d9:dc brd ff:ff:ff:ff:ff:ff link-netnsid 12 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        705955    4947      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1113558    4892      0       0       0       0 
37: lxc4c920d1320f1@if36: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 52:1f:77:b9:ac:46 brd ff:ff:ff:ff:ff:ff link-netnsid 13 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        681288    7536      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1034092    8824      0       0       0       0 
39: lxcfd427869bc62@if38: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether f6:a4:e9:14:df:98 brd ff:ff:ff:ff:ff:ff link-netnsid 14 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1464243    8742      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1575727    8960      0       0       0       0 
41: lxce316820ded76@if40: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 5a:3d:1f:73:56:44 brd ff:ff:ff:ff:ff:ff link-netnsid 15 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      17234902   15682      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       7302428   16938      0       0       0       0 
43: lxc3b052960bf39@if42: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 32:aa:e4:e5:37:63 brd ff:ff:ff:ff:ff:ff link-netnsid 16 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1526664    8394      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1594313    8118      0       0       0       0 
45: lxc83b895bb0fa9@if44: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 46:46:bc:7d:29:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 17 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1977690    9120      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      10171476   12247      0       0       0       0 
47: lxcf8bd3ef502c5@if46: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 66:2e:d0:39:89:83 brd ff:ff:ff:ff:ff:ff link-netnsid 18 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1832988    7538      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        919546    7040      0       0       0       0 
49: lxcbdbcfb757b99@if48: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 7e:68:c8:e5:63:f0 brd ff:ff:ff:ff:ff:ff link-netnsid 19 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        240212    1574      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        227579    2055      0       0       0       0 
51: lxc3136ad64a403@if50: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ee:cc:1d:a4:6e:91 brd ff:ff:ff:ff:ff:ff link-netnsid 20 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        732390    5496      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       7808440    5086      0       0       0       0 
53: lxccc2dfd51c9f5@if52: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ea:b8:dd:5d:5d:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 21 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          1146      15      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
           176       2      0       0       0       0 
55: lxcefb5df718e0f@if54: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ee:39:66:a4:13:43 brd ff:ff:ff:ff:ff:ff link-netnsid 22 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        276550    2052      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       2425583    1728      0       0       0       0 
59: lxcb7c0ed9dd42e@if58: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 86:d4:6d:77:25:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 24 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        653594    4573      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      10239528    3778      0       0       0       0 
61: lxcbf04ad6c9b4a@if60: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ca:50:84:a1:10:4e brd ff:ff:ff:ff:ff:ff link-netnsid 25 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      10366329   36141      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      72515911   29721      0       0       0       0 
63: lxca7a944ff01cc@if62: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 1a:1e:a2:8c:4a:e0 brd ff:ff:ff:ff:ff:ff link-netnsid 26 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4900536   24469      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       2547455   26422      0       0       0       0 
75: lxc_health@if74: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 06:1d:6b:cb:46:58 brd ff:ff:ff:ff:ff:ff link-netnsid 23 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         25258     321      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         32778     403      0       0       0       0 
77: lxcb9692533e4ab@if76: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 5a:7a:aa:2f:d4:08 brd ff:ff:ff:ff:ff:ff link-netnsid 27 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        355801    4321      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        466674    5352      0       0       0       0 
