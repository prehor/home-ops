REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     124004    152361473   0      unknown(0)
Interface                 INGRESS     188474    98023778    2305   bpf_lxc.c
Interface                 INGRESS     53302     17446478    1132   bpf_host.c
Success                   EGRESS      112990    60339512    0      unknown(0)
Success                   EGRESS      16954     63834152    235    trace.h
Success                   EGRESS      171277    43974948    1308   bpf_lxc.c
Success                   EGRESS      3         210         1694   bpf_host.c
Success                   EGRESS      3498      448912      1035   bpf_lxc.c
Success                   EGRESS      5999      576334      1598   bpf_host.c
Success                   INGRESS     188240    98011602    2110   bpf_lxc.c
Success                   INGRESS     188240    98011602    235    trace.h
Success                   INGRESS     204432    273413742   0      unknown(0)
Unsupported L3 protocol   EGRESS      331       25006       0      unknown(0)
Unsupported L3 protocol   EGRESS      59        4226        1492   bpf_lxc.c
Unsupported L3 protocol   INGRESS     347       26102       0      unknown(0)
Unsupported L3 protocol   INGRESS     79        5666        2388   bpf_lxc.c
